<?php
/**
 * Plugin Name: ViroBuilder
 * Plugin URI: https://virodigital.net/virobuilder
 * Description: Not a page builder. A page designer. The first WordPress plugin that designs bespoke, agency-quality landing pages with AI — with real photos, responsive layouts, SEO, and a chat-based editor. No templates. No bloat.
 * Version: 1.3.6
 * Author: Viro Digital LLC
 * Author URI: https://virodigital.net
 * License: GPL v2 or later
 * License URI: https://www.gnu.org/licenses/gpl-2.0.html
 * Text Domain: virobuilder
 * Domain Path: /languages
 * Requires at least: 6.2
 * Requires PHP: 8.0
 *
 * ViroBuilder is developed by Viro Digital LLC (Connecticut, USA).
 * Support: support@virodigital.net
 *
 * @copyright 2026 Viro Digital LLC
 */

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

// Prevent double-loading during plugin updates/reactivation.
// This guard + function_exists on every function = no fatal on update.
if ( defined( 'VIROBUILDER_LOADED' ) ) {
    return;
}
define( 'VIROBUILDER_LOADED', true );
define( 'VIROBUILDER_VERSION', '1.3.6' );
define( 'VIROBUILDER_FILE', __FILE__ );
define( 'VIROBUILDER_PATH', plugin_dir_path( __FILE__ ) );
define( 'VIROBUILDER_URL', plugin_dir_url( __FILE__ ) );
define( 'VIROBUILDER_ASSETS_URL', VIROBUILDER_URL . 'assets/' );

require_once VIROBUILDER_PATH . 'includes/class-virobuilder.php';
require_once VIROBUILDER_PATH . 'includes/class-editor.php';
require_once VIROBUILDER_PATH . 'includes/class-ai-builder.php';
require_once VIROBUILDER_PATH . 'includes/class-forms.php';
require_once VIROBUILDER_PATH . 'includes/class-assets.php';

/**
 * Sanitize an AI-generated full HTML document before output.
 *
 * Designer pages are complete HTML documents (doctype, <head>, <style>,
 * structural markup). wp_kses() cannot be used here because it mangles the
 * page's CSS (media queries and child-combinator selectors contain ">", and
 * inline style filtering strips valid properties), which would destroy the
 * design. Instead, this removes the actual script-execution vectors — script
 * elements, inline event-handler attributes, and javascript: URLs — while
 * preserving the document structure and all CSS. Generated pages reveal their
 * content with CSS animations, so stripping scripts does not hide content.
 *
 * @param string $html Raw stored document HTML.
 * @return string Sanitized document HTML, safe to output.
 */
function virobuilder_sanitize_document_html( $html ) {
	if ( ! is_string( $html ) || '' === $html ) {
		return $html;
	}

	// Remove <script>...</script> blocks (any attributes, multiline).
	$html = preg_replace( '#<script\b[^>]*>.*?</script>#is', '', $html );
	// Remove any stray or self-closing <script> tags.
	$html = preg_replace( '#<script\b[^>]*/?>#i', '', $html );
	// Remove inline event-handler attributes (onclick, onload, onerror, ...).
	$html = preg_replace( '#\son[a-z]+\s*=\s*"[^"]*"#i', '', $html );
	$html = preg_replace( "#\son[a-z]+\s*=\s*'[^']*'#i", '', $html );
	$html = preg_replace( '#\son[a-z]+\s*=\s*[^\s>]+#i', '', $html );
	// Neutralize javascript: URIs in link/source attributes.
	$html = preg_replace( '#(href|src|xlink:href)\s*=\s*(["\'])\s*javascript:[^"\']*\2#i', '$1=$2#$2', $html );

	return $html;
}

// ── Bootstrap ──
if ( ! function_exists( 'virobuilder_init' ) ) {
    function virobuilder_init() {
        return ViroBuilder::instance();
    }
}
add_action( 'plugins_loaded', 'virobuilder_init' );

// ── Extend timeouts for AI API calls ──
if ( ! function_exists( 'virobuilder_extend_api_timeout' ) ) {
    function virobuilder_extend_api_timeout( $timeout, $url = '' ) {
        if ( is_string( $url ) && strpos( $url, 'api.anthropic.com' ) !== false ) {
            return 300;
        }
        if ( is_string( $url ) && strpos( $url, 'api.pexels.com' ) !== false ) {
            return 30;
        }
        return $timeout;
    }
}
add_filter( 'http_request_timeout', 'virobuilder_extend_api_timeout', 10, 2 );

if ( ! function_exists( 'virobuilder_extend_execution_time' ) ) {
    function virobuilder_extend_execution_time() {
        if ( function_exists( 'set_time_limit' ) ) {
            // phpcs:ignore Squiz.PHP.DiscouragedFunctions.Discouraged, WordPress.PHP.NoSilencedErrors.Discouraged -- AI generation can legitimately exceed the default limit
            @set_time_limit( 300 );
        }
    }
}
add_action( 'wp_ajax_virobuilder_ai_design', 'virobuilder_extend_execution_time', 1 );
add_action( 'wp_ajax_virobuilder_chat_edit', 'virobuilder_extend_execution_time', 1 );
add_action( 'wp_ajax_virobuilder_ai_generate', 'virobuilder_extend_execution_time', 1 );

// ── Designer page template: bypass theme for AI-generated pages ──
if ( ! function_exists( 'virobuilder_is_designer_page' ) ) {
    /**
     * Detect whether a page is a ViroBuilder AI-designed page.
     * Checks the meta flag first, then falls back to detecting a full
     * HTML document in the content (self-heals pages missing the flag).
     */
    function virobuilder_is_designer_page( $post_id ) {
        if ( get_post_meta( $post_id, '_virobuilder_designer_page', true ) === '1' ) {
            return true;
        }
        $post = get_post( $post_id );
        if ( $post && preg_match( '/^\s*(<!DOCTYPE|<html)/i', $post->post_content ) ) {
            // Self-heal: tag it so future loads are fast and the editor routes correctly
            update_post_meta( $post_id, '_virobuilder_designer_page', '1' );
            return true;
        }
        return false;
    }
}

if ( ! function_exists( 'virobuilder_designer_page_template' ) ) {
    function virobuilder_designer_page_template( $template ) {
        if ( is_singular( [ 'page', 'post' ] ) ) {
            $post_id = get_the_ID();
            if ( virobuilder_is_designer_page( $post_id ) ) {
                $designer_template = VIROBUILDER_PATH . 'templates/designer-page.php';
                if ( file_exists( $designer_template ) ) {
                    return $designer_template;
                }
            }
        }
        return $template;
    }
}
add_filter( 'template_include', 'virobuilder_designer_page_template', 99 );

if ( ! function_exists( 'virobuilder_register_designer_template' ) ) {
    function virobuilder_register_designer_template( $templates ) {
        $templates['virobuilder-designer'] = 'ViroBuilder Designer Page';
        return $templates;
    }
}
add_filter( 'theme_page_templates', 'virobuilder_register_designer_template' );

// ── Activation / Deactivation ──
register_activation_hook( __FILE__, function() {
    flush_rewrite_rules();
    update_option( 'virobuilder_version', VIROBUILDER_VERSION );
    if ( class_exists( 'ViroBuilder_Forms' ) ) {
        delete_option( 'virobuilder_forms_db_version' );
        ViroBuilder_Forms::instance()->maybe_install_schema();
    }
    // phpcs:ignore WordPress.Security.NonceVerification.Recommended -- activation hook only checks presence of a core WP flag
    if ( ! isset( $_GET['activate-multi'] ) ) {
        set_transient( 'virobuilder_activation_redirect', 1, 30 );
    }
});

register_deactivation_hook( __FILE__, function() {
    flush_rewrite_rules();
});

// ── Plugin action links ──
add_filter( 'plugin_action_links_' . plugin_basename( __FILE__ ), function( $links ) {
    $custom = [
        '<a href="' . esc_url( admin_url( 'admin.php?page=virobuilder-dashboard' ) ) . '">' . esc_html__( 'Dashboard', 'virobuilder' ) . '</a>',
        '<a href="' . esc_url( admin_url( 'admin.php?page=virobuilder-ai-settings' ) ) . '">' . esc_html__( 'AI Settings', 'virobuilder' ) . '</a>',
    ];
    return array_merge( $custom, $links );
});
