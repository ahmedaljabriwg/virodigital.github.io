=== ViroBuilder ===
Contributors: virodigital
Tags: page builder, ai, landing page, website builder, design
Requires at least: 6.2
Tested up to: 7.0
Requires PHP: 8.0
Stable tag: 1.3.6
License: GPLv2 or later
License URI: https://www.gnu.org/licenses/gpl-2.0.html

Describe your business and ViroBuilder uses AI to design a complete landing page — layout, copy, real photos, and SEO — editable by chat and click.

== Description ==

ViroBuilder is a WordPress plugin that uses AI to design landing pages. You describe your business in plain language, and the plugin generates a complete page — the layout, written copy, real stock photos, and SEO markup — which you can then refine in a visual editor by clicking elements or chatting with the AI.

It requires your own API keys: an Anthropic (Claude) key for generation and a Pexels key for stock photos. Both are entered in the plugin settings and stored only in your WordPress database.

= How it works =

1. **Describe your business** — for example, "A family dental practice in Boston focused on anxiety-free care." You can optionally add an industry, audience, location, and brand color.
2. **AI designs the page** — the plugin sends your description to the Anthropic API, which returns a complete HTML page with a custom layout and written copy, then places relevant photos from Pexels.
3. **Edit by chat or click** — open the visual editor to click any element and change its text, image, or link, or describe a broader change in plain language (for example, "add a FAQ section" or "change the brand color to navy").
4. **Publish** — the page is saved as standard WordPress content.

= Features =

* **AI-designed pages.** The AI designs a layout and writes copy for each business; different inputs produce different layouts.
* **Stock photos from Pexels.** The plugin searches Pexels for relevant photos and places them in the page. You can swap any image in the editor.
* **Chat and click editor.** Edit text, images, links, and colors visually, or request larger changes in plain language.
* **SEO markup.** Generated pages include a meta description, Open Graph tags, Twitter Card tags, and JSON-LD structured data.
* **Responsive layouts.** Pages use desktop, tablet, and phone breakpoints, which you can preview in the editor.
* **Lead-capture forms.** Forms placed on generated pages save submissions to a dashboard in the admin.
* **Standard output.** Generated pages are stored as ordinary WordPress content; there is no proprietary format.

= Who it's for =

* Small business owners who want a landing page without building it section by section.
* Freelancers and agencies who build sites for clients.
* WordPress users who want AI-assisted page creation inside WordPress.

= Free tier (BYOK) =

The free version includes the full plugin. You provide your own Anthropic API key (for AI generation) and Pexels API key (for stock photos), and you pay Anthropic and Pexels directly for your own usage.

= Pro tier (coming soon) =

A paid tier is planned that would not require your own API keys. Features and pricing are still being finalized. Details will be posted at [virodigital.net/virobuilder](https://virodigital.net/virobuilder).

= External services =

ViroBuilder connects to the following third-party services to function:

**Anthropic API** (api.anthropic.com)
Used for AI-powered page design and chat-based editing. Your business description and page content are sent to Anthropic's servers for processing. Requires a user-provided API key.
[Privacy Policy](https://www.anthropic.com/privacy) | [Terms of Service](https://www.anthropic.com/terms)

**Pexels API** (api.pexels.com)
Used for searching and embedding free stock photographs in generated pages. Image search queries are sent to Pexels. Requires a user-provided API key.
[Privacy Policy](https://www.pexels.com/privacy-policy/) | [Terms of Service](https://www.pexels.com/terms-of-service/)

**Google Fonts** (fonts.googleapis.com)
Used only for typography on the public landing pages you generate and publish. Font files are requested by your site visitor's browser when they view a generated page; the plugin's admin screens and editor do not load any remote fonts. Because the generated page is your own published content, you may change or self-host these fonts at any time by editing the page.
[Privacy Policy](https://policies.google.com/privacy)

All three services are optional integrations that power the plugin's core function. The Anthropic and Pexels keys are provided by you and stored only in your own WordPress database. No data is collected or sent to Viro Digital LLC servers in the free tier — no tracking, no analytics, no telemetry.

== Installation ==

1. Upload the `virobuilder` folder to `/wp-content/plugins/` or install via Plugins > Add New > Upload.
2. Activate the plugin through the Plugins menu.
3. Go to **ViroBuilder > AI Settings** in your WordPress admin.
4. Add your **Anthropic API key** — get one free at [console.anthropic.com](https://console.anthropic.com/settings/keys). Each page generation is billed by Anthropic at their standard API rates.
5. Add your **Pexels API key** — get one free at [pexels.com/api](https://www.pexels.com/api/). 200 requests per hour, no credit card required.
6. Create a new page, open it in ViroBuilder, and click the AI Quick-Build button.
7. Describe your business, pick a brand color, and hit Generate.

== Frequently Asked Questions ==

= How much does each page cost to generate? =

Usage is billed directly by Anthropic at their standard API rates. ViroBuilder adds no markup to BYOK usage.

= Do I need to know HTML or CSS? =

No. ViroBuilder generates the complete page — design system, layout, copy, photos, animations, and SEO. You edit by clicking text, swapping images, or chatting with the AI. No code knowledge required.

= Can I edit the generated pages? =

Yes, in three ways: (1) Click any text directly in the preview to rewrite it — no AI needed, no cost. (2) Click any image to search Pexels and swap it — no cost. (3) Type instructions in the chat panel for structural changes, color updates, or adding/removing sections — each edit is a small API call.

= What does the generated page look like? =

Each page includes: a sticky frosted-glass navigation bar, a hero section with decorative elements and social proof stats, a trust strip, a service/feature card grid with hover effects, an about section with an overlay review card, a CTA band, and a structured footer. All with scroll-triggered animations and three responsive breakpoints.

= Does it work with my theme? =

Generated pages use their own complete design system and bypass your theme's styling. They render as standalone pages — no theme header, footer, or sidebar interference. Your existing theme pages are unaffected.

= Is the generated HTML clean? =

Yes. No inline styles, no bloated frameworks, no jQuery. Each page is a single HTML document with CSS custom properties, semantic HTML5, and minimal JavaScript for animations. Typically under 25KB total.

= Can I use this for client sites? =

Yes. The free tier works on any site where you've added your API keys. A Pro tier with multiple site activations and white-labeling is coming soon.

= What industries does it support? =

Any. The AI designs based on your description, not a fixed template. It has been tested with dental clinics, SaaS products, restaurants, law firms, real estate, agencies, e-commerce, and fitness studios — but it works for any business you can describe.

= What happens to my page if I deactivate ViroBuilder? =

Your pages stay. They are stored as standard WordPress page content. The only thing you lose is the chat editor for making further AI-powered edits.

= Is my data private? =

In the free tier, your data goes directly from your server to Anthropic and Pexels — Viro Digital never sees it. No analytics, no tracking, no telemetry. Your API keys are stored in your WordPress database and never leave your server except to authenticate with the respective APIs.

== Screenshots ==

1. AI Quick-Build modal — describe your business, pick a color, generate.
2. Generation progress — real-time progress with staged design steps.
3. Chat editor — split-screen with live preview and AI chat panel.
4. Visual editing — click text to edit, images to swap, links to update.
5. Device preview — switch between desktop, tablet, and phone views.
6. Generated dental clinic page — real output with Pexels photos.
7. Generated SaaS page — different design system, different layout.
8. Settings page — BYOK and Pro tier options.

== Changelog ==

= 1.2.0 =
* FOCUS: ViroBuilder is now AI-only — the plugin designs pages, it doesn't assemble them
* NEW: Standalone "Create New Page" screen — describe your business and generate, no editor canvas needed
* REMOVED: The legacy drag-and-drop builder, widget library, and section templates (the AI designer replaces them)
* IMPROVED: Editor opens fullscreen (no admin chrome), chat input no longer clipped, cleaner top bar
* IMPROVED: AI pages self-heal — any full-HTML page is detected and routed to the chat editor automatically
* FIX: "Edit with ViroBuilder" now always opens the correct chat editor
* Roughly half the plugin's code removed — faster, lighter, and sharper in focus

= 1.1.0 =
* NEW: AI Designer pipeline — generates complete, bespoke HTML pages (not template assembly)
* NEW: Chat-based editor — edit pages by talking to the AI or clicking directly
* NEW: Visual editing — click text to rewrite, images to swap from Pexels, links to update
* NEW: Pexels stock photo integration — auto-matched industry photos
* NEW: SEO — meta tags, Open Graph, Twitter Cards, and JSON-LD structured data
* NEW: Three-breakpoint responsive design (desktop, tablet, mobile)
* NEW: Parallax scroll effects and entrance animations
* NEW: Image selection tracking — chat edits target the image you clicked
* NEW: Progress overlay with staged design steps during generation
* NEW: BYOK / Pro tier architecture with cost transparency
* NEW: ViroBuilder brand identity (V-sparkle logo, dark theme UI)
* FIX: Timeout handling extended to 300s for complex generations
* FIX: Error handling catches Throwable (not just Exception)
* FIX: Non-JSON response handling in JavaScript
* FIX: Double-load guard prevents fatal errors on plugin update
* FIX: Section background rendering (bg_type was missing)

= 1.0.2 =
* Style preset system (Nimbus, Clarity, Pulse)
* AI copy generation with Claude Sonnet 4.6
* Recipe-based page assembly for SaaS and Health industries
* Drag-and-drop editor with widget system
* Form builder with submission management

= 1.0.0 =
* Initial release
* Drag-and-drop page builder
* Section and widget template library
* Frontend rendering engine
* Gutenberg integration

== Upgrade Notice ==

= 1.2.0 =
ViroBuilder is now AI-only: a cleaner, faster plugin focused entirely on AI page design. The legacy drag-and-drop builder has been removed. Deactivate and delete the old version before installing.

= 1.1.0 =
Major update: ViroBuilder is now an AI page designer. Generate bespoke, professionally designed landing pages by describing your business. Includes chat editor, Pexels photos, SEO, and responsive design. Deactivate and delete the old version before installing.
