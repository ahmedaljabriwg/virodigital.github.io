=== ViroBuilder ===
Contributors: virodigital
Tags: page builder, ai, landing page, website builder, design
Requires at least: 6.2
Tested up to: 7.0
Requires PHP: 8.0
Stable tag: 1.3.5
License: GPLv2 or later
License URI: https://www.gnu.org/licenses/gpl-2.0.html

Not a page builder — a page designer. Describe your business and get a bespoke AI-designed landing page with real photos, copy, and SEO.

== Description ==

**ViroBuilder designs pages — it doesn't assemble templates.**

Most page builders assemble pre-made templates. ViroBuilder's AI designs each page from scratch — bespoke CSS, real stock photos, scroll animations, and three-breakpoint responsive layouts. The result is a clean, professional, responsive page — built in a couple of minutes.

= How it works =

1. **Describe your business** — "We're a family dental practice in Boston that focuses on anxiety-free care." That's it.
2. **AI designs your page** — complete HTML with a custom design system, real Pexels photos, written copy, SEO markup, and scroll animations.
3. **Edit with chat or click** — say "change the color to navy" or click any text to rewrite it. Say "add a FAQ section" or click an image to swap it from Pexels.

= What makes ViroBuilder different =

* **Every page is one of one.** No template library. The AI designs a unique page for each business — different fonts, different layouts, different color systems.
* **Real photos, auto-matched.** Pexels integration finds industry-relevant stock photos and places them automatically. Dental clinic gets dental photos. Restaurant gets food photography.
* **Chat editor.** Edit your page by chatting with the AI. "Make the headline shorter." "Move testimonials above services." "Change the brand color." Or click any element to edit directly.
* **SEO from day one.** Every page ships with meta description, Open Graph tags, Twitter Cards, and JSON-LD structured data. Your business shows rich snippets in Google.
* **Three-breakpoint responsive.** Desktop, tablet, and mobile — not just "it stacks." Hero images change aspect ratio. Grids adapt from 3 to 2 to 1 column. Touch targets meet accessibility standards.
* **Parallax and animations.** Scroll-triggered entrance animations, hover-lifting cards, frosted-glass navigation, and subtle parallax — built into every page.
* **No lock-in.** Generated pages are clean HTML stored as WordPress content. No proprietary format. No vendor dependency. Export, modify, or migrate anytime.
* **No bloat.** No 300KB stylesheets. No jQuery dependency. No render-blocking scripts. Just clean, minimal HTML with scoped CSS.

= Who it's for =

* **Small business owners** who want a real website, not a template that looks like everyone else's.
* **Freelancers and agencies** who build sites for clients and want to deliver $5K quality in 5 minutes.
* **WordPress developers** who want AI-powered workflows without leaving the WordPress ecosystem.

= Free tier (BYOK) =

The free version is genuinely free — no crippled features, no watermarks. You provide your own Anthropic API key (for AI generation) and Pexels API key (for stock photos). You pay Anthropic directly for what you use.

= Pro tier (coming soon) =

No API keys needed. One-click generation, built-in stock photos, premium design presets, and priority support. Details at [virodigital.net/virobuilder](https://virodigital.net/virobuilder).

= External services =

ViroBuilder connects to the following third-party services to function:

**Anthropic API** (api.anthropic.com)
Used for AI-powered page design and chat-based editing. Your business description and page content are sent to Anthropic's servers for processing. Requires a user-provided API key.
[Privacy Policy](https://www.anthropic.com/privacy) | [Terms of Service](https://www.anthropic.com/terms)

**Pexels API** (api.pexels.com)
Used for searching and embedding free stock photographs in generated pages. Image search queries are sent to Pexels. Requires a user-provided API key.
[Privacy Policy](https://www.pexels.com/privacy-policy/) | [Terms of Service](https://www.pexels.com/terms-of-service/)

**Google Fonts** (fonts.googleapis.com)
Used only for typography on the public landing pages you generate and publish. Font files are requested by your site visitor's browser when they view a generated page; the plugin's admin screens and editor do not load any remote fonts. Because the generated page is your own published content, you may change or self-host these fonts at any time by editing the page.
[Privacy Policy](https://policies.google.com/privacy)

All three services are optional integrations that power the plugin's core function. The Anthropic and Pexels keys are provided by you and stored only in your own WordPress database. No data is collected or sent to Viro Digital LLC servers in the free tier — no tracking, no analytics, no telemetry.

== Installation ==

1. Upload the `virobuilder` folder to `/wp-content/plugins/` or install via Plugins > Add New > Upload.
2. Activate the plugin through the Plugins menu.
3. Go to **ViroBuilder > AI Settings** in your WordPress admin.
4. Add your **Anthropic API key** — get one free at [console.anthropic.com](https://console.anthropic.com/settings/keys). Each page generation is billed by Anthropic at their standard API rates.
5. Add your **Pexels API key** — get one free at [pexels.com/api](https://www.pexels.com/api/). 200 requests per hour, no credit card required.
6. Create a new page, open it in ViroBuilder, and click the AI Quick-Build button.
7. Describe your business, pick a brand color, and hit Generate.

== Frequently Asked Questions ==

= How much does each page cost to generate? =

Usage is billed directly by Anthropic at their standard API rates. ViroBuilder adds no markup to BYOK usage.

= Do I need to know HTML or CSS? =

No. ViroBuilder generates the complete page — design system, layout, copy, photos, animations, and SEO. You edit by clicking text, swapping images, or chatting with the AI. No code knowledge required.

= Can I edit the generated pages? =

Yes, in three ways: (1) Click any text directly in the preview to rewrite it — no AI needed, no cost. (2) Click any image to search Pexels and swap it — no cost. (3) Type instructions in the chat panel for structural changes, color updates, or adding/removing sections — each edit is a small API call.

= What does the generated page look like? =

Each page includes: a sticky frosted-glass navigation bar, a hero section with decorative elements and social proof stats, a trust strip, a service/feature card grid with hover effects, an about section with an overlay review card, a CTA band, and a structured footer. All with scroll-triggered animations and three responsive breakpoints.

= Does it work with my theme? =

Generated pages use their own complete design system and bypass your theme's styling. They render as standalone pages — no theme header, footer, or sidebar interference. Your existing theme pages are unaffected.

= Is the generated HTML clean? =

Yes. No inline styles, no bloated frameworks, no jQuery. Each page is a single HTML document with CSS custom properties, semantic HTML5, and minimal JavaScript for animations. Typically under 25KB total.

= Can I use this for client sites? =

Yes. The free tier works on any site where you've added your API keys. A Pro tier with multiple site activations and white-labeling is coming soon.

= What industries does it support? =

Any. The AI designs based on your description, not a fixed template. It has been tested with dental clinics, SaaS products, restaurants, law firms, real estate, agencies, e-commerce, and fitness studios — but it works for any business you can describe.

= What happens to my page if I deactivate ViroBuilder? =

Your pages stay. They are stored as standard WordPress page content. The only thing you lose is the chat editor for making further AI-powered edits.

= Is my data private? =

In the free tier, your data goes directly from your server to Anthropic and Pexels — Viro Digital never sees it. No analytics, no tracking, no telemetry. Your API keys are stored in your WordPress database and never leave your server except to authenticate with the respective APIs.

== Screenshots ==

1. AI Quick-Build modal — describe your business, pick a color, generate.
2. Generation progress — real-time progress with staged design steps.
3. Chat editor — split-screen with live preview and AI chat panel.
4. Visual editing — click text to edit, images to swap, links to update.
5. Device preview — switch between desktop, tablet, and phone views.
6. Generated dental clinic page — real output with Pexels photos.
7. Generated SaaS page — different design system, different layout.
8. Settings page — BYOK and Pro tier options.

== Changelog ==

= 1.2.0 =
* FOCUS: ViroBuilder is now AI-only — the plugin designs pages, it doesn't assemble them
* NEW: Standalone "Create New Page" screen — describe your business and generate, no editor canvas needed
* REMOVED: The legacy drag-and-drop builder, widget library, and section templates (the AI designer replaces them)
* IMPROVED: Editor opens fullscreen (no admin chrome), chat input no longer clipped, cleaner top bar
* IMPROVED: AI pages self-heal — any full-HTML page is detected and routed to the chat editor automatically
* FIX: "Edit with ViroBuilder" now always opens the correct chat editor
* Roughly half the plugin's code removed — faster, lighter, and sharper in focus

= 1.1.0 =
* NEW: AI Designer pipeline — generates complete, bespoke HTML pages (not template assembly)
* NEW: Chat-based editor — edit pages by talking to the AI or clicking directly
* NEW: Visual editing — click text to rewrite, images to swap from Pexels, links to update
* NEW: Pexels stock photo integration — auto-matched industry photos
* NEW: SEO — meta tags, Open Graph, Twitter Cards, and JSON-LD structured data
* NEW: Three-breakpoint responsive design (desktop, tablet, mobile)
* NEW: Parallax scroll effects and entrance animations
* NEW: Image selection tracking — chat edits target the image you clicked
* NEW: Progress overlay with staged design steps during generation
* NEW: BYOK / Pro tier architecture with cost transparency
* NEW: ViroBuilder brand identity (V-sparkle logo, dark theme UI)
* FIX: Timeout handling extended to 300s for complex generations
* FIX: Error handling catches Throwable (not just Exception)
* FIX: Non-JSON response handling in JavaScript
* FIX: Double-load guard prevents fatal errors on plugin update
* FIX: Section background rendering (bg_type was missing)

= 1.0.2 =
* Style preset system (Nimbus, Clarity, Pulse)
* AI copy generation with Claude Sonnet 4.6
* Recipe-based page assembly for SaaS and Health industries
* Drag-and-drop editor with widget system
* Form builder with submission management

= 1.0.0 =
* Initial release
* Drag-and-drop page builder
* Section and widget template library
* Frontend rendering engine
* Gutenberg integration

== Upgrade Notice ==

= 1.2.0 =
ViroBuilder is now AI-only: a cleaner, faster plugin focused entirely on AI page design. The legacy drag-and-drop builder has been removed. Deactivate and delete the old version before installing.

= 1.1.0 =
Major update: ViroBuilder is now an AI page designer. Generate bespoke, professionally designed landing pages by describing your business. Includes chat editor, Pexels photos, SEO, and responsive design. Deactivate and delete the old version before installing.
