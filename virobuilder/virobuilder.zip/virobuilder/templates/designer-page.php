<?php
/**
 * Template: ViroBuilder Designer Page
 *
 * Renders AI-generated designer pages as raw HTML without any theme
 * wrapping (no header.php, no footer.php, no sidebar). The page content
 * IS the complete HTML document.
 *
 * This template is auto-assigned to pages that have the
 * '_virobuilder_designer_page' meta key set to '1'.
 *
 * @package ViroBuilder
 */

defined( 'ABSPATH' ) || exit;

// Get the raw post content (the full HTML document)
$virobuilder_html = get_the_content( null, false, get_the_ID() );

// Strip script-execution vectors as late as possible, right before output,
// while preserving document structure and CSS (see
// virobuilder_sanitize_document_html()).
$virobuilder_html = virobuilder_sanitize_document_html( $virobuilder_html );

// If the content starts with <!DOCTYPE or <html, output it raw
// and bypass the theme entirely
if ( preg_match( '/^\s*<!DOCTYPE|^\s*<html/i', $virobuilder_html ) ) {
    // Sanitized above: <script> tags, on* event-handler attributes, and
    // javascript: URLs have been removed. The remaining markup is a complete
    // HTML document whose CSS must be emitted verbatim, so no further escaping
    // function applies without breaking the design.
    // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- sanitized full HTML document (scripts/handlers stripped)
    echo $virobuilder_html;
    exit;
}

// Fallback: if for some reason the content isn't a full HTML document,
// render it inside a minimal wrapper
?>
<!DOCTYPE html>
<html <?php language_attributes(); ?>>
<head>
    <meta charset="<?php bloginfo( 'charset' ); ?>">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php wp_title( '|', true, 'right' ); ?></title>
    <?php wp_head(); ?>
</head>
<body <?php body_class(); ?>>
    <?php
    // $virobuilder_html was sanitized above (scripts/handlers/javascript: URLs removed).
    // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- sanitized page content (scripts/handlers stripped)
    echo $virobuilder_html;
    ?>
    <?php wp_footer(); ?>
</body>
</html>
