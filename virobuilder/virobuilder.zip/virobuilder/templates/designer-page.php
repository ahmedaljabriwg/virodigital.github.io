<?php
/**
 * Template: ViroBuilder Designer Page
 *
 * Renders AI-generated designer pages as raw HTML without any theme
 * wrapping (no header.php, no footer.php, no sidebar). The page content
 * IS the complete HTML document.
 *
 * This template is auto-assigned to pages that have the
 * '_virobuilder_designer_page' meta key set to '1'.
 *
 * @package ViroBuilder
 */

defined( 'ABSPATH' ) || exit;

// Get the raw post content (the full HTML document)
$virobuilder_html = get_the_content( null, false, get_the_ID() );

// If the content starts with <!DOCTYPE or <html, output it raw
// and bypass the theme entirely
if ( preg_match( '/^\s*<!DOCTYPE|^\s*<html/i', $virobuilder_html ) ) {
    // The content is a complete HTML document (doctype, <style>, etc.) created only
    // by users with the edit_posts capability via the ViroBuilder editor. It cannot be
    // escaped or run through wp_kses_post without destroying the page design.
    // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- trusted, capability-gated full HTML document
    echo $virobuilder_html;
    exit;
}

// Fallback: if for some reason the content isn't a full HTML document,
// render it inside a minimal wrapper
?>
<!DOCTYPE html>
<html <?php language_attributes(); ?>>
<head>
    <meta charset="<?php bloginfo( 'charset' ); ?>">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php wp_title( '|', true, 'right' ); ?></title>
    <?php wp_head(); ?>
</head>
<body <?php body_class(); ?>>
    <?php
    // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- trusted, capability-gated page content
    echo $virobuilder_html;
    ?>
    <?php wp_footer(); ?>
</body>
</html>
