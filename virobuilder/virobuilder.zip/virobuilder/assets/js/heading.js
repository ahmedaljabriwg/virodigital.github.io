document.addEventListener('DOMContentLoaded', function(){
            var wrap = document.querySelector('.wp-heading-inline');
            if (!wrap) return;
            var a = document.createElement('a');
            a.href = VBHEAD.createUrl;
            a.className = 'page-title-action';
            a.style.cssText = 'background:#4f46e5;border-color:#4f46e5;color:#fff';
            a.textContent = '✦ Create with ViroBuilder AI';
            var addNew = wrap.parentNode.querySelector('.page-title-action');
            if (addNew) { addNew.parentNode.insertBefore(a, addNew.nextSibling); }
            else { wrap.parentNode.insertBefore(a, wrap.nextSibling); }
        });
