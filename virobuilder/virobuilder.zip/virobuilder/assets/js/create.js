(function(){
            var AJAX = VBCREATE.ajax;
            var ADMIN = VBCREATE.admin;
            var NONCE = VBCREATE.nonce;
            var go = document.getElementById('vbc-go');
            var overlay = document.getElementById('vbc-overlay');
            var stepEl = document.getElementById('vbc-ov-step');
            var timerEl = document.getElementById('vbc-ov-timer');
            var steps = [
                ['🧠','Understanding your business…'],
                ['🎨','Choosing colors and typography…'],
                ['📐','Designing the layout…'],
                ['✍️','Writing your copy…'],
                ['📷','Finding the right photos…'],
                ['✨','Adding animations and polish…'],
                ['🔍','Optimizing for search engines…'],
                ['📱','Making it responsive…'],
                ['🏁','Finishing touches…']
            ];
            go.addEventListener('click', function(){
                var name = document.getElementById('vbc-name').value.trim();
                var offering = document.getElementById('vbc-offering').value.trim();
                if(!name || !offering){ alert('Please enter the business name and what they offer.'); return; }

                var brief = {
                    business_name:name, offering:offering,
                    industry:document.getElementById('vbc-industry').value,
                    audience:document.getElementById('vbc-audience').value.trim(),
                    location:document.getElementById('vbc-location').value.trim(),
                    phone:document.getElementById('vbc-phone').value.trim(),
                    brand_color:document.getElementById('vbc-color').value
                };

                overlay.classList.add('on');
                var t0 = Date.now(), si = 0;
                var stepTimer = setInterval(function(){
                    si = Math.min(si+1, steps.length-1);
                    stepEl.innerHTML = '<span>'+steps[si][0]+'</span><span>'+steps[si][1]+'</span>';
                }, 9000);
                var clock = setInterval(function(){
                    timerEl.textContent = Math.round((Date.now()-t0)/1000)+'s';
                }, 1000);

                var fd = new FormData();
                fd.append('action','virobuilder_ai_design');
                fd.append('_ajax_nonce', NONCE);
                fd.append('save_as_post','1');
                Object.keys(brief).forEach(function(k){ fd.append(k, brief[k]); });

                fetch(AJAX, {method:'POST', body:fd, credentials:'same-origin'})
                    .then(function(r){ return r.text(); })
                    .then(function(text){
                        clearInterval(stepTimer); clearInterval(clock);
                        var data;
                        try { data = JSON.parse(text); }
                        catch(e){ overlay.classList.remove('on'); alert('The server returned an unexpected response. Please try again.'); return; }
                        if(data.success && data.data && data.data.post_id){
                            window.location.href = ADMIN + '?page=virobuilder-designer-edit&post_id=' + data.data.post_id;
                        } else {
                            overlay.classList.remove('on');
                            alert((data.data && data.data.message) ? data.data.message : 'Generation failed. Please try again.');
                        }
                    })
                    .catch(function(){
                        clearInterval(stepTimer); clearInterval(clock);
                        overlay.classList.remove('on');
                        alert('Network error. Please try again.');
                    });
            });
        })();
