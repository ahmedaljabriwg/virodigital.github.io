(function() {
            // Delete handler
            document.querySelectorAll('.virobuilder-delete-submission').forEach(function(el) {
                el.addEventListener('click', async function(e) {
                    e.preventDefault();
                    if (!confirm('Delete this submission? This cannot be undone.')) return;
                    const id = this.dataset.id;
                    const fd = new FormData();
                    fd.append('action', 'virobuilder_form_delete_submission');
                    fd.append('_wpnonce', VBSUBS.nonce);
                    fd.append('id', id);
                    try {
                        const res = await fetch(ajaxurl, { method: 'POST', body: fd });
                        const data = await res.json();
                        if (data.success) {
                            this.closest('tr').remove();
                        } else {
                            alert('Could not delete: ' + (data.data?.message || 'unknown error'));
                        }
                    } catch (err) {
                        alert('Network error');
                    }
                });
            });

            // CSV export
            const exportBtn = document.getElementById('virobuilder-export-csv');
            if (exportBtn) {
                exportBtn.addEventListener('click', function(e) {
                    e.preventDefault();
                    const formId = this.dataset.formId || '';
                    const url = ajaxurl + '?action=virobuilder_form_export_csv&_wpnonce=' + encodeURIComponent(VBSUBS.nonce) + '&form_id=' + encodeURIComponent(formId);
                    window.location.href = url;
                });
            }
        })();
