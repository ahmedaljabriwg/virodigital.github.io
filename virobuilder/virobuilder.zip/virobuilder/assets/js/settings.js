(function() {
                // Toggle BYOK / Pro sections
                document.querySelectorAll('input[name="virobuilder_ai_mode"]').forEach(function(r) {
                    r.addEventListener('change', function() {
                        document.getElementById('viro-byok-section').style.display = this.value === 'byok' ? '' : 'none';
                        document.getElementById('viro-pro-section').style.display = this.value === 'pro' ? '' : 'none';
                    });
                });

                // Save handler
                var form = document.getElementById('virobuilder-ai-settings-form');
                var status = document.getElementById('virobuilder-ai-save-status');
                form.addEventListener('submit', async function(e) {
                    e.preventDefault();
                    status.textContent = 'Saving...';
                    status.style.color = '#64748b';
                    var fd = new FormData(form);
                    fd.append('action', 'virobuilder_ai_save_settings');
                    fd.append('_wpnonce', VBSET.nonce);
                    try {
                        var res = await fetch(ajaxurl, { method: 'POST', body: fd });
                        var data = await res.json();
                        if (data.success) {
                            status.textContent = '✓ Saved';
                            status.style.color = '#10b981';
                            setTimeout(function() { window.location.reload(); }, 800);
                        } else {
                            status.textContent = '✗ ' + (data.data?.message || 'Save failed');
                            status.style.color = '#ef4444';
                        }
                    } catch (err) {
                        status.textContent = '✗ Network error';
                        status.style.color = '#ef4444';
                    }
                });
            })();
