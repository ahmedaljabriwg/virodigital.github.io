<?php
/**
 * Forms module — captures form submissions on the frontend.
 *
 * Tier A scope: single-step forms, basic field types, submissions stored in DB,
 * email notifications, admin viewer. Multi-step + CRM coming in v1.1.
 *
 * @package ViroBuilder
 */

defined( 'ABSPATH' ) || exit;

class ViroBuilder_Forms {

    private static ?ViroBuilder_Forms $instance = null;
    const TABLE_VERSION = '1.0.0';

    public static function instance(): self {
        if ( null === self::$instance ) {
            self::$instance = new self();
        }
        return self::$instance;
    }

    private function __construct() {
        // Public AJAX endpoint (no auth required for form submissions)
        add_action( 'wp_ajax_virobuilder_form_submit', [ $this, 'handle_submission' ] );
        add_action( 'wp_ajax_nopriv_virobuilder_form_submit', [ $this, 'handle_submission' ] );

        // Admin AJAX endpoints
        add_action( 'wp_ajax_virobuilder_form_get_submissions', [ $this, 'ajax_get_submissions' ] );
        add_action( 'wp_ajax_virobuilder_form_delete_submission', [ $this, 'ajax_delete_submission' ] );
        add_action( 'wp_ajax_virobuilder_form_export_csv', [ $this, 'ajax_export_csv' ] );

        // Admin page
        add_action( 'admin_menu', [ $this, 'register_admin_page' ], 20 );

        // Check schema on admin init (creates tables if missing)
        add_action( 'admin_init', [ $this, 'maybe_install_schema' ] );
    }

    public static function submissions_table(): string {
        global $wpdb;
        return $wpdb->prefix . 'virobuilder_submissions';
    }

    /**
     * Install or migrate the submissions table.
     */
    public function maybe_install_schema(): void {
        $installed = get_option( 'virobuilder_forms_db_version', '' );
        if ( $installed === self::TABLE_VERSION ) return;

        global $wpdb;
        $table = self::submissions_table();
        $charset = $wpdb->get_charset_collate();

        $sql = "CREATE TABLE {$table} (
            id BIGINT(20) UNSIGNED NOT NULL AUTO_INCREMENT,
            form_id VARCHAR(64) NOT NULL DEFAULT '',
            form_name VARCHAR(255) NOT NULL DEFAULT '',
            post_id BIGINT(20) UNSIGNED NOT NULL DEFAULT 0,
            data LONGTEXT NOT NULL,
            ip_address VARCHAR(64) DEFAULT NULL,
            user_agent TEXT DEFAULT NULL,
            referrer VARCHAR(2048) DEFAULT NULL,
            is_spam TINYINT(1) NOT NULL DEFAULT 0,
            created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
            PRIMARY KEY (id),
            KEY form_id (form_id),
            KEY post_id (post_id),
            KEY created_at (created_at)
        ) {$charset};";

        require_once ABSPATH . 'wp-admin/includes/upgrade.php';
        dbDelta( $sql );

        update_option( 'virobuilder_forms_db_version', self::TABLE_VERSION );
    }

    /**
     * Handle a form submission from the frontend.
     *
     * Accepts POST data with:
     *   form_id: the widget's form_id (used to key submissions)
     *   form_name: human-readable name
     *   post_id: which page the form lives on
     *   honeypot: must be empty (anti-spam)
     *   fields: JSON-encoded array of {name, label, value}
     */
    public function handle_submission(): void {
        // Verify nonce — uses public nonce baked into the rendered form
        if ( ! wp_verify_nonce( sanitize_text_field( wp_unslash( $_POST['_wpnonce'] ?? '' ) ), 'virobuilder_form_submit' ) ) {
            wp_send_json_error( [ 'message' => 'Security check failed. Please refresh and try again.' ], 400 );
        }

        // Honeypot check — a hidden field that bots fill in. If non-empty, it's spam.
        $honeypot = sanitize_text_field( wp_unslash( $_POST['hp_field'] ?? '' ) );
        $is_spam = ! empty( $honeypot );

        $form_id   = sanitize_key( wp_unslash( $_POST['form_id'] ?? '' ) );
        $form_name = sanitize_text_field( wp_unslash( $_POST['form_name'] ?? '' ) );
        $post_id   = absint( $_POST['post_id'] ?? 0 );

        if ( empty( $form_id ) ) {
            wp_send_json_error( [ 'message' => 'Invalid form.' ], 400 );
        }

        // Parse fields
        // phpcs:ignore WordPress.Security.ValidatedSanitizedInput.InputNotSanitized -- JSON decoded then each field sanitized individually below
        $raw_fields = json_decode( wp_unslash( $_POST['fields'] ?? '[]' ), true );
        if ( ! is_array( $raw_fields ) ) {
            wp_send_json_error( [ 'message' => 'Invalid form data.' ], 400 );
        }

        // Sanitize each field
        $clean_fields = [];
        foreach ( $raw_fields as $field ) {
            if ( ! is_array( $field ) ) continue;
            $type  = sanitize_key( $field['type'] ?? 'text' );
            $name  = sanitize_key( $field['name'] ?? '' );
            $label = sanitize_text_field( $field['label'] ?? '' );
            $value = $field['value'] ?? '';

            // Sanitize value based on type
            switch ( $type ) {
                case 'email':
                    $value = sanitize_email( $value );
                    break;
                case 'textarea':
                    $value = sanitize_textarea_field( $value );
                    break;
                case 'url':
                    $value = esc_url_raw( $value );
                    break;
                case 'checkbox':
                    $value = ! empty( $value ) ? '1' : '0';
                    break;
                default:
                    if ( is_array( $value ) ) {
                        $value = array_map( 'sanitize_text_field', $value );
                    } else {
                        $value = sanitize_text_field( $value );
                    }
            }

            if ( empty( $name ) ) continue;
            $clean_fields[] = [
                'type'  => $type,
                'name'  => $name,
                'label' => $label,
                'value' => $value,
            ];
        }

        if ( empty( $clean_fields ) ) {
            wp_send_json_error( [ 'message' => 'No fields submitted.' ], 400 );
        }

        // Insert into DB
        global $wpdb;
        // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching -- inserting into custom plugin table
        $inserted = $wpdb->insert(
            self::submissions_table(),
            [
                'form_id'    => $form_id,
                'form_name'  => $form_name,
                'post_id'    => $post_id,
                'data'       => wp_json_encode( $clean_fields ),
                'ip_address' => $this->get_client_ip(),
                'user_agent' => substr( sanitize_text_field( wp_unslash( $_SERVER['HTTP_USER_AGENT'] ?? '' ) ), 0, 500 ),
                'referrer'   => esc_url_raw( wp_get_referer() ),
                'is_spam'    => $is_spam ? 1 : 0,
                'created_at' => current_time( 'mysql' ),
            ],
            [ '%s', '%s', '%d', '%s', '%s', '%s', '%s', '%d', '%s' ]
        );

        if ( ! $inserted ) {
            wp_send_json_error( [ 'message' => 'Could not save submission. Please try again.' ], 500 );
        }

        $submission_id = $wpdb->insert_id;

        // Send notification email (skip for spam)
        if ( ! $is_spam ) {
            $admin_email_override = sanitize_email( wp_unslash( $_POST['notify_email'] ?? '' ) );
            $this->send_notification_email( $form_name, $clean_fields, $post_id, $admin_email_override );
        }

        // Return success — let the client handle redirect/success message
        wp_send_json_success( [
            'id'      => $submission_id,
            'message' => 'Submission received.',
        ] );
    }

    private function get_client_ip(): string {
        // Respect common proxy headers if available
        foreach ( [ 'HTTP_CF_CONNECTING_IP', 'HTTP_X_FORWARDED_FOR', 'REMOTE_ADDR' ] as $key ) {
            if ( ! empty( $_SERVER[ $key ] ) ) {
                $ip = sanitize_text_field( wp_unslash( $_SERVER[ $key ] ) );
                if ( strpos( $ip, ',' ) !== false ) {
                    $ip = trim( explode( ',', $ip )[0] );
                }
                if ( filter_var( $ip, FILTER_VALIDATE_IP ) ) {
                    return $ip;
                }
            }
        }
        return '';
    }

    private function send_notification_email( string $form_name, array $fields, int $post_id, string $override = '' ): void {
        $to = ! empty( $override ) ? $override : get_option( 'admin_email' );
        if ( empty( $to ) ) return;

        $site_name = get_bloginfo( 'name' );
        $subject = sprintf( '[%s] New form submission: %s', $site_name, $form_name ?: 'Untitled' );

        $body  = "You have a new form submission.\n\n";
        $body .= "Form: " . ( $form_name ?: 'Untitled' ) . "\n";
        if ( $post_id ) {
            $body .= "Page: " . get_permalink( $post_id ) . "\n";
        }
        $body .= "Time: " . current_time( 'mysql' ) . "\n\n";
        $body .= "--- Submission ---\n\n";

        foreach ( $fields as $field ) {
            $label = $field['label'] ?: $field['name'];
            $value = is_array( $field['value'] ) ? implode( ', ', $field['value'] ) : $field['value'];
            $body .= $label . ":\n" . $value . "\n\n";
        }

        $body .= "\n--- \nSent from " . $site_name . " via ViroBuilder Forms.";

        wp_mail( $to, $subject, $body );
    }

    /**
     * Register the admin "Submissions" page.
     */
    public function register_admin_page(): void {
        add_submenu_page(
            'virobuilder-dashboard',
            __( 'Form Submissions', 'virobuilder' ),
            __( 'Submissions', 'virobuilder' ),
            'edit_posts',
            'virobuilder-submissions',
            [ $this, 'render_admin_page' ]
        );
    }

    public function render_admin_page(): void {
        global $wpdb;
        $table = self::submissions_table();

        // phpcs:disable WordPress.Security.NonceVerification.Recommended -- read-only admin list view; no state is changed by these query-string filters
        // Pagination
        $per_page = 25;
        $page = max( 1, intval( wp_unslash( $_GET['paged'] ?? 1 ) ) );
        $offset = ( $page - 1 ) * $per_page;

        // Filter by form_id if specified
        $filter_form_id = sanitize_key( wp_unslash( $_GET['form_id'] ?? '' ) );
        // phpcs:enable WordPress.Security.NonceVerification.Recommended

        $where = "WHERE is_spam = 0";
        if ( ! empty( $filter_form_id ) ) {
            $where .= $wpdb->prepare( " AND form_id = %s", $filter_form_id );
        }

        // phpcs:disable WordPress.DB.PreparedSQL.InterpolatedNotPrepared, WordPress.DB.PreparedSQL.NotPrepared, WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching, PluginCheck.Security.DirectDB.UnescapedDBParameter -- custom plugin table; $where uses $wpdb->prepare, $per_page/$offset are integers
        $total = (int) $wpdb->get_var( "SELECT COUNT(*) FROM `{$table}` {$where}" );
        $submissions = $wpdb->get_results( "SELECT * FROM `{$table}` {$where} ORDER BY created_at DESC LIMIT {$per_page} OFFSET {$offset}" );

        // Group counts per form for the sidebar
        $form_counts = $wpdb->get_results( "SELECT form_id, form_name, COUNT(*) as count FROM `{$table}` WHERE is_spam = 0 GROUP BY form_id ORDER BY count DESC", ARRAY_A );
        // phpcs:enable WordPress.DB.PreparedSQL.InterpolatedNotPrepared, WordPress.DB.PreparedSQL.NotPrepared, WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching, PluginCheck.Security.DirectDB.UnescapedDBParameter

        ?>
        <div class="wrap">
            <h1 style="display:flex;align-items:center;gap:12px;">
                <?php esc_html_e( 'Form Submissions', 'virobuilder' ); ?>
                <?php if ( ! empty( $form_counts ) ): ?>
                    <a href="#" id="virobuilder-export-csv" class="page-title-action" data-form-id="<?php echo esc_attr( $filter_form_id ); ?>">
                        <?php esc_html_e( 'Export CSV', 'virobuilder' ); ?>
                    </a>
                <?php endif; ?>
            </h1>

            <?php if ( empty( $submissions ) && empty( $filter_form_id ) ): ?>
                <div style="background:#ffffff;border:1px solid #e2e5ea;border-radius:8px;padding:48px;text-align:center;margin-top:20px;">
                    <h2 style="margin-top:0;color:#0f172a;"><?php esc_html_e( 'No submissions yet', 'virobuilder' ); ?></h2>
                    <p style="color:#64748b;max-width:480px;margin:0 auto 16px;">
                        <?php esc_html_e( 'When visitors submit a form on your site, their submissions will appear here. To add a form to a page, edit the page in ViroBuilder and drag the Form widget onto your layout.', 'virobuilder' ); ?>
                    </p>
                </div>
            <?php else: ?>
                <div style="display:grid;grid-template-columns:220px 1fr;gap:20px;margin-top:20px;">
                    <!-- Sidebar: forms list -->
                    <aside style="background:#ffffff;border:1px solid #e2e5ea;border-radius:8px;padding:12px;height:fit-content;">
                        <h3 style="margin:0 0 10px;font-size:12px;text-transform:uppercase;letter-spacing:0.5px;color:#94a3b8;">
                            <?php esc_html_e( 'Forms', 'virobuilder' ); ?>
                        </h3>
                        <ul style="margin:0;padding:0;list-style:none;">
                            <li>
                                <a href="?page=virobuilder-submissions" style="display:flex;justify-content:space-between;align-items:center;padding:8px 10px;text-decoration:none;border-radius:6px;<?php echo empty( $filter_form_id ) ? 'background:#0f3460;color:#ffffff;' : 'color:#475569;'; ?>">
                                    <span><?php esc_html_e( 'All', 'virobuilder' ); ?></span>
                                    <span style="font-size:11px;opacity:0.7;"><?php echo (int) $total; ?></span>
                                </a>
                            </li>
                            <?php foreach ( $form_counts as $fc ): ?>
                                <li>
                                    <a href="?page=virobuilder-submissions&form_id=<?php echo esc_attr( $fc['form_id'] ); ?>" style="display:flex;justify-content:space-between;align-items:center;padding:8px 10px;text-decoration:none;border-radius:6px;<?php echo $filter_form_id === $fc['form_id'] ? 'background:#0f3460;color:#ffffff;' : 'color:#475569;'; ?>">
                                        <span><?php echo esc_html( $fc['form_name'] ?: $fc['form_id'] ); ?></span>
                                        <span style="font-size:11px;opacity:0.7;"><?php echo (int) $fc['count']; ?></span>
                                    </a>
                                </li>
                            <?php endforeach; ?>
                        </ul>
                    </aside>

                    <!-- Submissions table -->
                    <div>
                        <?php if ( empty( $submissions ) ): ?>
                            <div style="background:#ffffff;border:1px solid #e2e5ea;border-radius:8px;padding:24px;text-align:center;color:#64748b;">
                                <?php esc_html_e( 'No submissions match the current filter.', 'virobuilder' ); ?>
                            </div>
                        <?php else: ?>
                            <div style="background:#ffffff;border:1px solid #e2e5ea;border-radius:8px;overflow:hidden;">
                                <table class="wp-list-table widefat striped" style="margin:0;border:none;">
                                    <thead>
                                        <tr>
                                            <th style="width:140px;"><?php esc_html_e( 'Date', 'virobuilder' ); ?></th>
                                            <th><?php esc_html_e( 'Form', 'virobuilder' ); ?></th>
                                            <th><?php esc_html_e( 'Submission', 'virobuilder' ); ?></th>
                                            <th style="width:90px;text-align:right;"><?php esc_html_e( 'Actions', 'virobuilder' ); ?></th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <?php foreach ( $submissions as $s ): ?>
                                            <tr>
                                                <td style="vertical-align:top;">
                                                    <?php echo esc_html( mysql2date( 'M j, Y H:i', $s->created_at ) ); ?>
                                                </td>
                                                <td style="vertical-align:top;">
                                                    <strong><?php echo esc_html( $s->form_name ?: $s->form_id ); ?></strong>
                                                    <?php if ( $s->post_id ): ?>
                                                        <br><a href="<?php echo esc_url( get_permalink( $s->post_id ) ); ?>" target="_blank" style="font-size:11px;color:#64748b;text-decoration:none;">
                                                            <?php echo esc_html( get_the_title( $s->post_id ) ?: 'Page #' . $s->post_id ); ?> ↗
                                                        </a>
                                                    <?php endif; ?>
                                                </td>
                                                <td style="vertical-align:top;">
                                                    <?php
                                                    $fields = json_decode( $s->data, true );
                                                    if ( is_array( $fields ) ):
                                                        foreach ( $fields as $f ):
                                                            $val = is_array( $f['value'] ) ? implode( ', ', $f['value'] ) : $f['value'];
                                                            if ( strlen( $val ) > 100 ) $val = substr( $val, 0, 100 ) . '…';
                                                            ?>
                                                            <div style="margin-bottom:4px;">
                                                                <span style="color:#94a3b8;font-size:12px;"><?php echo esc_html( $f['label'] ?: $f['name'] ); ?>:</span>
                                                                <span style="color:#0f172a;"><?php echo esc_html( $val ); ?></span>
                                                            </div>
                                                            <?php
                                                        endforeach;
                                                    endif;
                                                    ?>
                                                </td>
                                                <td style="vertical-align:top;text-align:right;">
                                                    <a href="#" class="virobuilder-delete-submission" data-id="<?php echo (int) $s->id; ?>" style="color:#ef4444;text-decoration:none;font-size:12px;">
                                                        <?php esc_html_e( 'Delete', 'virobuilder' ); ?>
                                                    </a>
                                                </td>
                                            </tr>
                                        <?php endforeach; ?>
                                    </tbody>
                                </table>
                            </div>

                            <?php
                            // Pagination
                            $total_pages = ceil( $total / $per_page );
                            if ( $total_pages > 1 ):
                                ?>
                                <div style="margin-top:16px;text-align:center;">
                                    <?php
                                    $base = '?page=virobuilder-submissions' . ( $filter_form_id ? '&form_id=' . $filter_form_id : '' );
                                    for ( $p = 1; $p <= $total_pages; $p++ ):
                                        ?>
                                        <a href="<?php echo esc_url( $base . '&paged=' . $p ); ?>" style="display:inline-block;padding:6px 12px;margin:0 2px;background:<?php echo $p === $page ? '#0f3460' : '#ffffff'; ?>;color:<?php echo $p === $page ? '#ffffff' : '#475569'; ?>;text-decoration:none;border:1px solid #e2e5ea;border-radius:6px;font-size:13px;">
                                            <?php echo (int) $p; ?>
                                        </a>
                                        <?php
                                    endfor;
                                    ?>
                                </div>
                            <?php endif; ?>
                        <?php endif; ?>
                    </div>
                </div>
            <?php endif; ?>
        </div>

        <?php
    }

    public function ajax_delete_submission(): void {
        check_ajax_referer( 'virobuilder_forms_admin' );

        if ( ! current_user_can( 'edit_posts' ) ) {
            wp_send_json_error( [ 'message' => 'Permission denied' ], 403 );
        }

        $id = absint( $_POST['id'] ?? 0 );
        if ( ! $id ) wp_send_json_error( [ 'message' => 'Invalid id' ], 400 );

        global $wpdb;
        // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching -- deleting from custom plugin table
        $result = $wpdb->delete( self::submissions_table(), [ 'id' => $id ], [ '%d' ] );

        if ( $result === false ) {
            wp_send_json_error( [ 'message' => 'Could not delete' ], 500 );
        }
        wp_send_json_success();
    }

    public function ajax_get_submissions(): void {
        check_ajax_referer( 'virobuilder_forms_admin' );

        if ( ! current_user_can( 'edit_posts' ) ) {
            wp_send_json_error( [ 'message' => 'Permission denied' ], 403 );
        }

        global $wpdb;
        $table = self::submissions_table();
        // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching -- custom plugin table; name prepared with %i
        $rows = $wpdb->get_results( $wpdb->prepare( "SELECT * FROM %i WHERE is_spam = 0 ORDER BY created_at DESC LIMIT 100", $table ) );
        wp_send_json_success( [ 'submissions' => $rows ] );
    }

    public function ajax_export_csv(): void {
        if ( ! wp_verify_nonce( sanitize_text_field( wp_unslash( $_GET['_wpnonce'] ?? '' ) ), 'virobuilder_forms_admin' ) ) {
            wp_die( 'Security check failed.' );
        }
        if ( ! current_user_can( 'edit_posts' ) ) {
            wp_die( 'Permission denied.' );
        }

        global $wpdb;
        $form_id = sanitize_key( $_GET['form_id'] ?? '' );

        $where = "WHERE is_spam = 0";
        if ( ! empty( $form_id ) ) {
            $where .= $wpdb->prepare( " AND form_id = %s", $form_id );
        }
        $table = self::submissions_table();
        // phpcs:ignore WordPress.DB.PreparedSQL.NotPrepared, WordPress.DB.PreparedSQL.InterpolatedNotPrepared, WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching, PluginCheck.Security.DirectDB.UnescapedDBParameter -- custom plugin table; $where built with $wpdb->prepare above
        $rows = $wpdb->get_results( "SELECT * FROM `{$table}` {$where} ORDER BY created_at DESC" );

        // Collect all unique field labels across all submissions so the CSV has consistent columns
        $all_labels = [];
        foreach ( $rows as $row ) {
            $fields = json_decode( $row->data, true );
            if ( ! is_array( $fields ) ) continue;
            foreach ( $fields as $f ) {
                $label = $f['label'] ?: $f['name'];
                if ( ! in_array( $label, $all_labels, true ) ) {
                    $all_labels[] = $label;
                }
            }
        }

        // Send CSV headers
        $filename = 'virobuilder-submissions-' . gmdate( 'Y-m-d' ) . '.csv';
        header( 'Content-Type: text/csv; charset=utf-8' );
        header( 'Content-Disposition: attachment; filename="' . $filename . '"' );

        // Build CSV in memory (avoids direct filesystem writes); UTF-8 BOM for Excel.
        $csv = "\xEF\xBB\xBF";
        $header_row = array_merge( [ 'Date', 'Form', 'Page' ], $all_labels );
        $csv .= virobuilder_csv_row( $header_row );

        // Data rows
        foreach ( $rows as $row ) {
            $fields = json_decode( $row->data, true );
            $field_map = [];
            if ( is_array( $fields ) ) {
                foreach ( $fields as $f ) {
                    $label = $f['label'] ?: $f['name'];
                    $field_map[ $label ] = is_array( $f['value'] ) ? implode( ', ', $f['value'] ) : $f['value'];
                }
            }
            $line = [
                $row->created_at,
                $row->form_name ?: $row->form_id,
                $row->post_id ? get_the_title( $row->post_id ) : '',
            ];
            foreach ( $all_labels as $label ) {
                $line[] = $field_map[ $label ] ?? '';
            }
            $csv .= virobuilder_csv_row( $line );
        }

        // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- raw CSV file download, not HTML
        echo $csv;
        exit;
    }
}

/**
 * Build one CSV line (RFC-4180 quoting) without using filesystem handles.
 */
if ( ! function_exists( 'virobuilder_csv_row' ) ) {
    function virobuilder_csv_row( array $fields ): string {
        $escaped = array_map( function ( $v ) {
            $v = (string) $v;
            if ( preg_match( '/[",\r\n]/', $v ) ) {
                $v = '"' . str_replace( '"', '""', $v ) . '"';
            }
            return $v;
        }, $fields );
        return implode( ',', $escaped ) . "\r\n";
    }
}

ViroBuilder_Forms::instance();
