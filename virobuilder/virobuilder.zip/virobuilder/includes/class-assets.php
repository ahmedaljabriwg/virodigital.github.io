<?php
/**
 * Central asset registration for ViroBuilder admin screens and the
 * admin-bar button. All CSS/JS that was previously printed inline is
 * registered here and enqueued on the appropriate screen, with dynamic
 * values passed through wp_localize_script().
 *
 * @package ViroBuilder
 */

defined( 'ABSPATH' ) || exit;

class ViroBuilder_Assets {

	private static ?ViroBuilder_Assets $instance = null;

	public static function instance(): ViroBuilder_Assets {
		if ( null === self::$instance ) {
			self::$instance = new self();
		}
		return self::$instance;
	}

	private function __construct() {
		add_action( 'wp_enqueue_scripts', array( $this, 'enqueue_admin_bar_style' ) );
		add_action( 'admin_enqueue_scripts', array( $this, 'enqueue_admin' ) );
	}

	/**
	 * Small stylesheet for the front-end admin-bar button.
	 */
	public function enqueue_admin_bar_style(): void {
		if ( is_admin_bar_showing() && current_user_can( 'edit_posts' ) ) {
			wp_enqueue_style(
				'virobuilder-admin-bar',
				VIROBUILDER_ASSETS_URL . 'css/admin-bar.css',
				array(),
				VIROBUILDER_VERSION
			);
		}
	}

	/**
	 * Enqueue the right assets for each ViroBuilder admin screen.
	 *
	 * @param string $hook Current admin page hook suffix.
	 */
	public function enqueue_admin( string $hook ): void {

		// Admin-bar button styling, wherever the bar is shown in admin.
		if ( is_admin_bar_showing() && current_user_can( 'edit_posts' ) ) {
			wp_enqueue_style(
				'virobuilder-admin-bar',
				VIROBUILDER_ASSETS_URL . 'css/admin-bar.css',
				array(),
				VIROBUILDER_VERSION
			);
		}

		// Dashboard / welcome hub (top-level page only).
		if ( 'toplevel_page_virobuilder-dashboard' === $hook ) {
			wp_enqueue_style(
				'virobuilder-welcome',
				VIROBUILDER_ASSETS_URL . 'css/welcome.css',
				array(),
				VIROBUILDER_VERSION
			);
		}

		// Create-new-page screen.
		if ( false !== strpos( $hook, 'virobuilder-create' ) ) {
			wp_enqueue_style(
				'virobuilder-create',
				VIROBUILDER_ASSETS_URL . 'css/create.css',
				array(),
				VIROBUILDER_VERSION
			);
			wp_enqueue_script(
				'virobuilder-create',
				VIROBUILDER_ASSETS_URL . 'js/create.js',
				array(),
				VIROBUILDER_VERSION,
				true
			);
			wp_localize_script(
				'virobuilder-create',
				'VBCREATE',
				array(
					'ajax'  => admin_url( 'admin-ajax.php' ),
					'admin' => admin_url( 'admin.php' ),
					'nonce' => wp_create_nonce( 'virobuilder_nonce' ),
				)
			);
		}

		// AI Settings screen.
		if ( false !== strpos( $hook, 'virobuilder-ai-settings' ) ) {
			wp_enqueue_script(
				'virobuilder-settings',
				VIROBUILDER_ASSETS_URL . 'js/settings.js',
				array(),
				VIROBUILDER_VERSION,
				true
			);
			wp_localize_script(
				'virobuilder-settings',
				'VBSET',
				array(
					'nonce' => wp_create_nonce( 'virobuilder_ai_settings' ),
				)
			);
		}

		// Form submissions screen.
		if ( false !== strpos( $hook, 'virobuilder-submissions' ) ) {
			wp_enqueue_script(
				'virobuilder-submissions',
				VIROBUILDER_ASSETS_URL . 'js/submissions.js',
				array(),
				VIROBUILDER_VERSION,
				true
			);
			wp_localize_script(
				'virobuilder-submissions',
				'VBSUBS',
				array(
					'nonce' => wp_create_nonce( 'virobuilder_forms_admin' ),
				)
			);
		}

		// Post / page list screens: the "Create with ViroBuilder AI" button.
		if ( 'edit.php' === $hook ) {
			$screen = get_current_screen();
			if ( $screen && in_array( $screen->post_type, array( 'page', 'post' ), true ) ) {
				wp_enqueue_script(
					'virobuilder-heading',
					VIROBUILDER_ASSETS_URL . 'js/heading.js',
					array(),
					VIROBUILDER_VERSION,
					true
				);
				wp_localize_script(
					'virobuilder-heading',
					'VBHEAD',
					array(
						'createUrl' => admin_url( 'admin.php?page=virobuilder-create' ),
					)
				);
			}
		}
	}
}

ViroBuilder_Assets::instance();
