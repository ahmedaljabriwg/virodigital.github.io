<?php
if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

class ViroBuilder {

    private static ?ViroBuilder $instance = null;
    public ViroBuilder_Editor $editor;

    public static function instance(): ViroBuilder {
        if ( null === self::$instance ) {
            self::$instance = new self();
        }
        return self::$instance;
    }

    private function __construct() {
        $this->editor = new ViroBuilder_Editor();

        add_action( 'init', [ $this, 'register_post_types' ] );
        add_filter( 'post_row_actions', [ $this, 'add_edit_link' ], 10, 2 );
        add_filter( 'page_row_actions', [ $this, 'add_edit_link' ], 10, 2 );
        add_action( 'admin_bar_menu', [ $this, 'add_admin_bar_button' ], 100 );
    }

    /**
     * Register the template custom post type for saved templates.
     */
    public function register_post_types(): void {
        register_post_type( 'viro_template', [
            'labels' => [
                'name'          => __( 'ViroBuilder Templates', 'virobuilder' ),
                'singular_name' => __( 'Template', 'virobuilder' ),
            ],
            'public'       => false,
            'show_ui'      => false,
            'supports'     => [ 'title' ],
            'show_in_rest' => false,
        ]);
    }

    /**
     * Add "Edit with ViroBuilder" link in the posts/pages list table.
     */
    public function add_edit_link( array $actions, WP_Post $post ): array {
        if ( ! current_user_can( 'edit_post', $post->ID ) ) {
            return $actions;
        }

        // Only show on AI-designed pages (full HTML documents).
        if ( ! $this->is_designer_page( $post->ID ) ) {
            return $actions;
        }

        $editor_url = $this->get_editor_url( $post->ID );
        $actions['virobuilder'] = sprintf(
            '<a href="%s" style="color: #818cf8; font-weight: 600;">%s</a>',
            esc_url( $editor_url ),
            __( 'Edit with ViroBuilder', 'virobuilder' )
        );

        return $actions;
    }

    /**
     * Whether a post is an AI-designed ViroBuilder page.
     */
    public function is_designer_page( int $post_id ): bool {
        if ( get_post_meta( $post_id, '_virobuilder_designer_page', true ) === '1' ) {
            return true;
        }
        $post = get_post( $post_id );
        return $post && (bool) preg_match( '/^\s*(<!DOCTYPE|<html)/i', $post->post_content );
    }

    /**
     * Get the chat-editor URL for an AI-designed page.
     */
    public function get_editor_url( int $post_id ): string {
        return add_query_arg([
            'page'    => 'virobuilder-designer-edit',
            'post_id' => $post_id,
        ], admin_url( 'admin.php' ));
    }

    /**
     * Post types the builder supports.
     */
    public function get_supported_post_types(): array {
        return apply_filters( 'virobuilder/supported_post_types', [ 'page', 'post' ] );
    }

    /**
     * Get the default element structure for a new page.
     */
    public static function get_default_data(): array {
        return [
            'version'  => VIROBUILDER_VERSION,
            'elements' => [],
        ];
    }

    /**
     * Add ViroBuilder entries to the admin bar:
     *  - A global "New ViroBuilder Page" under the + New menu (everywhere)
     *  - An "Edit with ViroBuilder" button on single AI-designed pages
     */
    public function add_admin_bar_button( WP_Admin_Bar $admin_bar ): void {
        if ( ! is_admin_bar_showing() || ! current_user_can( 'edit_posts' ) ) {
            return;
        }

        $create_url = admin_url( 'admin.php?page=virobuilder-create' );

        // Under the WordPress "+ New" menu
        $admin_bar->add_node([
            'id'     => 'virobuilder-new-page',
            'parent' => 'new-content',
            'title'  => 'ViroBuilder Page',
            'href'   => $create_url,
        ]);

        // Per-page edit button (front-end or admin, on AI-designed pages)
        if ( is_singular() ) {
            $post = get_queried_object();
            if ( $post instanceof WP_Post
                && current_user_can( 'edit_post', $post->ID )
                && $this->is_designer_page( $post->ID ) ) {
                $admin_bar->add_node([
                    'id'    => 'virobuilder-edit',
                    'title' => '<span class="ab-icon virobuilder-ab-icon"></span><span class="ab-label">Edit with ViroBuilder</span>',
                    'href'  => $this->get_editor_url( $post->ID ),
                    'meta'  => [
                        'class' => 'virobuilder-admin-bar-btn',
                        'title' => 'Edit this page with ViroBuilder',
                    ],
                ]);
            }
        }
    }

}
