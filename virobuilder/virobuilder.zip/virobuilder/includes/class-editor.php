<?php
if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

class ViroBuilder_Editor {

    public function __construct() {
        add_action( 'admin_menu', [ $this, 'register_editor_page' ] );
        add_action( 'admin_enqueue_scripts', [ $this, 'enqueue_admin_assets' ] );

        // Add the "Edit with ViroBuilder" button to the classic editor (designer pages only)
        add_action( 'edit_form_after_title', [ $this, 'add_edit_button' ] );

        // Add a "Create with AI" button on the Pages/Posts list screens

        // One-time redirect to the welcome screen after activation
        add_action( 'admin_init', [ $this, 'maybe_activation_redirect' ] );

        // AJAX to dismiss the welcome screen
        add_action( 'wp_ajax_virobuilder_dismiss_welcome', [ $this, 'ajax_dismiss_welcome' ] );
    }


    /**
     * Redirect to the welcome screen once, right after activation.
     */
    public function maybe_activation_redirect(): void {
        if ( ! get_transient( 'virobuilder_activation_redirect' ) ) {
            return;
        }
        delete_transient( 'virobuilder_activation_redirect' );

        // Don't redirect during AJAX, cron, bulk actions, or for users who can't edit.
        if ( wp_doing_ajax() || ! current_user_can( 'edit_posts' ) ) {
            return;
        }
        // phpcs:ignore WordPress.Security.NonceVerification.Recommended -- read-only check of a core WP flag
        if ( isset( $_GET['activate-multi'] ) ) {
            return;
        }

        wp_safe_redirect( admin_url( 'admin.php?page=virobuilder-dashboard&welcome=1' ) );
        exit;
    }

    /**
     * Mark the welcome screen as dismissed for this user.
     */
    public function ajax_dismiss_welcome(): void {
        check_ajax_referer( 'virobuilder_welcome' );
        if ( ! current_user_can( 'edit_posts' ) ) {
            wp_send_json_error( [ 'message' => 'Permission denied' ], 403 );
        }
        update_user_meta( get_current_user_id(), 'virobuilder_welcome_dismissed', 1 );
        wp_send_json_success();
    }

    /**
     * Compute the getting-started checklist state from real data.
     */
    private function get_onboarding_state(): array {
        global $wpdb;

        // Has the user added an Anthropic API key?
        $has_api_key = ! empty( get_option( 'virobuilder_ai_api_key', '' ) );

        // Has any page been edited/saved with ViroBuilder? We detect by the marker
        // comment our AJAX save writes into post_content.
        // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching -- one read-only dashboard stat
        $built_count = (int) $wpdb->get_var(
            "SELECT COUNT(*) FROM {$wpdb->posts}
             WHERE post_status IN ('publish','draft','private')
             AND post_content LIKE '%wp:html%virobuilder%'"
        );
        // Fallback: detect our rendered marker class
        if ( $built_count === 0 ) {
            // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching -- one read-only dashboard stat
            $built_count = (int) $wpdb->get_var(
                "SELECT COUNT(*) FROM {$wpdb->posts}
                 WHERE post_status IN ('publish','draft','private')
                 AND post_content LIKE '%viro-section%'"
            );
        }
        $has_built_page = $built_count > 0;

        // Has any form submission been captured?
        $has_submission = false;
        if ( class_exists( 'ViroBuilder_Forms' ) ) {
            $table = ViroBuilder_Forms::submissions_table();
            // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching -- one-time table-existence check for a dashboard stat
            $exists = $wpdb->get_var( $wpdb->prepare( 'SHOW TABLES LIKE %s', $table ) );
            if ( $exists ) {
                // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching, PluginCheck.Security.DirectDB.UnescapedDBParameter -- prepared with %i identifier placeholder
                $has_submission = (int) $wpdb->get_var( $wpdb->prepare( "SELECT COUNT(*) FROM %i", $table ) ) > 0;
            }
        }

        return [
            'has_api_key'    => $has_api_key,
            'has_built_page' => $has_built_page,
            'has_submission' => $has_submission,
        ];
    }

    /**
     * Register the admin menu.
     *
     * We register a real top-level "ViroBuilder" menu (a dashboard landing page) so that
     * submenu pages (Submissions, AI Settings) have a parent to attach to and appear in
     * the sidebar. The actual page editor remains a separate hidden page reached via the
     * "Edit with ViroBuilder" button on each page/post.
     */
    public function register_editor_page(): void {
        // Top-level ViroBuilder menu — landing/dashboard page.
        // V-sparkle logo mark as admin menu icon
        $menu_icon = 'data:image/svg+xml;base64,' . base64_encode(
            '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 40 44" fill="none">'
            . '<path d="M6 40L20 6L34 40" stroke="#a7aaad" stroke-width="3" stroke-linecap="round" stroke-linejoin="round"/>'
            . '<circle cx="20" cy="5" r="3.5" fill="#22d3ee"/>'
            . '</svg>'
        );

        add_menu_page(
            __( 'ViroBuilder', 'virobuilder' ),
            __( 'ViroBuilder', 'virobuilder' ),
            'edit_posts',
            'virobuilder-dashboard',
            [ $this, 'render_dashboard_page' ],
            $menu_icon,
            58
        );
    }

    /**
     * Render the ViroBuilder dashboard / welcome hub.
     */
    public function render_dashboard_page(): void {
        $state = $this->get_onboarding_state();
        $steps_done = (int) $state['has_api_key'] + (int) $state['has_built_page'];
        // "Activated" always counts as done, so 3 total steps.
        $total_steps = 3;
        $completed = 1 + $steps_done; // +1 for activation
        $pct = (int) round( ( $completed / $total_steps ) * 100 );

        $pages_url     = admin_url( 'admin.php?page=virobuilder-create' );
        $ai_url        = admin_url( 'admin.php?page=virobuilder-ai-settings' );
        $subs_url      = admin_url( 'admin.php?page=virobuilder-submissions' );
        $welcome_nonce = wp_create_nonce( 'virobuilder_welcome' );
        ?>
        <div class="wrap virobuilder-welcome">

            <div class="vb-hero">
                <h1><span class="vb-logo"><svg viewBox="0 0 40 44" fill="none"><path d="M6 40L20 6L34 40" stroke="#818cf8" stroke-width="3" stroke-linecap="round" stroke-linejoin="round"/><circle cx="20" cy="5" r="3.5" fill="#22d3ee"/></svg></span> <?php esc_html_e( 'Welcome to ViroBuilder', 'virobuilder' ); ?>
                    <span style="font-size:12px;font-weight:600;background:rgba(129,140,248,.2);color:#a5b4fc;padding:3px 10px;border-radius:20px;margin-left:8px;">v<?php echo esc_html( VIROBUILDER_VERSION ); ?></span>
                </h1>
                <p><?php esc_html_e( 'Not a page builder. A page designer. Generate professional landing pages with AI, edit with chat, and publish in minutes.', 'virobuilder' ); ?></p>
                <div class="vb-progress-wrap">
                    <div class="vb-progress-track"><div class="vb-progress-bar" style="width:<?php echo esc_attr( $pct ); ?>%;"></div></div>
                    <div class="vb-progress-label"><?php
                        /* translators: 1: completion percentage, 2: completed step count, 3: total step count */
                        echo esc_html( sprintf( __( 'Setup %1$d%% complete · %2$d of %3$d steps', 'virobuilder' ), $pct, $completed, $total_steps ) ); ?></div>
                </div>
            </div>

            <div class="vb-cards">
                <div class="vb-card">
                    <div class="vb-card-icon" style="background:linear-gradient(135deg,#6366f1,#8b5cf6);color:#fff;">
                        <svg width="22" height="22" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><polygon points="13 2 3 14 12 14 11 22 21 10 12 10 13 2"/></svg>
                    </div>
                    <h2><?php esc_html_e( 'Create a new page', 'virobuilder' ); ?></h2>
                    <p><?php esc_html_e( 'Describe your business and ViroBuilder designs a complete, bespoke landing page in minutes — photos, copy, and SEO included.', 'virobuilder' ); ?></p>
                    <a class="vb-btn vb-btn-primary" href="<?php echo esc_url( $pages_url ); ?>"><?php esc_html_e( '✦ Create New Page', 'virobuilder' ); ?></a>
                </div>
                <div class="vb-card">
                    <div class="vb-card-icon" style="background:rgba(129,140,248,0.1);color:#111111;">
                        <svg width="22" height="22" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M21 15a2 2 0 0 1-2 2H7l-4 4V5a2 2 0 0 1 2-2h14a2 2 0 0 1 2 2z"/></svg>
                    </div>
                    <h2><?php esc_html_e( 'Edit by chat & click', 'virobuilder' ); ?></h2>
                    <p><?php esc_html_e( 'Refine any page in the visual editor — click elements to change text, photos, colors, and links, or chat with the AI for bigger changes.', 'virobuilder' ); ?></p>
                    <a class="vb-btn vb-btn-ghost" href="<?php echo esc_url( admin_url( 'edit.php?post_type=page' ) ); ?>"><?php esc_html_e( 'Go to My Pages', 'virobuilder' ); ?></a>
                </div>
                <div class="vb-card">
                    <div class="vb-card-icon" style="background:rgba(16,185,129,0.12);color:#10b981;">
                        <svg width="22" height="22" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M4 4h16v16H4z"/><path d="m4 7 8 5 8-5"/></svg>
                    </div>
                    <h2><?php esc_html_e( 'Collect leads', 'virobuilder' ); ?></h2>
                    <p><?php esc_html_e( 'Forms on your generated pages capture enquiries automatically — saved here and emailed to you.', 'virobuilder' ); ?></p>
                    <a class="vb-btn vb-btn-ghost" href="<?php echo esc_url( $subs_url ); ?>"><?php esc_html_e( 'View Submissions', 'virobuilder' ); ?></a>
                </div>
            </div>

            <div class="vb-checklist">
                <h2><?php esc_html_e( 'Getting started', 'virobuilder' ); ?></h2>
                <p><?php esc_html_e( 'Three steps to your first AI-designed page.', 'virobuilder' ); ?></p>

                <?php
                $this->render_step( true, __( 'Install & activate ViroBuilder', 'virobuilder' ), __( 'Done — you’re here!', 'virobuilder' ) );

                $this->render_step(
                    $state['has_api_key'],
                    __( 'Add your Anthropic API key', 'virobuilder' ),
                    sprintf(
                        /* translators: %s: link to AI settings */
                        __( 'Required to generate pages. %s', 'virobuilder' ),
                        '<a href="' . esc_url( $ai_url ) . '">' . esc_html__( 'Open AI Settings →', 'virobuilder' ) . '</a>'
                    )
                );

                $this->render_step(
                    $state['has_built_page'],
                    __( 'Create your first page', 'virobuilder' ),
                    sprintf(
                        /* translators: %s: link to create page */
                        __( 'Describe a business and let the AI design it. %s', 'virobuilder' ),
                        '<a href="' . esc_url( $pages_url ) . '">' . esc_html__( 'Create New Page →', 'virobuilder' ) . '</a>'
                    )
                );
                ?>
            </div>
        </div>
        <?php
    }

    /**
     * Render a single checklist step.
     */
    private function render_step( bool $done, string $title, string $desc ): void {
        ?>
        <div class="vb-step <?php echo $done ? 'is-done' : ''; ?>">
            <div class="vb-step-check <?php echo $done ? 'done' : 'todo'; ?>">
                <?php if ( $done ) : ?>
                    <svg width="13" height="13" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="3" stroke-linecap="round" stroke-linejoin="round"><polyline points="20 6 9 17 4 12"/></svg>
                <?php endif; ?>
            </div>
            <div class="vb-step-body">
                <h3><?php echo esc_html( $title ); ?></h3>
                <p><?php echo wp_kses_post( $desc ); ?></p>
            </div>
        </div>
        <?php
    }

    /**
     * Check if we're on the ViroBuilder editor page.
     */
    public function is_editor_page(): bool {
        // phpcs:ignore WordPress.Security.NonceVerification.Recommended -- read-only admin page detection
        return isset( $_GET['page'] ) && sanitize_key( wp_unslash( $_GET['page'] ) ) === 'virobuilder';
    }

    /**
     * Get the post being edited.
     */
    public function get_current_post_id(): int {
        // phpcs:ignore WordPress.Security.NonceVerification.Recommended -- read-only id read; capability enforced where used
        return isset( $_GET['post_id'] ) ? absint( wp_unslash( $_GET['post_id'] ) ) : 0;
    }

    /**
     * Add body class on editor page for full-screen styling.
     */
    public function add_body_class( string $classes ): string {
        if ( $this->is_editor_page() ) {
            $classes .= ' virobuilder-editor-active';
        }
        return $classes;
    }

    /**
     * Enqueue small admin-wide styles (just for the edit button).
     */
    public function enqueue_admin_assets( string $hook ): void {
        if ( ! in_array( $hook, [ 'post.php', 'post-new.php' ], true ) ) {
            return;
        }

        global $post;
        if ( ! $post || ! in_array( $post->post_type, virobuilder_init()->get_supported_post_types(), true ) ) {
            return;
        }

        wp_add_inline_style( 'wp-admin', '
            .virobuilder-edit-btn {
                display: inline-flex;
                align-items: center;
                gap: 8px;
                padding: 8px 20px;
                background: #111111;
                color: #fff !important;
                border: none;
                border-radius: 6px;
                font-size: 14px;
                font-weight: 600;
                text-decoration: none !important;
                cursor: pointer;
                transition: all 0.2s;
                margin: 10px 0;
            }
            .virobuilder-edit-btn:hover {
                background: #1a1a1a;
                color: #fff !important;
                transform: translateY(-1px);
                box-shadow: 0 4px 12px rgba(15, 52, 96, 0.3);
            }
            .virobuilder-edit-btn svg {
                width: 18px;
                height: 18px;
            }
        ' );
    }

    /**
     * Add "Edit with ViroBuilder" button below the title in classic editor.
     */
    public function add_edit_button( WP_Post $post ): void {
        // Only show on AI-designed pages
        if ( ! virobuilder_init()->is_designer_page( $post->ID ) ) {
            return;
        }

        $url = virobuilder_init()->get_editor_url( $post->ID );
        printf(
            '<a href="%s" class="virobuilder-edit-btn">%s %s</a>',
            esc_url( $url ),
            '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M12 2L2 7l10 5 10-5-10-5z"/><path d="M2 17l10 5 10-5M2 12l10 5 10-5"/></svg>',
            esc_html__( 'Edit with ViroBuilder', 'virobuilder' )
        );
    }

    /**
     * Deprecated: Gutenberg button (drag-and-drop builder removed).
     */
    public function enqueue_gutenberg_button(): void {
        // No-op. ViroBuilder is AI-only; pages are created via "Create New Page".
    }

    /**
     * Enqueue editor React app assets — only on the editor page.
     */
    public function enqueue_editor_assets( string $hook ): void {
        // No-op. The drag-and-drop editor was removed; the AI chat editor
        // enqueues its own assets inline.
    }

    public function render_editor_page(): void {
        // Drag-and-drop builder removed. Redirect any old links to the AI create page.
        wp_safe_redirect( admin_url( 'admin.php?page=virobuilder-create' ) );
        exit;
    }
}
