<?php
/**
 * AI Quick-Build module.
 *
 * Generates a complete page from a short brief (business name, industry, offering).
 * Uses a recipe-based approach: industry-specific section ordering with AI-generated copy.
 *
 * In v1, this uses BYOK (Bring Your Own Key) — user pastes their Anthropic API key
 * in settings. Future versions will use a proxy through virodigital.net for paid plans.
 *
 * @package ViroBuilder
 */

defined( 'ABSPATH' ) || exit;

class ViroBuilder_AI_Builder {

    private static ?ViroBuilder_AI_Builder $instance = null;

    public static function instance(): self {
        if ( null === self::$instance ) {
            self::$instance = new self();
        }
        return self::$instance;
    }

    private function __construct() {
        // Settings page (under ViroBuilder menu)
        add_action( 'admin_menu', [ $this, 'register_admin_pages' ], 20 );

        // AJAX endpoints
        add_action( 'wp_ajax_virobuilder_ai_generate', [ $this, 'ajax_generate' ] );
        add_action( 'wp_ajax_virobuilder_ai_save_settings', [ $this, 'ajax_save_settings' ] );
        add_action( 'wp_ajax_virobuilder_ai_get_recipes', [ $this, 'ajax_get_recipes' ] );

        // AJAX endpoint: search Pexels photos from the editor (image swap UI)
        add_action( 'wp_ajax_virobuilder_pexels_search', [ $this, 'ajax_pexels_search' ] );

        // AJAX endpoint: designer-mode full-page generation (new pipeline)
        add_action( 'wp_ajax_virobuilder_ai_design', [ $this, 'ajax_design' ] );

        // Load recipes, style presets, and image subsystem
        require_once VIROBUILDER_PATH . 'includes/ai/recipes.php';
        require_once VIROBUILDER_PATH . 'includes/ai/styles.php';
        require_once VIROBUILDER_PATH . 'includes/ai/image-provider.php';
        require_once VIROBUILDER_PATH . 'includes/ai/image-queries.php';
        require_once VIROBUILDER_PATH . 'includes/ai/class-ai-designer.php';
        require_once VIROBUILDER_PATH . 'includes/ai/class-chat-editor.php';

        // Initialize the chat editor
        ViroBuilder_Chat_Editor::instance();
    }

    /**
     * Register the AI Builder pages under the ViroBuilder admin menu.
     */
    public function register_admin_pages(): void {
        // Primary entry point: create a new AI-designed page
        add_submenu_page(
            'virobuilder-dashboard',
            __( 'Create New Page', 'virobuilder' ),
            __( 'Create New Page', 'virobuilder' ),
            'edit_posts',
            'virobuilder-create',
            [ $this, 'render_create_page' ]
        );

        add_submenu_page(
            'virobuilder-dashboard',
            __( 'AI Settings', 'virobuilder' ),
            __( 'AI Settings', 'virobuilder' ),
            'manage_options',
            'virobuilder-ai-settings',
            [ $this, 'render_settings_page' ]
        );
    }

    /**
     * Standalone "Create New Page" screen — the AI generation entry point.
     * Replaces the old drag-and-drop Quick-Build modal.
     */
    public function render_create_page(): void {
        $brand   = get_option( 'virobuilder_ai_brand_color', '#4f46e5' );
        $api_key = get_option( 'virobuilder_ai_api_key', '' );
        $ai_mode = get_option( 'virobuilder_ai_mode', 'byok' );
        $has_key = ! empty( $api_key ) || ( $ai_mode === 'pro' && get_option( 'virobuilder_pro_license_key', '' ) );
        $nonce   = wp_create_nonce( 'virobuilder_nonce' );
        $settings_url = admin_url( 'admin.php?page=virobuilder-ai-settings' );
        $industries = [ 'saas'=>'SaaS / Software','dental'=>'Dental / Medical','restaurant'=>'Restaurant / Food','law'=>'Law / Legal','realestate'=>'Real Estate','agency'=>'Agency / Studio','fitness'=>'Fitness / Wellness','ecommerce'=>'E-commerce / Retail','beauty'=>'Beauty / Salon','construction'=>'Construction / Trades','consulting'=>'Consulting / Finance','education'=>'Education / Coaching','nonprofit'=>'Nonprofit','photography'=>'Photography / Creative','other'=>'Other' ];
        ?>
        <div class="wrap">

        <div class="vbc">
            <div class="vbc-hero">
                <h1>✦ Create a new page</h1>
                <p>Describe the business. The AI designs a complete, bespoke landing page — photos, copy, SEO, and all.</p>
            </div>

            <?php if ( ! $has_key ) : ?>
            <div class="vbc-warn">
                ⚠ You haven't added an API key yet. <a href="<?php echo esc_url( $settings_url ); ?>">Add it in AI Settings</a> before generating.
            </div>
            <?php endif; ?>

            <div class="vbc-card">
                <div class="vbc-field">
                    <label>Business name</label>
                    <input type="text" id="vbc-name" placeholder="e.g. Brightsmile Dental">
                </div>
                <div class="vbc-field">
                    <label>What do they offer? <span class="hint">— one or two sentences</span></label>
                    <textarea id="vbc-offering" placeholder="e.g. A family dental practice focused on gentle, anxiety-free care with same-day appointments."></textarea>
                </div>
                <div class="vbc-row">
                    <div class="vbc-field">
                        <label>Industry</label>
                        <select id="vbc-industry">
                            <?php foreach ( $industries as $val => $lbl ) : ?>
                            <option value="<?php echo esc_attr( $val ); ?>"><?php echo esc_html( $lbl ); ?></option>
                            <?php endforeach; ?>
                        </select>
                    </div>
                    <div class="vbc-field">
                        <label>Who is it for? <span class="hint">— optional</span></label>
                        <input type="text" id="vbc-audience" placeholder="e.g. Local families">
                    </div>
                </div>
                <div class="vbc-row">
                    <div class="vbc-field">
                        <label>Location <span class="hint">— optional</span></label>
                        <input type="text" id="vbc-location" placeholder="e.g. Boston, MA">
                    </div>
                    <div class="vbc-field">
                        <label>Phone <span class="hint">— optional</span></label>
                        <input type="text" id="vbc-phone" placeholder="e.g. (555) 123-4567">
                    </div>
                </div>
                <div class="vbc-field">
                    <label>Brand color</label>
                    <div class="vbc-color-row">
                        <input type="color" id="vbc-color" value="<?php echo esc_attr( $brand ); ?>">
                        <span class="hint">The AI builds a full palette around this color.</span>
                    </div>
                </div>
                <div class="vbc-actions">
                    <button class="vbc-generate" id="vbc-go" <?php disabled( ! $has_key ); ?>>✦ Design my page</button>
                    <span class="hint">Takes a minute or two — the AI is designing from scratch.</span>
                </div>
            </div>
        </div>

        <div class="vbc-overlay" id="vbc-overlay">
            <div class="vbc-spin"></div>
            <div class="vbc-ov-title">Designing your page…</div>
            <div class="vbc-ov-sub" id="vbc-ov-sub">Creating a bespoke design</div>
            <div class="vbc-ov-step" id="vbc-ov-step"><span>🧠</span><span>Understanding your business…</span></div>
            <div class="vbc-ov-timer" id="vbc-ov-timer">0s</div>
        </div>

        </div>
        <?php
    }

    public function render_settings_page(): void {
        $api_key     = get_option( 'virobuilder_ai_api_key', '' );
        $masked      = $api_key ? substr( $api_key, 0, 7 ) . str_repeat( '•', 32 ) . substr( $api_key, -4 ) : '';
        $pro_key     = get_option( 'virobuilder_pro_license_key', '' );
        $ai_mode     = get_option( 'virobuilder_ai_mode', 'byok' ); // 'byok' or 'pro'
        $has_api_key = ! empty( $api_key );
        $has_pro     = ! empty( $pro_key );
        ?>
        <div class="wrap">
            <h1><?php esc_html_e( 'ViroBuilder AI Settings', 'virobuilder' ); ?></h1>
            <p style="max-width:680px;color:#475569;font-size:14px;line-height:1.6;">
                <?php esc_html_e( "AI Quick-Build generates designer-grade landing pages from a short business description. Choose how you'd like to power the AI below.", 'virobuilder' ); ?>
            </p>

            <form method="post" id="virobuilder-ai-settings-form" style="max-width:680px;margin-top:24px;">

                <!-- ═══ AI Plan Toggle ═══ -->
                <div style="display:grid;grid-template-columns:1fr 1fr;gap:16px;margin-bottom:28px;">

                    <!-- BYOK Card -->
                    <label style="background:<?php echo $ai_mode === 'byok' ? '#f0fdf4' : '#ffffff'; ?>;
                        border:2px solid <?php echo $ai_mode === 'byok' ? '#22c55e' : '#e2e5ea'; ?>;
                        border-radius:12px;padding:20px;cursor:pointer;transition:all .2s;position:relative;">
                        <input type="radio" name="virobuilder_ai_mode" value="byok"
                            <?php checked( $ai_mode, 'byok' ); ?>
                            style="position:absolute;top:16px;right:16px;">
                        <div style="font-weight:700;font-size:15px;color:#0f172a;margin-bottom:4px;">
                            🔑 <?php esc_html_e( 'Bring Your Own Key', 'virobuilder' ); ?>
                        </div>
                        <div style="font-size:12px;color:#64748b;line-height:1.5;">
                            <?php esc_html_e( 'Free forever. Provide your own Anthropic API key and pay Anthropic directly for what you use.', 'virobuilder' ); ?>
                        </div>
                        <div style="margin-top:10px;font-size:11px;font-weight:600;color:#22c55e;">
                            <?php esc_html_e( 'FREE', 'virobuilder' ); ?>
                        </div>
                    </label>

                    <!-- Pro Card -->
                    <label style="background:<?php echo $ai_mode === 'pro' ? '#eff6ff' : '#ffffff'; ?>;
                        border:2px solid <?php echo $ai_mode === 'pro' ? '#3b82f6' : '#e2e5ea'; ?>;
                        border-radius:12px;padding:20px;cursor:pointer;transition:all .2s;position:relative;">
                        <input type="radio" name="virobuilder_ai_mode" value="pro"
                            <?php checked( $ai_mode, 'pro' ); ?>
                            style="position:absolute;top:16px;right:16px;">
                        <div style="font-weight:700;font-size:15px;color:#0f172a;margin-bottom:4px;">
                            ⚡ <?php esc_html_e( 'ViroBuilder Pro', 'virobuilder' ); ?>
                        </div>
                        <div style="font-size:12px;color:#64748b;line-height:1.5;">
                            <?php esc_html_e( 'One-click generation, no API keys needed. Includes stock photos and premium styles.', 'virobuilder' ); ?>
                        </div>
                        <div style="margin-top:10px;font-size:11px;font-weight:600;color:#3b82f6;">
                            <?php esc_html_e( 'COMING SOON', 'virobuilder' ); ?>
                        </div>
                    </label>
                </div>

                <!-- ═══ BYOK Section ═══ -->
                <div id="viro-byok-section" style="background:#ffffff;padding:24px;border:1px solid #e2e5ea;border-radius:8px;<?php echo $ai_mode !== 'byok' ? 'display:none;' : ''; ?>">
                    <h2 style="margin-top:0;font-size:18px;"><?php esc_html_e( 'Anthropic API Key', 'virobuilder' ); ?></h2>
                    <p style="color:#64748b;font-size:13px;line-height:1.6;">
                        <?php
                        printf(
                            wp_kses(
                                /* translators: %s: Anthropic console URL */
                                __( 'Get your API key from <a href="%s" target="_blank">console.anthropic.com</a>. Keys are stored in your database and never leave your server except to call Anthropic directly.', 'virobuilder' ),
                                [ 'a' => [ 'href' => [], 'target' => [] ] ]
                            ),
                            'https://console.anthropic.com/settings/keys'
                        );
                        ?>
                    </p>
                    <div style="margin-top:16px;">
                        <label for="virobuilder_ai_api_key" style="display:block;font-weight:600;margin-bottom:6px;font-size:13px;">
                            <?php esc_html_e( 'API Key', 'virobuilder' ); ?>
                        </label>
                        <input type="password" id="virobuilder_ai_api_key" name="virobuilder_ai_api_key"
                            value="" placeholder="<?php echo $api_key ? esc_attr( $masked ) : 'sk-ant-api03-...'; ?>"
                            style="width:100%;padding:10px 12px;border:1px solid #e2e5ea;border-radius:6px;font-family:monospace;font-size:13px;"
                            autocomplete="off" />
                        <?php if ( $api_key ) : ?>
                            <p style="color:#10b981;font-size:12px;margin-top:6px;">
                                ✓ <?php esc_html_e( 'API key is saved. Leave blank to keep the current key.', 'virobuilder' ); ?>
                            </p>
                        <?php endif; ?>
                    </div>
                </div>

                <!-- ═══ Pro Section ═══ -->
                <div id="viro-pro-section" style="background:#ffffff;padding:24px;border:1px solid #e2e5ea;border-radius:8px;<?php echo $ai_mode !== 'pro' ? 'display:none;' : ''; ?>">
                    <h2 style="margin-top:0;font-size:18px;"><?php esc_html_e( 'ViroBuilder Pro License', 'virobuilder' ); ?></h2>
                    <?php if ( ! $has_pro ) : ?>
                        <div style="background:#eff6ff;border:1px solid #bfdbfe;border-radius:8px;padding:20px;margin-top:12px;">
                            <p style="color:#1e40af;font-size:14px;font-weight:600;margin:0 0 8px;">
                                <?php esc_html_e( 'ViroBuilder Pro is coming soon', 'virobuilder' ); ?>
                            </p>
                            <p style="color:#3b82f6;font-size:13px;line-height:1.6;margin:0;">
                                <?php
                                printf(
                                    wp_kses(
                                        /* translators: %s: Pro waitlist URL */
                                        __( 'Pro is planned to include unlimited AI generations, built-in stock photos, premium design styles, and priority support — no API keys needed. Features may change before launch. <a href="%s" target="_blank">Join the waitlist →</a>', 'virobuilder' ),
                                        [ 'a' => [ 'href' => [], 'target' => [] ] ]
                                    ),
                                    'https://virodigital.net/pro'
                                );
                                ?>
                            </p>
                        </div>
                    <?php else : ?>
                        <div style="margin-top:12px;">
                            <label for="virobuilder_pro_license_key" style="display:block;font-weight:600;margin-bottom:6px;font-size:13px;">
                                <?php esc_html_e( 'License Key', 'virobuilder' ); ?>
                            </label>
                            <input type="password" id="virobuilder_pro_license_key" name="virobuilder_pro_license_key"
                                value="" placeholder="VIRO-PRO-XXXX-XXXX-XXXX"
                                style="width:100%;padding:10px 12px;border:1px solid #e2e5ea;border-radius:6px;font-family:monospace;font-size:13px;"
                                autocomplete="off" />
                        </div>
                    <?php endif; ?>
                </div>

                <!-- ═══ Stock Photos ═══ -->
                <div style="background:#ffffff;padding:24px;border:1px solid #e2e5ea;border-radius:8px;margin-top:16px;">
                    <h2 style="margin-top:0;font-size:18px;"><?php esc_html_e( 'Stock Photos (Pexels)', 'virobuilder' ); ?></h2>
                    <p style="color:#64748b;font-size:13px;line-height:1.6;">
                        <?php
                        printf(
                            wp_kses(
                                /* translators: %s: Pexels API signup URL */
                                __( 'Generated pages include real stock photos from Pexels. Get a free key from <a href="%s" target="_blank">pexels.com/api</a> — 200 requests/hour, no credit card, free for commercial use.', 'virobuilder' ),
                                [ 'a' => [ 'href' => [], 'target' => [] ] ]
                            ),
                            'https://www.pexels.com/api/'
                        );
                        ?>
                    </p>
                    <?php
                        $pexels_key = get_option( 'virobuilder_pexels_api_key', '' );
                        $pexels_masked = $pexels_key ? substr( $pexels_key, 0, 8 ) . str_repeat( '•', 24 ) . substr( $pexels_key, -4 ) : '';
                    ?>
                    <div style="margin-top:16px;">
                        <label for="virobuilder_pexels_api_key" style="display:block;font-weight:600;margin-bottom:6px;font-size:13px;">
                            <?php esc_html_e( 'Pexels API Key', 'virobuilder' ); ?>
                        </label>
                        <input type="password" id="virobuilder_pexels_api_key" name="virobuilder_pexels_api_key"
                            value="" placeholder="<?php echo $pexels_key ? esc_attr( $pexels_masked ) : 'Paste your Pexels API key'; ?>"
                            style="width:100%;padding:10px 12px;border:1px solid #e2e5ea;border-radius:6px;font-family:monospace;font-size:13px;"
                            autocomplete="off" />
                        <?php if ( $pexels_key ) : ?>
                            <p style="color:#10b981;font-size:12px;margin-top:6px;">
                                ✓ <?php esc_html_e( 'Pexels key saved. Pages will include real stock photos.', 'virobuilder' ); ?>
                            </p>
                        <?php else : ?>
                            <p style="color:#f59e0b;font-size:12px;margin-top:6px;">
                                <?php esc_html_e( 'Without a Pexels key, generated pages will use placeholder images.', 'virobuilder' ); ?>
                            </p>
                        <?php endif; ?>
                    </div>
                </div>

                <!-- ═══ Brand Settings ═══ -->
                <div style="background:#ffffff;padding:24px;border:1px solid #e2e5ea;border-radius:8px;margin-top:16px;">
                    <h2 style="margin-top:0;font-size:18px;"><?php esc_html_e( 'Default Brand Settings', 'virobuilder' ); ?></h2>
                    <p style="color:#64748b;font-size:13px;">
                        <?php esc_html_e( 'Pre-filled when you open AI Quick-Build. Override per-generation.', 'virobuilder' ); ?>
                    </p>
                    <div style="margin-top:16px;display:grid;grid-template-columns:1fr 1fr;gap:16px;">
                        <div>
                            <label for="virobuilder_ai_brand_color" style="display:block;font-weight:600;margin-bottom:6px;font-size:13px;">
                                <?php esc_html_e( 'Brand Color', 'virobuilder' ); ?>
                            </label>
                            <input type="color" id="virobuilder_ai_brand_color" name="virobuilder_ai_brand_color"
                                value="<?php echo esc_attr( get_option( 'virobuilder_ai_brand_color', '#0f3460' ) ); ?>"
                                style="width:100%;height:42px;padding:4px;border:1px solid #e2e5ea;border-radius:6px;" />
                        </div>
                        <div>
                            <label for="virobuilder_ai_default_industry" style="display:block;font-weight:600;margin-bottom:6px;font-size:13px;">
                                <?php esc_html_e( 'Default Industry', 'virobuilder' ); ?>
                            </label>
                            <select id="virobuilder_ai_default_industry" name="virobuilder_ai_default_industry"
                                style="width:100%;padding:10px 12px;border:1px solid #e2e5ea;border-radius:6px;font-size:13px;background:#ffffff;">
                                <?php
                                $default = get_option( 'virobuilder_ai_default_industry', 'saas' );
                                $industries = virobuilder_ai_get_industries();
                                foreach ( $industries as $id => $info ) {
                                    printf(
                                        '<option value="%s"%s>%s</option>',
                                        esc_attr( $id ),
                                        selected( $default, $id, false ),
                                        esc_html( $info['label'] )
                                    );
                                }
                                ?>
                            </select>
                        </div>
                    </div>
                </div>

                <div style="margin-top:20px;display:flex;gap:12px;align-items:center;">
                    <button type="submit" class="button button-primary" id="virobuilder-ai-save-btn"
                        style="background:#818cf8;border-color:#818cf8;padding:8px 20px;height:auto;">
                        <?php esc_html_e( 'Save Settings', 'virobuilder' ); ?>
                    </button>
                    <span id="virobuilder-ai-save-status" style="font-size:13px;color:#64748b;"></span>
                </div>
            </form>

            <!-- ═══ Data & Privacy ═══ -->
            <div style="max-width:680px;margin-top:20px;background:#ffffff;border:1px solid #e2e5ea;border-radius:8px;padding:24px;">
                <h2 style="margin-top:0;font-size:18px;"><?php esc_html_e( 'Data & Privacy', 'virobuilder' ); ?></h2>
                <label style="display:flex;align-items:flex-start;gap:12px;cursor:pointer;margin-top:12px;">
                    <input type="checkbox" id="viro-keep-data"
                        <?php checked( get_option( 'virobuilder_keep_data_on_uninstall', '0' ), '1' ); ?>
                        style="margin-top:3px;flex:none;"
                        onchange="(function(el){
                            var fd=new FormData();
                            fd.append('action','virobuilder_ai_save_settings');
                            fd.append('_wpnonce','<?php echo esc_js( wp_create_nonce( 'virobuilder_ai_settings' ) ); ?>');
                            fd.append('virobuilder_keep_data_on_uninstall',el.checked?'1':'0');
                            fetch(ajaxurl,{method:'POST',body:fd});
                        })(this)">
                    <div>
                        <div style="font-weight:600;font-size:14px;color:#0f172a;"><?php esc_html_e( 'Keep data if plugin is deleted', 'virobuilder' ); ?></div>
                        <div style="font-size:12px;color:#64748b;margin-top:2px;line-height:1.5;">
                            <?php esc_html_e( 'When enabled, your API keys, generated pages, and settings will be preserved if you uninstall ViroBuilder. When disabled, all ViroBuilder data will be removed on deletion.', 'virobuilder' ); ?>
                        </div>
                    </div>
                </label>
            </div>

        </div>
        <?php
    }

    public function ajax_save_settings(): void {
        check_ajax_referer( 'virobuilder_ai_settings' );

        if ( ! current_user_can( 'manage_options' ) ) {
            wp_send_json_error( [ 'message' => 'Permission denied' ], 403 );
        }

        // AI mode (byok or pro)
        $ai_mode = sanitize_key( wp_unslash( $_POST['virobuilder_ai_mode'] ?? 'byok' ) );
        if ( in_array( $ai_mode, [ 'byok', 'pro' ], true ) ) {
            update_option( 'virobuilder_ai_mode', $ai_mode );
        }

        // Anthropic API key (BYOK)
        $api_key = isset( $_POST['virobuilder_ai_api_key'] ) ? sanitize_text_field( wp_unslash( $_POST['virobuilder_ai_api_key'] ) ) : '';
        if ( ! empty( $api_key ) ) {
            update_option( 'virobuilder_ai_api_key', $api_key );
        }

        // Pro license key
        $pro_key = isset( $_POST['virobuilder_pro_license_key'] ) ? sanitize_text_field( wp_unslash( $_POST['virobuilder_pro_license_key'] ) ) : '';
        if ( ! empty( $pro_key ) ) {
            update_option( 'virobuilder_pro_license_key', $pro_key );
        }

        if ( isset( $_POST['virobuilder_ai_brand_color'] ) ) {
            update_option( 'virobuilder_ai_brand_color', sanitize_hex_color( wp_unslash( $_POST['virobuilder_ai_brand_color'] ) ) );
        }

        if ( isset( $_POST['virobuilder_ai_default_industry'] ) ) {
            update_option( 'virobuilder_ai_default_industry', sanitize_key( wp_unslash( $_POST['virobuilder_ai_default_industry'] ) ) );
        }

        // Pexels stock photo API key
        $pexels_key = isset( $_POST['virobuilder_pexels_api_key'] ) ? sanitize_text_field( wp_unslash( $_POST['virobuilder_pexels_api_key'] ) ) : '';
        if ( ! empty( $pexels_key ) ) {
            update_option( 'virobuilder_pexels_api_key', $pexels_key );
        }

        // Keep data on uninstall
        if ( isset( $_POST['virobuilder_keep_data_on_uninstall'] ) ) {
            update_option( 'virobuilder_keep_data_on_uninstall', sanitize_key( $_POST['virobuilder_keep_data_on_uninstall'] ) );
        }

        wp_send_json_success( [ 'message' => 'Settings saved' ] );
    }

    /**
     * AJAX: Return the list of available industries (for the AI Builder modal dropdown).
     */
    public function ajax_get_recipes(): void {
        check_ajax_referer( 'virobuilder_nonce' );

        if ( ! current_user_can( 'edit_posts' ) ) {
            wp_send_json_error( [ 'message' => 'Permission denied' ], 403 );
        }

        $industries = virobuilder_ai_get_industries();
        $list = [];
        $styles_map = [];
        foreach ( $industries as $id => $info ) {
            $list[] = [
                'id'          => $id,
                'label'       => $info['label'],
                'description' => $info['description'] ?? '',
                'icon'        => $info['icon'] ?? 'briefcase',
            ];
            // Expose the style presets for this industry (id/label/blurb/swatch only).
            if ( function_exists( 'virobuilder_ai_get_styles_for_industry' ) ) {
                $styles_map[ $id ] = array_map( function( $s ) {
                    return [
                        'id'     => $s['id'],
                        'label'  => $s['label'],
                        'blurb'  => $s['blurb'],
                        'swatch' => $s['swatch'],
                    ];
                }, virobuilder_ai_get_styles_for_industry( $id ) );
            }
        }

        wp_send_json_success( [
            'industries' => $list,
            'styles' => $styles_map,
            'has_api_key' => ! empty( get_option( 'virobuilder_ai_api_key', '' ) ),
            'has_pexels_key' => ! empty( get_option( 'virobuilder_pexels_api_key', '' ) ),
            'ai_mode' => get_option( 'virobuilder_ai_mode', 'byok' ),
            'has_pro' => ! empty( get_option( 'virobuilder_pro_license_key', '' ) ),
            'default_industry' => get_option( 'virobuilder_ai_default_industry', 'saas' ),
            'default_brand_color' => get_option( 'virobuilder_ai_brand_color', '#0f3460' ),
        ] );
    }

    /**
     * AJAX: Generate a page from the user's brief.
     *
     * Body: business_name, industry, offering, audience, brand_color, mode (test|live)
     * Returns: { elements: [...] } — page JSON ready to load into the builder
     */
    public function ajax_generate(): void {
        check_ajax_referer( 'virobuilder_nonce' );

        if ( ! current_user_can( 'edit_posts' ) ) {
            wp_send_json_error( [ 'message' => 'Permission denied' ], 403 );
        }

        $brief = [
            'business_name' => sanitize_text_field( wp_unslash( $_POST['business_name'] ?? '' ) ),
            'industry'      => sanitize_key( wp_unslash( $_POST['industry'] ?? 'saas' ) ),
            'offering'      => sanitize_textarea_field( wp_unslash( $_POST['offering'] ?? '' ) ),
            'audience'      => sanitize_text_field( wp_unslash( $_POST['audience'] ?? '' ) ),
            'brand_color'   => sanitize_hex_color( wp_unslash( $_POST['brand_color'] ?? '#0f3460' ) ) ?: '#0f3460',
            'style'         => sanitize_key( wp_unslash( $_POST['style'] ?? '' ) ),
            'mode'          => sanitize_key( wp_unslash( $_POST['mode'] ?? 'live' ) ),
        ];

        // Validate
        if ( empty( $brief['business_name'] ) || empty( $brief['offering'] ) ) {
            wp_send_json_error( [ 'message' => 'Business name and offering are required.' ], 400 );
        }

        // Get the industry recipe
        $recipe = virobuilder_ai_get_recipe( $brief['industry'] );
        if ( ! $recipe ) {
            wp_send_json_error( [ 'message' => 'Unknown industry: ' . $brief['industry'] ], 400 );
        }

        // Generate the page — both variants in one shot
        $generator = new ViroBuilder_AI_Generator( $brief, $recipe );

        try {
            $variants = $generator->generate_variants();
            wp_send_json_success( [
                'variants' => $variants,
                'brief'    => $brief,
                'mode'     => $brief['mode'],
            ] );
        } catch ( Exception $e ) {
            wp_send_json_error( [ 'message' => $e->getMessage() ], 500 );
        }
    }

    /**
     * AJAX: Designer-mode — generate a full HTML page via AI.
     *
     * This is the new pipeline. Instead of assembling widget trees with AI copy,
     * the AI designs the entire page as one coherent HTML document.
     *
     * Body: business_name, industry, offering, audience, brand_color, tone, location, phone
     * Returns: { html, sections, usage, cost_estimate }
     */
    public function ajax_design(): void {
        check_ajax_referer( 'virobuilder_nonce' );

        if ( ! current_user_can( 'edit_posts' ) ) {
            wp_send_json_error( [ 'message' => 'Permission denied' ], 403 );
        }

        $brief = [
            'business_name' => sanitize_text_field( wp_unslash( $_POST['business_name'] ?? '' ) ),
            'industry'      => sanitize_text_field( wp_unslash( $_POST['industry'] ?? '' ) ),
            'offering'      => sanitize_textarea_field( wp_unslash( $_POST['offering'] ?? '' ) ),
            'audience'      => sanitize_text_field( wp_unslash( $_POST['audience'] ?? '' ) ),
            'tone'          => sanitize_text_field( wp_unslash( $_POST['tone'] ?? 'professional and approachable' ) ),
            'brand_color'   => sanitize_hex_color( wp_unslash( $_POST['brand_color'] ?? '#1f4a3f' ) ) ?: '#1f4a3f',
            'location'      => sanitize_text_field( wp_unslash( $_POST['location'] ?? '' ) ),
            'phone'         => sanitize_text_field( wp_unslash( $_POST['phone'] ?? '' ) ),
        ];

        if ( empty( $brief['business_name'] ) || empty( $brief['offering'] ) ) {
            wp_send_json_error( [ 'message' => 'Business name and offering are required.' ], 400 );
        }

        $designer = new ViroBuilder_AI_Designer( $brief );

        // Catch ALL errors including PHP fatals in PHP 8+
        try {
            // Suppress any stray output that would break JSON
            ob_start();

            $result = $designer->generate();

            // Discard any stray output
            ob_end_clean();

            // Optionally save as a WordPress post (draft)
            $post_id = null;
            if ( ! empty( $_POST['save_as_post'] ) ) {
                $post_id = wp_insert_post( [
                    'post_title'   => $brief['business_name'] . ' — AI Landing Page',
                    'post_content' => $result['html'],
                    'post_status'  => 'draft',
                    'post_type'    => 'page',
                    'meta_input'   => [
                        '_virobuilder_designer_page' => '1',
                        '_virobuilder_sections'      => wp_json_encode( $result['sections'] ),
                        '_virobuilder_brief'         => wp_json_encode( $brief ),
                    ],
                ] );
            }

            wp_send_json_success( [
                'html'          => $result['html'],
                'sections'      => $result['sections'],
                'usage'         => $result['usage'],
                'cost_estimate' => $result['cost_estimate'],
                'post_id'       => $post_id,
            ] );
        } catch ( \Throwable $e ) {
            ob_end_clean();
            wp_send_json_error( [
                'message' => $e->getMessage(),
                'file'    => basename( $e->getFile() ),
                'line'    => $e->getLine(),
            ], 500 );
        }
    }

    /**
     * AJAX: Search Pexels from the editor (for one-click image swap).
     */
    public function ajax_pexels_search(): void {
        check_ajax_referer( 'virobuilder_nonce' );

        if ( ! current_user_can( 'edit_posts' ) ) {
            wp_send_json_error( [ 'message' => 'Permission denied' ], 403 );
        }

        $query = sanitize_text_field( wp_unslash( $_POST['query'] ?? '' ) );
        $orientation = sanitize_key( wp_unslash( $_POST['orientation'] ?? 'landscape' ) );
        $count = absint( $_POST['count'] ?? 12 );
        $count = max( 3, min( 15, $count ) );

        if ( empty( $query ) ) {
            wp_send_json_error( [ 'message' => 'Search query is required.' ], 400 );
        }

        $provider = virobuilder_ai_get_image_provider();
        $results = $provider->search( $query, $count, $orientation );

        wp_send_json_success( [
            'photos'   => $results,
            'query'    => $query,
            'provider' => $provider->name(),
        ] );
    }
}

/**
 * The actual page generator. Loads sections from the recipe, substitutes copy
 * (either with placeholder text in test mode or AI-generated copy in live mode).
 */
class ViroBuilder_AI_Generator {

    /**
     * The Anthropic model used for copy generation.
     * Update this single constant when Anthropic deprecates a model.
     * As of May 2026 the current models are claude-opus-4-7, claude-sonnet-4-6,
     * and claude-haiku-4-5-20251001. Sonnet 4.6 is the best balance of quality and cost.
     */
    const AI_MODEL = 'claude-sonnet-4-6';

    private array $brief;
    private array $recipe;
    private array $generated_copy = [];
    private array $style = [];
    private array $palette = [];
    /** @var int[] Pexels photo IDs already used on this page (for dedup). */
    private array $used_pexels_ids = [];

    public function __construct( array $brief, array $recipe ) {
        $this->brief = $brief;
        $this->recipe = $recipe;

        // Resolve the chosen visual style preset (defaults to the industry's first).
        if ( function_exists( 'virobuilder_ai_get_style' ) ) {
            $industry = $brief['industry'] ?? 'saas';
            $style_id = $brief['style'] ?? '';
            $style = virobuilder_ai_get_style( $industry, $style_id );
            if ( $style ) {
                $this->style   = $style;
                $this->palette = virobuilder_ai_build_palette( $style, $brief['brand_color'] ?? '#6366f1' );
            }
        }
    }

    public function generate(): array {
        if ( $this->brief['mode'] === 'test' ) {
            // Test mode: use the recipe's fallback copy without calling AI
            $this->generated_copy = $this->get_placeholder_copy();
        } else {
            // Live mode: call AI to generate copy
            $this->generated_copy = $this->call_ai();
        }

        // Now assemble the page by loading each section and substituting copy
        return $this->assemble_page();
    }

    /**
     * Generate TWO design variants in one shot.
     * Variant A: "Pain-first" — leads with the problem before the solution (analytical tone)
     * Variant B: "Benefit-first" — leads with what's possible (aspirational tone)
     *
     * Both use the same recipe sections but with different ordering and different
     * AI-generated copy reflecting the different framings.
     */
    public function generate_variants(): array {
        if ( $this->brief['mode'] === 'test' ) {
            // Test mode: same placeholder copy, just two orderings
            $placeholder = $this->get_placeholder_copy();
            return [
                'a' => [
                    'label'    => 'Pain-first',
                    'tagline'  => 'Leads with the problem before the solution',
                    'elements' => $this->assemble_with_ordering( $placeholder, 'a' ),
                ],
                'b' => [
                    'label'    => 'Benefit-first',
                    'tagline'  => 'Leads with what is possible',
                    'elements' => $this->assemble_with_ordering( $placeholder, 'b' ),
                ],
            ];
        }

        // Live mode: ONE API call asking for both variants
        $both_copy = $this->call_ai_for_variants();

        $variant_a_copy = $both_copy['variant_a'] ?? [];
        $variant_b_copy = $both_copy['variant_b'] ?? [];

        return [
            'a' => [
                'label'    => 'Pain-first',
                'tagline'  => 'Leads with the problem before the solution',
                'elements' => $this->assemble_with_ordering( $variant_a_copy, 'a' ),
            ],
            'b' => [
                'label'    => 'Benefit-first',
                'tagline'  => 'Leads with what is possible',
                'elements' => $this->assemble_with_ordering( $variant_b_copy, 'b' ),
            ],
        ];
    }

    /**
     * Determine section ordering for a given variant.
     * Variant A keeps the recipe's default order (problem-first if the recipe includes it).
     * Variant B promotes solution/features to the top, demotes problem-agitation.
     */
    private function get_section_order_for_variant( string $variant ): array {
        $sections = $this->recipe['sections'];
        if ( $variant === 'a' ) {
            return $sections;
        }
        // Variant B: move 'problem-agitation-*' to LATER in the page (right before FAQ),
        // and lift 'features-*' / 'services-*' / 'solution-intro' to right after hero
        $hero = [];
        $problem = [];
        $solution_features = [];
        $middle = [];
        $faq = null;
        $cta = null;

        foreach ( $sections as $section ) {
            $sid = $section['section_id'];
            if ( strpos( $sid, 'hero-' ) === 0 ) {
                $hero[] = $section;
            } elseif ( strpos( $sid, 'problem-' ) === 0 ) {
                $problem[] = $section;
            } elseif ( strpos( $sid, 'features-' ) === 0 || strpos( $sid, 'services-' ) === 0 || strpos( $sid, 'solution-' ) === 0 ) {
                $solution_features[] = $section;
            } elseif ( strpos( $sid, 'faq-' ) === 0 ) {
                $faq = $section;
            } elseif ( strpos( $sid, 'cta-' ) === 0 ) {
                $cta = $section;
            } else {
                $middle[] = $section;
            }
        }

        // Variant B order: hero → solution/features → middle → problem → faq → cta
        $reordered = array_merge( $hero, $solution_features, $middle, $problem );
        if ( $faq ) $reordered[] = $faq;
        if ( $cta ) $reordered[] = $cta;
        return $reordered;
    }

    /**
     * Same assembly as assemble_page() but allows specifying the ordering variant.
     */
    private function assemble_with_ordering( array $copy_map, string $variant ): array {
        $sections_ordered = $this->get_section_order_for_variant( $variant );
        $elements = [];
        $counter = 0;
        $brand = $this->brief['brand_color'];

        foreach ( $sections_ordered as $position => $section ) {
            $counter++;
            $section_id = $section['section_id'];

            $section_elements = $this->load_section_elements( $section_id );
            if ( empty( $section_elements ) ) continue;

            $section_elements = json_decode( wp_json_encode( $section_elements ), true );
            $this->reassign_ids( $section_elements, $variant . $counter . '_' );

            $copy_for_section = $copy_map[ $section_id ] ?? [];
            $substitutions = $section['substitutions'] ?? [];
            if ( ! empty( $substitutions ) && ! empty( $copy_for_section ) ) {
                $this->apply_substitutions( $section_elements, $substitutions, $copy_for_section );
            }

            if ( ! empty( $section['brand_color_targets'] ) ) {
                $this->apply_brand_color( $section_elements, $section['brand_color_targets'], $brand );
            }

            if ( ! empty( $section['image_targets'] ) ) {
                $this->apply_images( $section_elements, $section['image_targets'] );
            }

            // Apply the chosen visual style preset: section background rhythm,
            // typography, brand-tinted text accents, card treatment.
            if ( ! empty( $this->style ) && ! empty( $this->palette ) ) {
                $this->apply_style( $section_elements, $position, $section_id );
            }

            $elements = array_merge( $elements, $section_elements );
        }

        return $elements;
    }

    /**
     * Apply the chosen style preset to one section's elements.
     *
     * @param array  $elements   Section element tree (by reference).
     * @param int    $position   0-based index of this section in the page.
     * @param string $section_id The section template id (for per-type tweaks).
     */
    private function apply_style( array &$elements, int $position, string $section_id ): void {
        $style   = $this->style;
        $pal     = $this->palette;
        $rhythm  = $style['rhythm'] ?? [ 'light' ];
        $treat   = $rhythm[ $position % count( $rhythm ) ];

        // Resolve the section background + the text colors that read on it.
        switch ( $treat ) {
            case 'dark':
                $section_bg   = $pal['dark_bg'];
                $heading_col  = '#ffffff';
                $body_col     = $pal['text_on_dark'];
                $eyebrow_col  = virobuilder_ai_tint( $pal['brand'], 0.35 );
                $muted_col    = $pal['muted_on_dark'];
                $on_dark      = true;
                break;
            case 'brand':
                $section_bg   = $pal['brand'];
                $heading_col  = virobuilder_ai_readable_text( $pal['brand'] );
                $body_col     = $heading_col === '#ffffff' ? $pal['text_on_dark'] : $pal['text_muted'];
                $eyebrow_col  = $heading_col === '#ffffff' ? 'rgba(255,255,255,0.85)' : $pal['brand_dark'];
                $muted_col    = $heading_col === '#ffffff' ? $pal['muted_on_dark'] : $pal['text_muted'];
                $on_dark      = ( $heading_col === '#ffffff' );
                break;
            case 'tinted':
                $section_bg   = $pal['tinted_bg'];
                $heading_col  = $pal['text_dark'];
                $body_col     = $pal['text_muted'];
                $eyebrow_col  = $pal['brand'];
                $muted_col    = $pal['text_muted'];
                $on_dark      = false;
                break;
            case 'light':
            default:
                $section_bg   = $pal['light_bg'];
                $heading_col  = $pal['text_dark'];
                $body_col     = $pal['text_muted'];
                $eyebrow_col  = $pal['brand'];
                $muted_col    = $pal['text_muted'];
                $on_dark      = false;
                break;
        }

        $card_bg = $on_dark ? 'rgba(255,255,255,0.06)' : '#ffffff';

        // Walk the tree once, applying treatment by element type.
        $walk = function( &$el ) use ( &$walk, $style, $pal, $section_bg, $heading_col, $body_col, $eyebrow_col, $muted_col, $card_bg, $on_dark, $treat ) {
            $type = $el['type'] ?? '';
            $wt   = $el['widgetType'] ?? '';

            if ( $type === 'section' ) {
                // Only set the outer section background; nested sections are rare.
                $el['settings']['bg_color'] = $section_bg;
                $el['settings']['bg_type']  = 'color';
                // Don't carry a stale bg image into a styled section unless it's the hero.
            }

            if ( $type === 'widget' ) {
                $s = $el['settings'] ?? [];
                switch ( $wt ) {
                    case 'eyebrow':
                        $s['color'] = $eyebrow_col;
                        break;
                    case 'heading':
                        $s['color'] = $heading_col;
                        $s['typography'] = array_merge( $s['typography'] ?? [], [
                            'font_family'    => $style['font_heading'],
                            'font_weight'    => $style['heading_weight'],
                            'letter_spacing' => $style['heading_ls'],
                        ] );
                        break;
                    case 'text-editor':
                        $s['color'] = $body_col;
                        $s['typography'] = array_merge( $s['typography'] ?? [], [
                            'font_family' => $style['font_body'],
                        ] );
                        break;
                    case 'button':
                        // Primary buttons always carry the brand; on brand sections invert.
                        if ( $treat === 'brand' ) {
                            $s['bg_color']       = '#ffffff';
                            $s['text_color']     = $pal['brand'];
                            $s['hover_bg_color'] = $pal['brand_soft'];
                        } else {
                            $s['bg_color']       = $pal['brand'];
                            $s['text_color']     = virobuilder_ai_readable_text( $pal['brand'] );
                            $s['hover_bg_color'] = $pal['brand_dark'];
                        }
                        $s['border_radius'] = $style['radius'];
                        break;
                    case 'icon-box':
                        $s['title_color']       = $heading_col;
                        $s['description_color'] = $muted_col;
                        $s['icon_color']        = $on_dark ? '#ffffff' : $pal['brand'];
                        if ( ( $style['card'] ?? 'flat' ) !== 'flat' ) {
                            $s['bg_color']      = $card_bg;
                            $s['border_radius'] = $style['radius'];
                            $s['padding']       = $s['padding'] ?? '28';
                            if ( $style['card'] === 'soft' && ! $on_dark ) {
                                $s['box_shadow'] = '0 4px 24px rgba(15,23,42,0.06)';
                            }
                            if ( $style['card'] === 'bordered' ) {
                                $s['border'] = '1px solid ' . ( $on_dark ? 'rgba(255,255,255,0.12)' : $pal['border'] );
                            }
                        }
                        break;
                    case 'testimonial':
                        $s['text_color']   = $heading_col;
                        $s['name_color']   = $heading_col;
                        $s['title_color']  = $muted_col;
                        $s['bg_color']     = $card_bg;
                        $s['border_radius']= $style['radius'];
                        if ( ( $style['card'] ?? 'flat' ) === 'soft' && ! $on_dark ) {
                            $s['box_shadow'] = '0 4px 24px rgba(15,23,42,0.06)';
                        }
                        break;
                    case 'heading-small':
                    case 'subheading':
                        $s['color'] = $body_col;
                        break;
                }
                $el['settings'] = $s;
            }

            if ( ! empty( $el['children'] ) && is_array( $el['children'] ) ) {
                foreach ( $el['children'] as &$child ) {
                    $walk( $child );
                }
                unset( $child );
            }
        };

        foreach ( $elements as &$el ) {
            $walk( $el );
        }
        unset( $el );
    }

    /**
     * Single AI call that produces copy for BOTH variants at once.
     * Returns: [ 'variant_a' => [...], 'variant_b' => [...] ]
     */
    private function call_ai_for_variants(): array {
        $api_key = get_option( 'virobuilder_ai_api_key', '' );
        if ( empty( $api_key ) ) {
            throw new Exception( esc_html( 'No Anthropic API key configured. Add one in ViroBuilder → AI Settings.' ) );
        }

        $prompt = $this->build_variants_prompt();

        $response = wp_remote_post( 'https://api.anthropic.com/v1/messages', [
            'timeout' => 90,
            'headers' => [
                'Content-Type'      => 'application/json',
                'x-api-key'         => $api_key,
                'anthropic-version' => '2023-06-01',
            ],
            'body' => wp_json_encode( [
                'model'      => self::AI_MODEL,
                'max_tokens' => 8192,
                'messages'   => [
                    [
                        'role'    => 'user',
                        'content' => $prompt,
                    ],
                ],
            ] ),
        ] );

        if ( is_wp_error( $response ) ) {
            throw new Exception( esc_html( 'AI request failed: ' . $response->get_error_message() ) );
        }

        $code = wp_remote_retrieve_response_code( $response );
        $body = wp_remote_retrieve_body( $response );

        if ( $code !== 200 ) {
            $error_body = json_decode( $body, true );
            $error_msg = $error_body['error']['message'] ?? 'HTTP ' . $code;
            throw new Exception( esc_html( 'Anthropic API error: ' . $error_msg ) );
        }

        $data = json_decode( $body, true );
        $text = $data['content'][0]['text'] ?? '';

        if ( empty( $text ) ) {
            throw new Exception( esc_html( 'AI returned empty response.' ) );
        }

        if ( preg_match( '/```(?:json)?\s*(\{.*\})\s*```/s', $text, $m ) ) {
            $json_str = $m[1];
        } else {
            $json_str = $text;
        }

        $result = json_decode( $json_str, true );
        if ( ! is_array( $result ) ) {
            throw new Exception( esc_html( 'AI returned invalid JSON. Raw: ' . substr( $text, 0, 300 ) ) );
        }

        if ( ! isset( $result['variant_a'] ) || ! isset( $result['variant_b'] ) ) {
            throw new Exception( esc_html( 'AI response missing variant_a or variant_b keys.' ) );
        }

        return $result;
    }

    private function build_variants_prompt(): string {
        $brief = $this->brief;
        $audience = $brief['audience'] ?: 'modern teams and customers';

        $schema_lines = [];
        foreach ( $this->recipe['sections'] as $section ) {
            $sid = $section['section_id'];
            $keys = $section['copy_keys'] ?? [];
            if ( empty( $keys ) ) continue;
            $schema_lines[] = '    "' . $sid . '": {';
            foreach ( $keys as $key => $description ) {
                $schema_lines[] = '      "' . $key . '": "' . str_replace( '"', "'", $description ) . '",';
            }
            $schema_lines[] = '    },';
        }
        $schema_body = implode( "\n", $schema_lines );

        $prompt = "You are writing copy for a landing page. The business is:\n\n";
        $prompt .= "BUSINESS NAME: {$brief['business_name']}\n";
        $prompt .= "INDUSTRY: {$this->recipe['label']}\n";
        $prompt .= "WHAT THEY OFFER: {$brief['offering']}\n";
        $prompt .= "TARGET AUDIENCE: {$audience}\n\n";

        $prompt .= "Write TWO complete landing page copy variants with different framings:\n\n";
        $prompt .= "VARIANT A (Pain-first, analytical tone):\n";
        $prompt .= "  Leads with the problem. Headlines call out what's broken about the current way of doing things.\n";
        $prompt .= "  Voice: direct, sharp, slightly skeptical. Like a smart consultant who tells it like it is.\n";
        $prompt .= "  Example hero headline pattern: 'Your X tells you what. Lumen tells you why.'\n\n";
        $prompt .= "VARIANT B (Benefit-first, aspirational tone):\n";
        $prompt .= "  Leads with what's possible. Headlines paint the outcome.\n";
        $prompt .= "  Voice: confident, warm, future-focused. Like a trusted partner showing you what's ahead.\n";
        $prompt .= "  Example hero headline pattern: 'Finally understand why users churn — in 2 days, not 2 quarters.'\n\n";

        $prompt .= "Rules for BOTH variants:\n";
        $prompt .= "1. Specific and concrete, not generic. Use real numbers, real outcomes, real scenarios when relevant.\n";
        $prompt .= "2. NEVER use marketing clichés: leverage, synergy, world-class, cutting-edge, unlock, transform, next-generation, innovative, seamless, robust.\n";
        $prompt .= "3. Headlines short and punchy (under 10 words usually).\n";
        $prompt .= "4. Body text conversational, like talking to one specific person.\n";
        $prompt .= "5. Mention {$brief['business_name']} by name 2-3 times across each variant.\n";
        $prompt .= "6. Both variants describe the SAME product, just with different angles.\n";
        $prompt .= "7. Generate REAL-feeling customer names and quotes (no 'Customer 1' or 'John Doe').\n\n";

        $prompt .= "Return ONLY a JSON object with this exact shape (no markdown, no explanation, no preamble):\n\n";
        $prompt .= "{\n";
        $prompt .= "  \"variant_a\": {\n";
        $prompt .= $schema_body . "\n";
        $prompt .= "  },\n";
        $prompt .= "  \"variant_b\": {\n";
        $prompt .= $schema_body . "\n";
        $prompt .= "  }\n";
        $prompt .= "}\n";

        return $prompt;
    }


    /**
     * Return placeholder copy for test mode — uses business name + offering directly
     * with template strings.
     */
    private function get_placeholder_copy(): array {
        $name = $this->brief['business_name'];
        $offering = $this->brief['offering'];
        $audience = $this->brief['audience'] ?: 'modern teams';
        $copy = [];
        foreach ( $this->recipe['sections'] as $section ) {
            $copy[ $section['section_id'] ] = [];
            foreach ( $section['copy_keys'] ?? [] as $key => $fallback ) {
                // Simple template substitution: {name}, {offering}, {audience}
                $text = $fallback;
                $text = str_replace( '{name}', $name, $text );
                $text = str_replace( '{offering}', $offering, $text );
                $text = str_replace( '{audience}', $audience, $text );
                $copy[ $section['section_id'] ][ $key ] = $text;
            }
        }
        return $copy;
    }

    /**
     * Call Anthropic API to generate copy for all sections in one shot.
     */
    private function call_ai(): array {
        $api_key = get_option( 'virobuilder_ai_api_key', '' );
        if ( empty( $api_key ) ) {
            throw new Exception( esc_html( 'No Anthropic API key configured. Add one in ViroBuilder → AI Settings.' ) );
        }

        // Build the prompt
        $prompt = $this->build_prompt();

        // Call the API
        $response = wp_remote_post( 'https://api.anthropic.com/v1/messages', [
            'timeout' => 60,
            'headers' => [
                'Content-Type'      => 'application/json',
                'x-api-key'         => $api_key,
                'anthropic-version' => '2023-06-01',
            ],
            'body' => wp_json_encode( [
                'model'      => self::AI_MODEL,
                'max_tokens' => 4096,
                'messages'   => [
                    [
                        'role'    => 'user',
                        'content' => $prompt,
                    ],
                ],
            ] ),
        ] );

        if ( is_wp_error( $response ) ) {
            throw new Exception( esc_html( 'AI request failed: ' . $response->get_error_message() ) );
        }

        $code = wp_remote_retrieve_response_code( $response );
        $body = wp_remote_retrieve_body( $response );

        if ( $code !== 200 ) {
            $error_body = json_decode( $body, true );
            $error_msg = $error_body['error']['message'] ?? 'HTTP ' . $code;
            throw new Exception( esc_html( 'Anthropic API error: ' . $error_msg ) );
        }

        $data = json_decode( $body, true );
        $text = $data['content'][0]['text'] ?? '';

        if ( empty( $text ) ) {
            throw new Exception( esc_html( 'AI returned empty response.' ) );
        }

        // Extract JSON from the response (the model may wrap it in markdown)
        if ( preg_match( '/```(?:json)?\s*(\{.*?\})\s*```/s', $text, $m ) ) {
            $json_str = $m[1];
        } else {
            $json_str = $text;
        }

        $copy = json_decode( $json_str, true );
        if ( ! is_array( $copy ) ) {
            throw new Exception( esc_html( 'AI returned invalid JSON. Raw: ' . substr( $text, 0, 200 ) ) );
        }

        return $copy;
    }

    private function build_prompt(): string {
        $brief = $this->brief;
        $audience = $brief['audience'] ?: 'modern teams and customers';

        // Build the schema of copy keys we need
        $schema_lines = [];
        $example_lines = [];
        foreach ( $this->recipe['sections'] as $section ) {
            $sid = $section['section_id'];
            $keys = $section['copy_keys'] ?? [];
            if ( empty( $keys ) ) continue;
            $schema_lines[] = '  "' . $sid . '": {';
            foreach ( $keys as $key => $fallback ) {
                $schema_lines[] = '    "' . $key . '": "...",';
            }
            $schema_lines[] = '  },';
        }

        $prompt = "You are writing copy for a landing page. The business is:\n\n";
        $prompt .= "BUSINESS NAME: {$brief['business_name']}\n";
        $prompt .= "INDUSTRY: {$this->recipe['label']}\n";
        $prompt .= "WHAT THEY OFFER: {$brief['offering']}\n";
        $prompt .= "TARGET AUDIENCE: {$audience}\n\n";
        $prompt .= "Write the copy for each section of their landing page. Follow these rules:\n";
        $prompt .= "1. Specific and concrete, not generic. Use real numbers, real outcomes, real scenarios.\n";
        $prompt .= "2. Match the voice for the industry (professional and warm for service businesses, sharp and confident for SaaS, etc.)\n";
        $prompt .= "3. NEVER use marketing clichés like 'leverage', 'synergy', 'world-class', 'cutting-edge', 'unlock', 'transform', or 'next-generation'.\n";
        $prompt .= "4. Headlines should be short and punchy (max 8 words usually).\n";
        $prompt .= "5. Body text should be conversational, like talking to one specific person.\n";
        $prompt .= "6. Address pain points the audience actually has.\n";
        $prompt .= "7. Mention {$brief['business_name']} by name at least 2-3 times across the page.\n\n";
        $prompt .= "Return ONLY a JSON object with this exact shape (no markdown, no explanation):\n\n";
        $prompt .= "{\n" . implode( "\n", $schema_lines ) . "\n}\n";

        return $prompt;
    }

    /**
     * Assemble the page by loading each section template and substituting AI-generated copy
     * into the widget settings that match the copy_keys mapping.
     */
    private function assemble_page(): array {
        $elements = [];
        $counter = 0;
        $brand = $this->brief['brand_color'];

        foreach ( $this->recipe['sections'] as $section ) {
            $counter++;
            $section_id = $section['section_id'];

            // Load the section template's elements
            $section_elements = $this->load_section_elements( $section_id );
            if ( empty( $section_elements ) ) {
                continue;
            }

            // Deep copy and reassign IDs
            $section_elements = json_decode( wp_json_encode( $section_elements ), true );
            $this->reassign_ids( $section_elements, 'ai' . $counter . '_' );

            // Apply copy substitutions
            $copy_for_section = $this->generated_copy[ $section_id ] ?? [];
            $substitutions = $section['substitutions'] ?? [];
            if ( ! empty( $substitutions ) && ! empty( $copy_for_section ) ) {
                $this->apply_substitutions( $section_elements, $substitutions, $copy_for_section );
            }

            // Apply brand color where the recipe says to
            if ( ! empty( $section['brand_color_targets'] ) ) {
                $this->apply_brand_color( $section_elements, $section['brand_color_targets'], $brand );
            }

            // Apply images where the recipe says to
            if ( ! empty( $section['image_targets'] ) ) {
                $this->apply_images( $section_elements, $section['image_targets'] );
            }

            $elements = array_merge( $elements, $section_elements );
        }

        return $elements;
    }

    /**
     * Apply images from Pexels (live search) or legacy Unsplash pools (fallback).
     *
     * `image_targets` maps "widget_type:index:url_key" => "pool_name"
     * where pool_name doubles as the section role for Pexels query mapping
     * (e.g. "hero", "feature", "team").
     *
     * Strategy:
     *   1. If a Pexels key is configured, search Pexels with industry+role queries.
     *   2. Otherwise, fall back to the recipe's hardcoded Unsplash image_pools.
     *   3. Track used Pexels IDs across the whole page to avoid duplicates.
     */
    private function apply_images( array &$elements, array $targets ): void {
        if ( empty( $targets ) ) return;

        $has_pexels = function_exists( 'virobuilder_ai_get_image_provider' )
                    && ! empty( get_option( 'virobuilder_pexels_api_key', '' ) );

        // Build widget index
        $widgets_by_type = [];
        $collect = function( &$el ) use ( &$collect, &$widgets_by_type ) {
            if ( ( $el['type'] ?? '' ) === 'widget' ) {
                $wt = $el['widgetType'] ?? '';
                if ( ! isset( $widgets_by_type[ $wt ] ) ) {
                    $widgets_by_type[ $wt ] = [];
                }
                $widgets_by_type[ $wt ][] = &$el;
            }
            if ( ! empty( $el['children'] ) && is_array( $el['children'] ) ) {
                foreach ( $el['children'] as &$child ) {
                    $collect( $child );
                }
            }
        };
        foreach ( $elements as &$el ) {
            $collect( $el );
        }

        foreach ( $targets as $target => $pool_name ) {
            $parts = explode( ':', $target );
            if ( count( $parts ) !== 3 ) continue;
            list( $wtype, $idx, $skey ) = $parts;
            $idx = (int) $idx;

            if ( ! isset( $widgets_by_type[ $wtype ][ $idx ] ) ) continue;

            $url = '';
            $alt = '';

            if ( $has_pexels ) {
                // Use Pexels: pool_name is the role (hero, feature, team, etc.)
                $industry = $this->brief['industry'] ?? 'saas';
                $hint     = $this->get_image_hint();
                $img      = virobuilder_ai_resolve_image(
                    $industry,
                    $pool_name,
                    $hint,
                    $this->used_pexels_ids,
                    'landscape'
                );
                if ( $img ) {
                    $url = $img['url'];
                    $alt = $img['alt'] ?? '';
                    if ( ! empty( $img['pexels_id'] ) ) {
                        $this->used_pexels_ids[] = $img['pexels_id'];
                    }
                    // Store photographer credit as data attribute for future UI
                    if ( ! empty( $img['photographer'] ) ) {
                        $widgets_by_type[ $wtype ][ $idx ]['settings']['_photo_credit'] = $img['photographer'];
                        $widgets_by_type[ $wtype ][ $idx ]['settings']['_photo_source'] = $img['source_url'] ?? '';
                    }
                }
            }

            // No remote fallback: if Pexels returned nothing, the image slot is
            // left empty (a branded placeholder is applied elsewhere). The plugin
            // does not load images from any remote host other than the user's
            // configured Pexels account.
            if ( ! empty( $url ) ) {
                $widgets_by_type[ $wtype ][ $idx ]['settings'][ $skey ] = $url;
                // Also set alt text if the widget supports it and we have one
                if ( ! empty( $alt ) && $skey === 'image_url' ) {
                    $widgets_by_type[ $wtype ][ $idx ]['settings']['image_alt'] = $alt;
                }
            }
        }
    }

    /**
     * Derive a short image-search hint from the business brief.
     * E.g. "pediatric dental" or "Italian restaurant" — enough to
     * contextualise the generic industry queries.
     */
    private function get_image_hint(): string {
        $name = $this->brief['business_name'] ?? '';
        $offering = $this->brief['offering'] ?? '';

        // Use the first few meaningful words of the offering
        $words = preg_split( '/\s+/', $offering );
        $hint_words = array_slice( $words, 0, 3 );
        $hint = implode( ' ', $hint_words );

        // Keep it short — max 40 chars
        if ( strlen( $hint ) > 40 ) {
            $hint = substr( $hint, 0, 40 );
        }

        return trim( $hint );
    }

    /**
     * Load the elements array from a section template PHP file by section ID.
     */
    private function load_section_elements( string $section_id ): array {
        $dir = VIROBUILDER_PATH . 'includes/templates/sections';
        if ( ! is_dir( $dir ) ) {
            return [];
        }

        foreach ( scandir( $dir ) as $file ) {
            if ( substr( $file, -4 ) !== '.php' ) continue;
            $path = $dir . '/' . $file;
            $data = include $path;
            if ( is_array( $data ) && ( $data['id'] ?? '' ) === $section_id ) {
                return $data['elements'] ?? [];
            }
        }
        return [];
    }

    /**
     * Recursively reassign element IDs to ensure uniqueness when composing pages.
     */
    private function reassign_ids( array &$elements, string $prefix ): void {
        static $counter = 0;
        $local_counter = 0;
        $walk = function( &$el ) use ( &$walk, $prefix, &$local_counter ) {
            $local_counter++;
            $el['id'] = $prefix . $local_counter;
            if ( ! empty( $el['children'] ) && is_array( $el['children'] ) ) {
                foreach ( $el['children'] as &$child ) {
                    $walk( $child );
                }
            }
        };
        foreach ( $elements as &$el ) {
            $walk( $el );
        }
    }

    /**
     * Apply substitutions to widget settings. The substitutions array maps:
     *   widget_index (0-based, depth-first) + setting_key  =>  copy_key
     *
     * Example: 'heading:0:title' => 'headline' means "the first heading widget's title comes from copy['headline']"
     */
    private function apply_substitutions( array &$elements, array $substitutions, array $copy ): void {
        // Build a flat depth-first index of widgets grouped by type
        $widgets_by_type = [];
        $collect = function( &$el ) use ( &$collect, &$widgets_by_type ) {
            if ( ( $el['type'] ?? '' ) === 'widget' ) {
                $wt = $el['widgetType'] ?? '';
                if ( ! isset( $widgets_by_type[ $wt ] ) ) {
                    $widgets_by_type[ $wt ] = [];
                }
                $widgets_by_type[ $wt ][] = &$el;
            }
            if ( ! empty( $el['children'] ) && is_array( $el['children'] ) ) {
                foreach ( $el['children'] as &$child ) {
                    $collect( $child );
                }
            }
        };
        foreach ( $elements as &$el ) {
            $collect( $el );
        }

        foreach ( $substitutions as $target => $copy_key ) {
            $value = $copy[ $copy_key ] ?? null;
            if ( $value === null ) continue;

            // Parse target: "widget_type:index:setting_key"
            $parts = explode( ':', $target );
            if ( count( $parts ) !== 3 ) continue;
            list( $wtype, $idx, $skey ) = $parts;
            $idx = (int) $idx;

            if ( isset( $widgets_by_type[ $wtype ][ $idx ] ) ) {
                $widget = &$widgets_by_type[ $wtype ][ $idx ];
                // Wrap in <p> tags if it's a text-editor content key
                if ( $wtype === 'text-editor' && $skey === 'content' && stripos( $value, '<p>' ) === false ) {
                    $value = '<p>' . esc_html( $value ) . '</p>';
                }
                $widget['settings'][ $skey ] = $value;
            }
        }
    }

    /**
     * Apply the user's brand color to the targets specified in the recipe.
     * Targets array maps "widget_type:index:setting_key" => true
     */
    private function apply_brand_color( array &$elements, array $targets, string $brand_color ): void {
        $widgets_by_type = [];
        $collect = function( &$el ) use ( &$collect, &$widgets_by_type ) {
            if ( ( $el['type'] ?? '' ) === 'widget' ) {
                $wt = $el['widgetType'] ?? '';
                if ( ! isset( $widgets_by_type[ $wt ] ) ) {
                    $widgets_by_type[ $wt ] = [];
                }
                $widgets_by_type[ $wt ][] = &$el;
            }
            if ( ! empty( $el['children'] ) && is_array( $el['children'] ) ) {
                foreach ( $el['children'] as &$child ) {
                    $collect( $child );
                }
            }
        };
        foreach ( $elements as &$el ) {
            $collect( $el );
        }

        foreach ( $targets as $target ) {
            $parts = explode( ':', $target );
            if ( count( $parts ) !== 3 ) continue;
            list( $wtype, $idx, $skey ) = $parts;
            $idx = (int) $idx;
            if ( isset( $widgets_by_type[ $wtype ][ $idx ] ) ) {
                $widgets_by_type[ $wtype ][ $idx ]['settings'][ $skey ] = $brand_color;
            }
        }
    }
}

ViroBuilder_AI_Builder::instance();
