<?php
/**
 * Industry → Pexels search query mapping.
 *
 * Maps (industry, section_role) pairs to curated search queries that return
 * high-quality, relevant photographs on Pexels. Each entry is an array of
 * query strings ordered from most specific to broadest — the resolver tries
 * them in order until it gets enough results.
 *
 * Section roles correspond to the image slots in the generated page:
 *   hero      — main hero background / split image
 *   team      — people / staff photos
 *   feature   — supporting imagery for feature sections
 *   about     — about-us / founder story
 *   gallery   — portfolio / project shots
 *   product   — product photography
 *   ambiance  — mood / atmosphere shots
 *
 * The AI also generates a per-business "image_hint" that gets prepended to
 * the first query (e.g. "pediatric dental" + "clinic interior"), so results
 * are contextualised even with generic industry mappings.
 *
 * @package ViroBuilder
 */

defined( 'ABSPATH' ) || exit;
/**
 * Return the query cascade for a given industry + section role.
 *
 * @param string $industry    Industry key (saas, health, restaurant, etc.)
 * @param string $role        Section role (hero, team, feature, about, etc.)
 * @param string $hint        Optional AI-generated context hint to prepend.
 * @return string[]  Ordered query strings, most specific first.
 */
function virobuilder_ai_image_queries( string $industry, string $role, string $hint = '' ): array {
    $map = virobuilder_ai_image_query_map();

    // Try exact industry+role, then industry+generic, then universal fallback
    $queries = $map[ $industry ][ $role ]
            ?? $map[ $industry ]['generic']
            ?? $map['_fallback'][ $role ]
            ?? $map['_fallback']['generic'];

    // If a hint was provided, prepend a hinted version of the first query
    if ( ! empty( $hint ) ) {
        array_unshift( $queries, trim( $hint . ' ' . $queries[0] ) );
    }

    return $queries;
}

/**
 * Master query map. Each leaf is an array of progressively broader queries.
 */
function virobuilder_ai_image_query_map(): array {
    static $map = null;
    if ( $map !== null ) return $map;

    $map = [

        // ── SaaS / Software ─────────────────────────────────────
        'saas' => [
            'hero'    => [ 'team working on laptops modern office', 'software team collaboration', 'modern office workspace' ],
            'feature' => [ 'person using laptop software', 'data dashboard on screen', 'technology workspace' ],
            'team'    => [ 'diverse tech team meeting', 'startup team office', 'professional team portrait' ],
            'about'   => [ 'startup founder office', 'entrepreneur working laptop', 'modern coworking space' ],
            'generic' => [ 'modern office technology', 'business professional laptop' ],
        ],

        // ── Agency ──────────────────────────────────────────────
        'agency' => [
            'hero'    => [ 'creative team brainstorming whiteboard', 'design studio workspace', 'creative agency meeting' ],
            'feature' => [ 'designer working on computer', 'creative workspace mood board', 'marketing strategy meeting' ],
            'team'    => [ 'creative professionals team portrait', 'design team collaboration', 'agency team meeting' ],
            'about'   => [ 'design studio interior', 'creative workspace', 'modern office design' ],
            'gallery' => [ 'web design on monitor screen', 'brand design mockup', 'creative portfolio work' ],
            'generic' => [ 'creative professional workspace', 'modern design studio' ],
        ],

        // ── Restaurant / Hospitality ────────────────────────────
        'restaurant' => [
            'hero'    => [ 'restaurant interior warm lighting', 'elegant dining room', 'modern restaurant ambiance' ],
            'feature' => [ 'chef preparing gourmet food', 'beautiful plated dish', 'fresh ingredients cooking' ],
            'team'    => [ 'chef in restaurant kitchen', 'restaurant staff service', 'friendly waiter serving' ],
            'about'   => [ 'restaurant interior design', 'cozy dining atmosphere', 'bar and lounge interior' ],
            'ambiance'=> [ 'candlelit dinner table', 'wine glasses restaurant', 'outdoor patio dining' ],
            'generic' => [ 'gourmet food photography', 'restaurant dining experience' ],
        ],

        // ── Health / Wellness ───────────────────────────────────
        'health' => [
            'hero'    => [ 'modern medical clinic interior', 'doctor consultation patient', 'bright healthcare office' ],
            'feature' => [ 'doctor with patient friendly', 'medical professional smiling', 'modern clinic treatment room' ],
            'team'    => [ 'medical team professionals', 'healthcare workers portrait', 'doctors and nurses team' ],
            'about'   => [ 'modern clinic reception', 'healthcare facility interior', 'medical office waiting room' ],
            'generic' => [ 'healthcare professional', 'modern medical clinic' ],
        ],

        // ── Real Estate ─────────────────────────────────────────
        'realestate' => [
            'hero'    => [ 'beautiful modern house exterior', 'luxury home interior design', 'modern architecture house' ],
            'feature' => [ 'house interior living room', 'modern kitchen design home', 'real estate open house' ],
            'team'    => [ 'real estate agent showing house', 'professional realtor portrait', 'property consultation' ],
            'about'   => [ 'modern real estate office', 'cityscape skyline buildings', 'residential neighborhood aerial' ],
            'gallery' => [ 'luxury property interior', 'modern apartment design', 'house exterior landscaping' ],
            'generic' => [ 'modern home interior', 'real estate property' ],
        ],

        // ── Law / Professional Services ─────────────────────────
        'law' => [
            'hero'    => [ 'professional office handshake', 'law firm modern office', 'business meeting conference room' ],
            'feature' => [ 'lawyer client consultation', 'legal documents desk', 'professional meeting office' ],
            'team'    => [ 'professional team business formal', 'law firm partners', 'corporate team portrait' ],
            'about'   => [ 'elegant office interior', 'law library books', 'professional office building' ],
            'generic' => [ 'professional business office', 'corporate meeting room' ],
        ],

        // ── E-commerce / Products ───────────────────────────────
        'ecommerce' => [
            'hero'    => [ 'product photography lifestyle', 'online shopping lifestyle', 'unboxing package delivery' ],
            'feature' => [ 'product packaging modern minimal', 'online shopping phone', 'ecommerce delivery happy customer' ],
            'team'    => [ 'small business owner workshop', 'entrepreneur packaging orders', 'warehouse team working' ],
            'about'   => [ 'handmade products workshop', 'small business workspace', 'product design process' ],
            'product' => [ 'minimal product photography', 'product flat lay', 'lifestyle product shoot' ],
            'generic' => [ 'ecommerce product lifestyle', 'modern product photography' ],
        ],

        // ── Fitness / Gym ───────────────────────────────────────
        'fitness' => [
            'hero'    => [ 'modern gym interior equipment', 'fitness class group workout', 'gym training session' ],
            'feature' => [ 'personal trainer coaching client', 'weight training gym', 'yoga class studio' ],
            'team'    => [ 'fitness trainers team gym', 'personal trainer portrait', 'gym coach with client' ],
            'about'   => [ 'gym interior modern design', 'fitness studio equipment', 'crossfit box interior' ],
            'generic' => [ 'fitness workout gym', 'exercise training session' ],
        ],

        // ── Universal fallback ──────────────────────────────────
        '_fallback' => [
            'hero'    => [ 'modern business professional', 'team collaboration office' ],
            'feature' => [ 'professional workspace laptop', 'business meeting' ],
            'team'    => [ 'professional team portrait', 'diverse team meeting' ],
            'about'   => [ 'modern office interior', 'professional workspace' ],
            'generic' => [ 'modern professional business' ],
        ],
    ];

    return $map;
}

/**
 * Resolve a single image for a given industry + role by querying Pexels.
 *
 * Tries each query in the cascade until results are returned.
 * Returns a single ViroBuilder_Image array, or null on failure.
 *
 * @param string $industry   Industry key.
 * @param string $role       Section role (hero, feature, team, etc.).
 * @param string $hint       Optional AI-generated specificity hint.
 * @param array  $exclude_ids  Pexels IDs already used (for dedup).
 * @param string $orientation  Preferred orientation.
 * @return array|null  Normalized image or null.
 */
function virobuilder_ai_resolve_image(
    string $industry,
    string $role,
    string $hint = '',
    array $exclude_ids = [],
    string $orientation = 'landscape'
): ?array {
    $provider = virobuilder_ai_get_image_provider();
    $queries  = virobuilder_ai_image_queries( $industry, $role, $hint );

    foreach ( $queries as $query ) {
        $results = $provider->search( $query, 8, $orientation );
        if ( empty( $results ) ) continue;

        // Filter out already-used images
        foreach ( $results as $img ) {
            $id = $img['pexels_id'] ?? 0;
            if ( $id && in_array( $id, $exclude_ids, true ) ) {
                continue;
            }
            return $img;
        }
    }

    return null;
}

/**
 * Resolve multiple images at once (batch), deduplicating across slots.
 *
 * @param string $industry
 * @param array  $slots  Array of [ 'role' => string, 'hint' => string, 'orientation' => string ]
 * @return array  Same-indexed array of ViroBuilder_Image|null.
 */
function virobuilder_ai_resolve_images_batch( string $industry, array $slots ): array {
    $used_ids = [];
    $results  = [];

    foreach ( $slots as $slot ) {
        $role        = $slot['role'] ?? 'generic';
        $hint        = $slot['hint'] ?? '';
        $orientation = $slot['orientation'] ?? 'landscape';

        $img = virobuilder_ai_resolve_image( $industry, $role, $hint, $used_ids, $orientation );
        if ( $img && ! empty( $img['pexels_id'] ) ) {
            $used_ids[] = $img['pexels_id'];
        }
        $results[] = $img;
    }

    return $results;
}
