<?php
/**
 * Stock photo provider for AI Quick-Build.
 *
 * Abstracts image search behind a provider interface so we can swap in
 * Openverse, AI generation, or other sources later. The Pexels provider
 * is the default.
 *
 * ARCHITECTURE NOTES:
 *   - All API calls happen server-side (key never exposed to the browser).
 *   - Results are cached in WP transients (1 h TTL) to stay within Pexels'
 *     200 req/h rate limit. A full page generation typically needs 3-6 queries.
 *   - The provider returns a normalized shape so downstream code never
 *     touches raw API responses.
 *
 * @package ViroBuilder
 */

defined( 'ABSPATH' ) || exit;
/**
 * Normalized image result shape.
 *
 * @typedef ViroBuilder_Image {
 *   url:          string  Full-size image URL (Pexels CDN, ~1200px wide)
 *   thumbnail:    string  Small preview (~280px wide)
 *   alt:          string  Descriptive alt text
 *   photographer: string  Credit name
 *   source_url:   string  Link back to Pexels page
 *   width:        int     Original image width
 *   height:       int     Original image height
 *   orientation:  string  'landscape' | 'portrait' | 'square'
 * }
 */

// ════════════════════════════════════════════════════════════════
// Provider interface
// ════════════════════════════════════════════════════════════════

interface ViroBuilder_Image_Provider {
    /**
     * Search for photos matching a query.
     *
     * @param string $query       Search terms (e.g. "modern dental clinic interior").
     * @param int    $count       Number of results to return (max 15).
     * @param string $orientation 'landscape' | 'portrait' | 'square' | '' (any).
     * @return array<ViroBuilder_Image>  Normalized results, may be fewer than $count.
     */
    public function search( string $query, int $count = 5, string $orientation = 'landscape' ): array;

    /**
     * Return the provider's human-readable name (for credits / UI).
     */
    public function name(): string;
}

// ════════════════════════════════════════════════════════════════
// Pexels provider
// ════════════════════════════════════════════════════════════════

class ViroBuilder_Pexels_Provider implements ViroBuilder_Image_Provider {

    private string $api_key;

    /**
     * @param string $api_key  Pexels API key. If empty, provider returns [].
     */
    public function __construct( string $api_key = '' ) {
        $this->api_key = $api_key;
    }

    public function name(): string {
        return 'Pexels';
    }

    public function search( string $query, int $count = 5, string $orientation = 'landscape' ): array {
        if ( empty( $this->api_key ) || empty( trim( $query ) ) ) {
            return [];
        }

        $count = max( 1, min( 15, $count ) );

        // Check transient cache first
        $cache_key = 'viro_pxl_' . md5( $query . '|' . $orientation . '|' . $count );
        $cached = get_transient( $cache_key );
        if ( is_array( $cached ) ) {
            return $cached;
        }

        $params = [
            'query'    => $query,
            'per_page' => $count,
        ];
        if ( in_array( $orientation, [ 'landscape', 'portrait', 'square' ], true ) ) {
            $params['orientation'] = $orientation;
        }

        $url = 'https://api.pexels.com/v1/search?' . http_build_query( $params );

        $response = wp_remote_get( $url, [
            'timeout' => 10,
            'headers' => [
                'Authorization' => $this->api_key,
            ],
        ] );

        if ( is_wp_error( $response ) ) {
            return [];
        }

        $code = wp_remote_retrieve_response_code( $response );
        if ( $code !== 200 ) {
            return [];
        }

        $body = json_decode( wp_remote_retrieve_body( $response ), true );
        if ( ! is_array( $body ) || empty( $body['photos'] ) ) {
            return [];
        }

        $results = [];
        foreach ( $body['photos'] as $photo ) {
            $w = (int) ( $photo['width'] ?? 0 );
            $h = (int) ( $photo['height'] ?? 0 );

            if ( $w > 0 && $h > 0 ) {
                $ratio = $w / $h;
                $orient = $ratio > 1.2 ? 'landscape' : ( $ratio < 0.8 ? 'portrait' : 'square' );
            } else {
                $orient = 'landscape';
            }

            $results[] = [
                'url'          => $photo['src']['large2x'] ?? $photo['src']['large'] ?? $photo['src']['original'] ?? '',
                'thumbnail'    => $photo['src']['medium'] ?? $photo['src']['small'] ?? '',
                'alt'          => $photo['alt'] ?? $query,
                'photographer' => $photo['photographer'] ?? '',
                'source_url'   => $photo['url'] ?? '',
                'width'        => $w,
                'height'       => $h,
                'orientation'  => $orient,
                'pexels_id'    => (int) ( $photo['id'] ?? 0 ),
            ];
        }

        // Cache for 1 hour
        set_transient( $cache_key, $results, HOUR_IN_SECONDS );

        return $results;
    }
}

// ════════════════════════════════════════════════════════════════
// Factory: get the configured provider
// ════════════════════════════════════════════════════════════════

/**
 * Returns the active image provider instance (singleton per request).
 */
function virobuilder_ai_get_image_provider(): ViroBuilder_Image_Provider {
    static $provider = null;
    if ( $provider !== null ) {
        return $provider;
    }

    $pexels_key = get_option( 'virobuilder_pexels_api_key', '' );
    $provider = new ViroBuilder_Pexels_Provider( $pexels_key );

    return $provider;
}
