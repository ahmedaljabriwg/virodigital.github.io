<?php
/**
 * ViroBuilder AI Chat Editor.
 *
 * Provides:
 *   1. AJAX endpoint for chat-based page edits
 *   2. AJAX endpoint for image re-resolution (after swap)
 *   3. The editor page renderer (split-screen: iframe + chat panel)
 *   4. Chat history storage in post meta
 *
 * @package ViroBuilder
 */

defined( 'ABSPATH' ) || exit;

require_once __DIR__ . '/editor-prompt.php';

class ViroBuilder_Chat_Editor {

    const AI_MODEL = 'claude-sonnet-4-6';

    private static ?self $instance = null;

    public static function instance(): self {
        if ( self::$instance === null ) {
            self::$instance = new self();
        }
        return self::$instance;
    }

    private function __construct() {
        // AJAX endpoints
        add_action( 'wp_ajax_virobuilder_chat_edit', [ $this, 'ajax_chat_edit' ] );
        add_action( 'wp_ajax_virobuilder_chat_history', [ $this, 'ajax_get_history' ] );
        add_action( 'wp_ajax_virobuilder_chat_resolve_images', [ $this, 'ajax_resolve_images' ] );
        add_action( 'wp_ajax_virobuilder_chat_publish', [ $this, 'ajax_chat_publish' ] );

        // Register the editor page route
        add_action( 'admin_menu', [ $this, 'register_editor_page' ] );

        // Handle the standalone editor URL
        add_action( 'admin_init', [ $this, 'maybe_render_editor' ] );
    }

    /**
     * Register a hidden admin page for the chat editor.
     */
    public function register_editor_page(): void {
        add_submenu_page(
            null, // hidden from menu
            'ViroBuilder Designer Editor',
            'Designer Editor',
            'edit_posts',
            'virobuilder-designer-edit',
            [ $this, 'render_editor_page' ]
        );
    }

    /**
     * Render the standalone editor BEFORE WordPress prints any admin chrome
     * (admin bar / side menu). Running on admin_init means our full-page
     * document is the entire response — a true fullscreen takeover.
     */
    public function maybe_render_editor(): void {
        // phpcs:ignore WordPress.Security.NonceVerification.Recommended -- read-only admin-page routing check; capability is enforced in render_editor_page()
        if ( ! isset( $_GET['page'] ) || sanitize_key( wp_unslash( $_GET['page'] ) ) !== 'virobuilder-designer-edit' ) {
            return;
        }
        $this->render_editor_page(); // outputs a full HTML document, then exit;
    }

    /**
     * Render the full-screen split editor (iframe + chat).
     */
    public function render_editor_page(): void {
        // phpcs:ignore WordPress.Security.NonceVerification.Recommended -- read-only id read; capability checked on the next line
        $post_id = absint( wp_unslash( $_GET['post_id'] ?? 0 ) );
        if ( ! $post_id || ! current_user_can( 'edit_post', $post_id ) ) {
            wp_die( 'Invalid post or insufficient permissions.' );
        }

        $post = get_post( $post_id );
        if ( ! $post ) {
            wp_die( 'Post not found.' );
        }

        $html = $post->post_content;
        $title = $post->post_title;
        $nonce = wp_create_nonce( 'virobuilder_nonce' );
        $is_published = ( $post->post_status === 'publish' );
        $view_url = get_permalink( $post_id );

        // Enqueue WordPress media library for image uploads
        wp_enqueue_media();

        // Register and enqueue the editor's stylesheet and script as proper
        // assets (instead of inline <style>/<script>). The script's dynamic
        // values are passed via wp_localize_script.
        wp_register_style( 'virobuilder-editor', VIROBUILDER_ASSETS_URL . 'css/editor.css', array(), VIROBUILDER_VERSION );
        wp_enqueue_style( 'virobuilder-editor' );
        wp_register_script( 'virobuilder-editor', VIROBUILDER_ASSETS_URL . 'js/editor.js', array( 'jquery', 'media-editor' ), VIROBUILDER_VERSION, true );
        wp_localize_script(
            'virobuilder-editor',
            'VBED',
            array(
                'ajax'         => admin_url( 'admin-ajax.php' ),
                'nonce'        => $nonce,
                'postId'       => (int) $post_id,
                'html'         => $html,
                'viewUrl'      => $view_url,
                'downloadName' => sanitize_file_name( $title ),
            )
        );
        wp_enqueue_script( 'virobuilder-editor' );

        ?>
        <!DOCTYPE html>
        <html <?php language_attributes(); ?>>
        <head>
            <meta charset="<?php bloginfo( 'charset' ); ?>">
            <meta name="viewport" content="width=device-width, initial-scale=1.0">
            <title><?php echo esc_html( $title ); ?> — ViroBuilder Editor</title>
            <?php
            wp_print_head_scripts(); // jQuery + media library (head part)
            wp_print_styles();       // prints the enqueued editor stylesheet + media styles
            ?>
        </head>
        <body>
            <div class="editor-layout">
                <!-- Top bar -->
                <div class="top-bar">
                    <div style="display:flex;align-items:center;gap:16px">
                        <div class="logo"><svg viewBox="0 0 40 44" fill="none" style="width:20px;height:22px;margin-right:2px"><path d="M6 40L20 6L34 40" stroke="#818cf8" stroke-width="3" stroke-linecap="round" stroke-linejoin="round"/><circle cx="20" cy="5" r="3.5" fill="#22d3ee"/></svg> ViroBuilder</div>
                        <div class="title"><?php echo esc_html( $title ); ?></div>
                    </div>
                    <div class="devices">
                        <button class="dev-btn active" data-device="desktop">Desktop</button>
                        <button class="dev-btn" data-device="tablet">Tablet</button>
                        <button class="dev-btn" data-device="phone">Phone</button>
                    </div>
                    <div class="mode-toggle">
                        <button class="mode-btn active" data-mode="select" title="Click page elements to edit text, images, and links">👆 Select</button>
                        <button class="mode-btn" data-mode="chat" title="Disable visual editing, chat only">💬 Chat</button>
                        <button class="mode-btn" data-mode="preview" title="Clean preview, no editing">👁️ Preview</button>
                    </div>
                    <div class="actions">
                        <div class="more-wrap">
                            <button class="tb-btn tb-btn-ghost" id="btn-more" title="More actions">⋯ More</button>
                            <div class="more-menu" id="more-menu">
                                <a href="<?php echo esc_url( get_permalink( $post_id ) ); ?>" target="_blank" class="more-item">
                                    <span class="mi-icon">↗</span>Open live preview
                                </a>
                                <button class="more-item" id="btn-export">
                                    <span class="mi-icon">⬇</span>Export as HTML
                                </button>
                                <button class="more-item" id="btn-import">
                                    <span class="mi-icon">⬆</span>Import HTML file
                                </button>
                                <input type="file" id="import-file" accept=".html,.htm" style="display:none">
                            </div>
                        </div>
                        <button class="tb-btn tb-btn-ghost" id="btn-undo" disabled title="Undo last change">↶</button>
                        <button class="tb-btn tb-btn-ghost" id="btn-save">Save draft</button>
                        <button class="tb-btn tb-btn-publish" id="btn-publish" data-published="<?php echo $is_published ? '1' : '0'; ?>">
                            <?php echo $is_published ? 'Update' : 'Publish'; ?>
                        </button>
                        <a href="<?php echo esc_url( admin_url( 'edit.php?post_type=page' ) ); ?>" class="tb-btn tb-btn-ghost" title="Exit editor">✕</a>
                    </div>
                </div>

                <!-- Preview -->
                <div class="preview-pane" id="preview-pane">
                    <iframe class="preview-frame" id="preview-frame"></iframe>
                </div>

                <!-- Chat -->
                <div class="chat-pane">
                    <div class="chat-header">
                        <h2><svg viewBox="0 0 40 44" fill="none" style="width:16px;height:18px;vertical-align:-2px;margin-right:4px"><path d="M6 40L20 6L34 40" stroke="#818cf8" stroke-width="3" stroke-linecap="round" stroke-linejoin="round"/><circle cx="20" cy="5" r="3.5" fill="#22d3ee"/></svg>Design Editor</h2>
                        <p>Describe any change — I'll update the page live.</p>
                    </div>
                    <div class="quick-actions" id="quick-actions">
                        <button class="qa-btn" data-prompt="Change the brand color to ">🎨 Colors</button>
                        <button class="qa-btn" data-prompt="Make the headline say '">✏️ Edit copy</button>
                        <button class="qa-btn" data-prompt="Replace the hero image with ">🖼️ Swap photo</button>
                        <button class="qa-btn" data-prompt="Add a testimonials section ">➕ Add section</button>
                        <button class="qa-btn" data-prompt="Remove the ">🗑️ Remove</button>
                        <button class="qa-btn" data-prompt="Move the ">↕️ Reorder</button>
                    </div>
                    <div class="selection-bar" id="selection-bar">
                        <img class="sel-thumb" id="sel-thumb" src="" alt="">
                        <div class="sel-text" id="sel-text"><b>Image selected</b> — chat edits will target this image</div>
                        <button class="sel-clear" id="sel-clear" title="Clear selection">&times;</button>
                    </div>
                    <div class="chat-messages" id="chat-messages">
                        <div class="msg msg-system">Page loaded. Tell me what to change.</div>
                    </div>
                    <div class="chat-input">
                        <div class="input-row">
                            <textarea id="chat-input" rows="1" placeholder="Describe a change…"></textarea>
                            <button class="send-btn" id="send-btn">
                                <svg viewBox="0 0 24 24"><path d="M22 2L11 13"/><path d="M22 2l-7 20-4-9-9-4 20-7z"/></svg>
                            </button>
                        </div>
                    </div>
                </div>
            </div>

            <?php wp_print_media_templates(); ?>
            <?php wp_print_footer_scripts(); ?>
        </body>
        </html>
        <?php
        exit; // Full page, no WP admin chrome
    }

    /**
     * AJAX: Publish (or update) the page — saves content and sets status to publish.
     */
    public function ajax_chat_publish(): void {
        check_ajax_referer( 'virobuilder_nonce' );

        $post_id = absint( $_POST['post_id'] ?? 0 );
        if ( ! $post_id || ! current_user_can( 'publish_posts' ) || ! current_user_can( 'edit_post', $post_id ) ) {
            wp_send_json_error( [ 'message' => 'Permission denied.' ], 403 );
        }

        // phpcs:ignore WordPress.Security.ValidatedSanitizedInput.InputNotSanitized -- full HTML document; nonce + edit_post capability verified above
        $current_html = wp_unslash( $_POST['current_html'] ?? '' );

        wp_update_post( [
            'ID'           => $post_id,
            'post_content' => $current_html,
            'post_status'  => 'publish',
        ] );
        update_post_meta( $post_id, '_virobuilder_designer_page', '1' );

        wp_send_json_success( [
            'published' => true,
            'view_url'  => get_permalink( $post_id ),
        ] );
    }

    /**
     * AJAX: Process a chat edit instruction.
     */
    public function ajax_chat_edit(): void {
        check_ajax_referer( 'virobuilder_nonce' );

        if ( ! current_user_can( 'edit_posts' ) ) {
            wp_send_json_error( [ 'message' => 'Permission denied' ], 403 );
        }

        $post_id     = absint( $_POST['post_id'] ?? 0 );
        $instruction = sanitize_textarea_field( wp_unslash( $_POST['instruction'] ?? '' ) );
        // phpcs:ignore WordPress.Security.ValidatedSanitizedInput.InputNotSanitized -- full HTML document; nonce + edit_post capability verified above
        $current_html = wp_unslash( $_POST['current_html'] ?? '' );

        if ( ! $post_id || ! current_user_can( 'edit_post', $post_id ) ) {
            wp_send_json_error( [ 'message' => 'Invalid post.' ], 400 );
        }

        // Special: save command (no AI call needed)
        if ( $instruction === '__save__' ) {
            wp_update_post( [
                'ID'           => $post_id,
                'post_content' => $current_html,
            ] );
            update_post_meta( $post_id, '_virobuilder_designer_page', '1' );
            wp_send_json_success( [ 'saved' => true ] );
            return;
        }

        if ( empty( $instruction ) ) {
            wp_send_json_error( [ 'message' => 'No instruction provided.' ], 400 );
        }

        // Get API key
        $api_key = get_option( 'virobuilder_ai_api_key', '' );
        if ( empty( $api_key ) ) {
            wp_send_json_error( [ 'message' => 'No API key configured.' ], 400 );
        }

        // Get chat history for context
        $history = get_post_meta( $post_id, '_virobuilder_chat_history', true );
        if ( ! is_array( $history ) ) $history = [];

        // Build messages
        $system  = virobuilder_editor_system_prompt();
        $messages = virobuilder_editor_build_messages( $current_html, $instruction, $history );

        // Call Claude
        $response = wp_remote_post( 'https://api.anthropic.com/v1/messages', [
            'timeout' => 300,
            'headers' => [
                'Content-Type'      => 'application/json',
                'x-api-key'         => $api_key,
                'anthropic-version' => '2023-06-01',
            ],
            'body' => wp_json_encode( [
                'model'      => self::AI_MODEL,
                'max_tokens' => 16000,
                'system'     => $system,
                'messages'   => $messages,
            ] ),
        ] );

        if ( is_wp_error( $response ) ) {
            wp_send_json_error( [ 'message' => 'AI request failed: ' . $response->get_error_message() ], 500 );
        }

        $code = wp_remote_retrieve_response_code( $response );
        $body = wp_remote_retrieve_body( $response );

        if ( $code !== 200 ) {
            $err = json_decode( $body, true );
            wp_send_json_error( [ 'message' => $err['error']['message'] ?? "HTTP $code" ], 500 );
        }

        $data = json_decode( $body, true );
        $new_html = '';
        foreach ( ( $data['content'] ?? [] ) as $block ) {
            if ( ( $block['type'] ?? '' ) === 'text' ) {
                $new_html .= $block['text'];
            }
        }

        // Strip code fences
        $new_html = preg_replace( '/^```html?\s*/i', '', $new_html );
        $new_html = preg_replace( '/\s*```\s*$/', '', $new_html );
        $new_html = trim( $new_html );

        // Extract just the HTML document — strip any AI preamble/explanation
        // before <!DOCTYPE or <html, and any trailing text after </html>
        $doctype_pos = stripos( $new_html, '<!DOCTYPE' );
        $html_pos = stripos( $new_html, '<html' );
        $start = false;
        if ( $doctype_pos !== false ) {
            $start = $doctype_pos;
        } elseif ( $html_pos !== false ) {
            $start = $html_pos;
        }
        if ( $start !== false && $start > 0 ) {
            $new_html = substr( $new_html, $start );
        }
        // Trim anything after the closing </html>
        $end_pos = stripos( $new_html, '</html>' );
        if ( $end_pos !== false ) {
            $new_html = substr( $new_html, 0, $end_pos + 7 );
        }
        $new_html = trim( $new_html );

        // Validate it's still HTML
        if ( stripos( $new_html, '<html' ) === false && stripos( $new_html, '<!DOCTYPE' ) === false ) {
            wp_send_json_error( [
                'message' => 'The AI could not complete that edit. Try rephrasing — for example, instead of "change the structure," try "move the about section above the services" or "add a testimonials section after the hero."',
            ], 500 );
        }

        // Resolve any new image placeholders
        if ( function_exists( 'virobuilder_ai_get_image_provider' ) && preg_match( '/\{\{[A-Z_0-9]+\}\}/', $new_html ) ) {
            $new_html = $this->resolve_image_placeholders( $new_html );
        }

        // Save chat history
        $history[] = [ 'role' => 'user', 'content' => $instruction ];
        $history[] = [ 'role' => 'assistant', 'content' => '(page updated)' ];
        // Keep last 20 exchanges max
        if ( count( $history ) > 40 ) {
            $history = array_slice( $history, -40 );
        }
        update_post_meta( $post_id, '_virobuilder_chat_history', $history );

        // Auto-save the HTML
        wp_update_post( [
            'ID'           => $post_id,
            'post_content' => $new_html,
        ] );
        update_post_meta( $post_id, '_virobuilder_designer_page', '1' );

        // Cost estimate
        $usage = $data['usage'] ?? [];
        $in = $usage['input_tokens'] ?? 0;
        $out = $usage['output_tokens'] ?? 0;
        $cost = ( $in * 0.003 / 1000 ) + ( $out * 0.015 / 1000 );

        wp_send_json_success( [
            'html'    => $new_html,
            'summary' => $this->generate_change_summary( $instruction ),
            'cost'    => number_format( $cost, 4 ),
            'usage'   => $usage,
        ] );
    }

    /**
     * Generate a human-readable summary of what changed.
     */
    private function generate_change_summary( string $instruction ): string {
        $lower = strtolower( $instruction );

        if ( strpos( $lower, 'color' ) !== false ) return '✓ Colors updated';
        if ( strpos( $lower, 'headline' ) !== false || strpos( $lower, 'heading' ) !== false ) return '✓ Headline updated';
        if ( strpos( $lower, 'image' ) !== false || strpos( $lower, 'photo' ) !== false ) return '✓ Image updated';
        if ( strpos( $lower, 'add' ) !== false ) return '✓ Section added';
        if ( strpos( $lower, 'remove' ) !== false || strpos( $lower, 'delete' ) !== false ) return '✓ Section removed';
        if ( strpos( $lower, 'move' ) !== false || strpos( $lower, 'reorder' ) !== false ) return '✓ Sections reordered';
        if ( strpos( $lower, 'font' ) !== false ) return '✓ Typography updated';

        return '✓ Page updated';
    }

    /**
     * Resolve {{IMAGE_SLOT}} placeholders via Pexels.
     */
    private function resolve_image_placeholders( string $html ): string {
        $pexels_key = get_option( 'virobuilder_pexels_api_key', '' );
        if ( empty( $pexels_key ) ) return $html;

        $provider = virobuilder_ai_get_image_provider();

        if ( preg_match_all( '/\{\{([A-Z_0-9]+)\}\}/', $html, $matches ) ) {
            foreach ( $matches[1] as $slot ) {
                // Check for data-viro-image-query on nearby img tags
                $query = '';
                if ( preg_match( '/data-viro-image-query="([^"]+)"/', $html, $qm ) ) {
                    $query = $qm[1];
                }
                if ( empty( $query ) ) {
                    // Derive query from slot name
                    $query = strtolower( str_replace( '_', ' ', $slot ) );
                }

                $results = $provider->search( $query, 5, 'landscape' );
                if ( ! empty( $results[0]['url'] ) ) {
                    $html = str_replace( '{{' . $slot . '}}', esc_url( $results[0]['url'] ), $html );
                }
            }
        }

        return $html;
    }

    /**
     * AJAX: Get chat history for a post.
     */
    public function ajax_get_history(): void {
        check_ajax_referer( 'virobuilder_nonce' );
        $post_id = absint( $_POST['post_id'] ?? 0 );
        if ( ! $post_id || ! current_user_can( 'edit_post', $post_id ) ) {
            wp_send_json_error( [ 'message' => 'Invalid post.' ], 400 );
        }
        $history = get_post_meta( $post_id, '_virobuilder_chat_history', true );
        wp_send_json_success( [ 'history' => is_array( $history ) ? $history : [] ] );
    }

    /**
     * AJAX: Re-resolve image placeholders in current HTML.
     */
    public function ajax_resolve_images(): void {
        check_ajax_referer( 'virobuilder_nonce' );

        if ( ! current_user_can( 'edit_posts' ) ) {
            wp_send_json_error( [ 'message' => 'Permission denied' ], 403 );
        }

        // phpcs:ignore WordPress.Security.ValidatedSanitizedInput.InputNotSanitized -- full HTML document; nonce + capability verified in this handler
        $html = wp_unslash( $_POST['html'] ?? '' );
        $resolved = $this->resolve_image_placeholders( $html );
        wp_send_json_success( [ 'html' => $resolved ] );
    }
}
