<?php
/**
 * ViroBuilder AI Chat Editor.
 *
 * Provides:
 *   1. AJAX endpoint for chat-based page edits
 *   2. AJAX endpoint for image re-resolution (after swap)
 *   3. The editor page renderer (split-screen: iframe + chat panel)
 *   4. Chat history storage in post meta
 *
 * @package ViroBuilder
 */

defined( 'ABSPATH' ) || exit;

require_once __DIR__ . '/editor-prompt.php';

class ViroBuilder_Chat_Editor {

    const AI_MODEL = 'claude-sonnet-4-6';

    private static ?self $instance = null;

    public static function instance(): self {
        if ( self::$instance === null ) {
            self::$instance = new self();
        }
        return self::$instance;
    }

    private function __construct() {
        // AJAX endpoints
        add_action( 'wp_ajax_virobuilder_chat_edit', [ $this, 'ajax_chat_edit' ] );
        add_action( 'wp_ajax_virobuilder_chat_history', [ $this, 'ajax_get_history' ] );
        add_action( 'wp_ajax_virobuilder_chat_resolve_images', [ $this, 'ajax_resolve_images' ] );
        add_action( 'wp_ajax_virobuilder_chat_publish', [ $this, 'ajax_chat_publish' ] );

        // Register the editor page route
        add_action( 'admin_menu', [ $this, 'register_editor_page' ] );

        // Handle the standalone editor URL
        add_action( 'admin_init', [ $this, 'maybe_render_editor' ] );
    }

    /**
     * Register a hidden admin page for the chat editor.
     */
    public function register_editor_page(): void {
        add_submenu_page(
            null, // hidden from menu
            'ViroBuilder Designer Editor',
            'Designer Editor',
            'edit_posts',
            'virobuilder-designer-edit',
            [ $this, 'render_editor_page' ]
        );
    }

    /**
     * Render the standalone editor BEFORE WordPress prints any admin chrome
     * (admin bar / side menu). Running on admin_init means our full-page
     * document is the entire response — a true fullscreen takeover.
     */
    public function maybe_render_editor(): void {
        // phpcs:ignore WordPress.Security.NonceVerification.Recommended -- read-only admin-page routing check; capability is enforced in render_editor_page()
        if ( ! isset( $_GET['page'] ) || sanitize_key( wp_unslash( $_GET['page'] ) ) !== 'virobuilder-designer-edit' ) {
            return;
        }
        $this->render_editor_page(); // outputs a full HTML document, then exit;
    }

    /**
     * Render the full-screen split editor (iframe + chat).
     */
    public function render_editor_page(): void {
        // phpcs:ignore WordPress.Security.NonceVerification.Recommended -- read-only id read; capability checked on the next line
        $post_id = absint( wp_unslash( $_GET['post_id'] ?? 0 ) );
        if ( ! $post_id || ! current_user_can( 'edit_post', $post_id ) ) {
            wp_die( 'Invalid post or insufficient permissions.' );
        }

        $post = get_post( $post_id );
        if ( ! $post ) {
            wp_die( 'Post not found.' );
        }

        $html = $post->post_content;
        $title = $post->post_title;
        $nonce = wp_create_nonce( 'virobuilder_nonce' );
        $is_published = ( $post->post_status === 'publish' );
        $view_url = get_permalink( $post_id );

        // Enqueue WordPress media library for image uploads
        wp_enqueue_media();

        ?>
        <!DOCTYPE html>
        <html <?php language_attributes(); ?>>
        <head>
            <meta charset="<?php bloginfo( 'charset' ); ?>">
            <meta name="viewport" content="width=device-width, initial-scale=1.0">
            <title><?php echo esc_html( $title ); ?> — ViroBuilder Editor</title>
            <?php wp_print_head_scripts(); // jQuery + media library (head part) ?>
            <style>
                *{margin:0;padding:0;box-sizing:border-box}
                html{overflow:hidden;height:100%}
                body{font-family:-apple-system,BlinkMacSystemFont,'Segoe UI',Roboto,Helvetica,Arial,sans-serif;background:#0f172a;color:#e2e8f0;
                    overflow:hidden;height:100%;margin:0;padding:0}

                .editor-layout{position:fixed;inset:0;display:grid;grid-template-columns:1fr 380px;
                    grid-template-rows:52px minmax(0,1fr);overflow:hidden}
                /* Second row must constrain its children so the chat input never overflows */
                .editor-layout > .preview-pane,
                .editor-layout > .chat-pane{min-height:0;height:100%;overflow:hidden}

                /* Top bar */
                .top-bar{grid-column:1/-1;background:#1e293b;border-bottom:1px solid rgba(255,255,255,.08);
                    display:flex;align-items:center;justify-content:space-between;padding:0 16px;gap:12px}
                .top-bar .logo{font-weight:700;font-size:13px;color:#94a3b8;display:flex;align-items:center;gap:8px}
                .top-bar .logo span{color:#38bdf8}
                .top-bar .title{font-size:13px;color:#e2e8f0;font-weight:500}
                .top-bar .actions{display:flex;gap:8px;align-items:center}
                .tb-btn{padding:6px 14px;border-radius:6px;font-size:12px;font-weight:600;cursor:pointer;
                    border:none;font-family:inherit;transition:all .15s}
                .tb-btn-ghost{background:rgba(255,255,255,.06);color:#94a3b8}
                .tb-btn-ghost:hover{background:rgba(255,255,255,.1);color:#e2e8f0}
                .tb-btn-primary{background:#3b82f6;color:#fff}
                .tb-btn-primary:hover{background:#2563eb}
                #btn-save{background:rgba(255,255,255,.06);color:#cbd5e1}
                #btn-save:hover{background:rgba(255,255,255,.1);color:#fff}
                .tb-btn-publish{background:#10b981;color:#fff;display:inline-flex;align-items:center;gap:6px}
                .tb-btn-publish:hover{background:#059669}
                .tb-btn-publish:disabled{opacity:.6;cursor:not-allowed}

                /* Device switcher */
                .devices{display:flex;gap:2px;background:rgba(255,255,255,.04);border-radius:6px;padding:2px}
                .dev-btn{padding:5px 10px;border-radius:4px;font-size:11px;cursor:pointer;
                    border:none;background:transparent;color:#64748b;font-family:inherit;transition:all .12s}
                .dev-btn.active{background:rgba(255,255,255,.1);color:#e2e8f0}

                /* Preview pane */
                .preview-pane{background:#1e293b;display:flex;align-items:center;justify-content:center;
                    overflow:hidden;position:relative}
                .preview-frame{width:100%;height:100%;border:none;background:#fff;transition:max-width .3s ease,
                    border-radius .3s;display:block;margin:0 auto}
                .preview-pane.device-tablet .preview-frame{max-width:768px;border-radius:8px;height:calc(100% - 24px)}
                .preview-pane.device-phone .preview-frame{max-width:375px;border-radius:16px;height:calc(100% - 24px)}

                /* Chat pane */
                .chat-pane{background:#0f172a;border-left:1px solid rgba(255,255,255,.06);
                    display:flex;flex-direction:column;overflow:hidden;min-height:0}

                .chat-header{padding:16px;border-bottom:1px solid rgba(255,255,255,.06);flex-shrink:0}
                .chat-header h2{font-size:14px;font-weight:600;color:#e2e8f0;margin-bottom:4px}
                .chat-header p{font-size:12px;color:#64748b;line-height:1.5}

                /* Quick actions */
                .quick-actions{padding:12px 16px;border-bottom:1px solid rgba(255,255,255,.04);
                    display:flex;flex-wrap:wrap;gap:6px;flex-shrink:0}
                .qa-btn{padding:5px 11px;border-radius:100px;font-size:11px;font-weight:500;
                    cursor:pointer;border:1px solid rgba(255,255,255,.1);background:transparent;
                    color:#94a3b8;font-family:inherit;transition:all .15s;white-space:nowrap}
                .qa-btn:hover{border-color:rgba(255,255,255,.2);color:#e2e8f0;background:rgba(255,255,255,.04)}

                /* Messages area */
                .chat-messages{flex:1;min-height:0;overflow-y:auto;padding:16px;display:flex;flex-direction:column;gap:12px}
                .chat-messages::-webkit-scrollbar{width:4px}
                .chat-messages::-webkit-scrollbar-thumb{background:rgba(255,255,255,.1);border-radius:2px}
                .chat-msg-hint{align-self:stretch;background:rgba(34,211,238,.07);
                    border:1px solid rgba(34,211,238,.22);border-radius:12px;padding:13px 15px}
                .chat-msg-hint .hint-body{font-size:13px;color:#cbd5e1;line-height:1.55}
                .chat-msg-hint .hint-body b{color:#67e8f9;font-weight:600}
                .chat-msg-hint .hint-actions{margin-top:10px}
                .chat-msg-hint .hint-send{background:rgba(255,255,255,.06);border:1px solid rgba(255,255,255,.14);
                    color:#94a3b8;font-size:12px;padding:6px 12px;border-radius:7px;cursor:pointer;
                    font-family:inherit;transition:all .15s}
                .chat-msg-hint .hint-send:hover{background:rgba(255,255,255,.1);color:#e2e8f0}

                .msg{max-width:92%;border-radius:12px;padding:10px 14px;font-size:13px;line-height:1.55}
                .msg-user{background:#1e3a5f;color:#e2e8f0;align-self:flex-end;border-bottom-right-radius:4px}
                .msg-ai{background:#1e293b;color:#cbd5e1;align-self:flex-start;border-bottom-left-radius:4px;
                    border:1px solid rgba(255,255,255,.06)}
                .msg-system{background:transparent;color:#475569;font-size:12px;text-align:center;
                    align-self:center;font-style:italic}
                .msg-ai .change-summary{font-weight:500;color:#38bdf8}

                /* Typing indicator */
                /* (typing indicator replaced by progress widget) */

                /* Input area */
                .chat-input{padding:14px 16px 22px;border-top:1px solid rgba(255,255,255,.06);flex-shrink:0;background:#0f172a}
                .input-row{display:flex;gap:8px;align-items:flex-end}
                .input-row textarea{flex:1;background:#1e293b;border:1px solid rgba(255,255,255,.1);
                    border-radius:12px;padding:13px 15px;color:#e2e8f0;font-family:inherit;font-size:14px;
                    line-height:1.5;resize:none;outline:none;transition:border-color .15s;
                    min-height:54px;max-height:140px}
                .input-row textarea:focus{border-color:rgba(59,130,246,.5)}
                .input-row textarea::placeholder{color:#475569}
                .send-btn{width:48px;height:54px;border-radius:12px;background:#3b82f6;border:none;
                    cursor:pointer;display:flex;align-items:center;justify-content:center;flex:none;
                    transition:background .15s}
                .send-btn:hover{background:#2563eb}
                .send-btn:disabled{opacity:.4;cursor:not-allowed}
                .send-btn svg{width:18px;height:18px;stroke:#fff;fill:none;stroke-width:2}

                .chat-cost{padding:6px 16px;font-size:11px;color:#475569;text-align:center;
                    border-top:1px solid rgba(255,255,255,.04)}

                /* Progress widget */
                .progress-widget{align-self:flex-start;max-width:85%;background:#1e293b;
                    border:1px solid rgba(255,255,255,.06);border-radius:12px;
                    padding:14px 16px;border-bottom-left-radius:4px}
                .pw-bar-track{height:3px;background:rgba(255,255,255,.06);border-radius:2px;
                    overflow:hidden;margin-bottom:10px}
                .pw-bar-fill{height:100%;background:linear-gradient(90deg,#818cf8,#22d3ee);
                    border-radius:2px;width:0%;transition:width .8s ease-out}
                .pw-step{display:flex;align-items:center;gap:8px;font-size:13px;
                    transition:opacity .2s,transform .2s}
                .pw-icon{font-size:15px;flex:none;width:22px;text-align:center}
                .pw-text{color:#94a3b8}
                .pw-timer{font-size:10px;color:#374151;margin-top:6px;font-family:monospace;
                    letter-spacing:.05em}

                /* Selected element indicator */
                .selection-bar{padding:8px 16px;border-bottom:1px solid rgba(255,255,255,.06);
                    flex-shrink:0;display:none;align-items:center;gap:8px;
                    background:rgba(34,211,238,.04);font-size:12px;color:#94a3b8}
                .selection-bar.active{display:flex}
                .selection-bar .sel-thumb{width:32px;height:32px;border-radius:6px;
                    object-fit:cover;border:1px solid rgba(255,255,255,.1)}
                .selection-bar .sel-text{flex:1;overflow:hidden;text-overflow:ellipsis;white-space:nowrap}
                .selection-bar .sel-text b{color:#22d3ee;font-weight:500}
                .selection-bar .sel-clear{background:none;border:none;color:#475569;
                    cursor:pointer;font-size:16px;padding:0 4px}

                /* Mode toggle */
                .mode-toggle{display:flex;gap:2px;background:rgba(255,255,255,.04);border-radius:6px;padding:2px}
                .mode-btn{padding:5px 10px;border-radius:4px;font-size:11px;cursor:pointer;
                    border:none;background:transparent;color:#64748b;font-family:inherit;transition:all .12s}
                .mode-btn.active{background:rgba(255,255,255,.1);color:#e2e8f0}

                /* Pexels popover (positioned over the iframe container) */
                .pexels-popover{position:absolute;z-index:60;background:#1e293b;border:1px solid rgba(255,255,255,.1);
                    border-radius:12px;box-shadow:0 12px 40px rgba(0,0,0,.4);width:360px;max-height:420px;
                    overflow:hidden;display:flex;flex-direction:column}
                .pexels-popover .pp-header{padding:12px 14px;border-bottom:1px solid rgba(255,255,255,.06);
                    display:flex;justify-content:space-between;align-items:center}
                .pexels-popover .pp-header span{font-size:13px;font-weight:600;color:#e2e8f0}
                .pexels-popover .pp-close{background:none;border:none;color:#64748b;font-size:18px;cursor:pointer}
                .pexels-popover .pp-search{display:flex;gap:6px;padding:10px 14px}
                .pexels-popover .pp-search input{flex:1;background:#0f172a;border:1px solid rgba(255,255,255,.1);
                    border-radius:6px;padding:7px 10px;color:#e2e8f0;font-size:12px;font-family:inherit;outline:none}
                .pexels-popover .pp-search button{padding:7px 12px;background:#3b82f6;color:#fff;border:none;
                    border-radius:6px;font-size:12px;cursor:pointer;font-family:inherit}
                .pexels-popover .pp-grid{display:grid;grid-template-columns:1fr 1fr 1fr;gap:6px;
                    padding:8px 14px 14px;overflow-y:auto;max-height:280px}
                .pexels-popover .pp-grid img{width:100%;aspect-ratio:1;object-fit:cover;border-radius:6px;
                    cursor:pointer;transition:opacity .15s}
                .pexels-popover .pp-grid img:hover{opacity:.8}
                .pexels-popover .pp-status{padding:8px 14px;font-size:11px;color:#64748b;text-align:center}
                .pexels-popover .pp-upload{padding:8px 14px 12px;border-top:1px solid rgba(255,255,255,.06)}
                .pexels-popover .pp-upload button{width:100%;padding:7px;background:rgba(255,255,255,.06);
                    border:1px solid rgba(255,255,255,.08);border-radius:6px;color:#94a3b8;font-size:12px;
                    cursor:pointer;font-family:inherit}

                /* Link edit popover */
                .link-popover{position:absolute;z-index:60;background:#1e293b;border:1px solid rgba(255,255,255,.1);
                    border-radius:10px;box-shadow:0 12px 40px rgba(0,0,0,.4);width:300px;padding:14px}
                .link-popover label{display:block;font-size:11px;color:#94a3b8;margin-bottom:4px;font-weight:500}
                .link-popover input,.link-popover select{width:100%;background:#0f172a;border:1px solid rgba(255,255,255,.1);
                    border-radius:6px;padding:7px 10px;color:#e2e8f0;font-size:12px;font-family:inherit;
                    outline:none;margin-bottom:10px}
                .link-popover .lp-actions{display:flex;gap:6px;justify-content:flex-end}
                .link-popover .lp-actions button{padding:6px 14px;border-radius:6px;font-size:12px;
                    cursor:pointer;border:none;font-family:inherit}
                .link-popover .lp-cancel{background:rgba(255,255,255,.06);color:#94a3b8}
                .link-popover .lp-apply{background:#3b82f6;color:#fff}
                /* destination badge — shows where the link currently goes */
                .lp-dest{display:flex;gap:10px;align-items:flex-start;padding:10px 12px;border-radius:8px;
                    margin-bottom:12px;background:rgba(255,255,255,.04);border:1px solid rgba(255,255,255,.07)}
                .lp-dest-icon{font-size:17px;line-height:1.2;flex:none}
                .lp-dest-label{font-size:12px;color:#e2e8f0;font-weight:600;line-height:1.3}
                .lp-dest-detail{font-size:11px;color:#94a3b8;margin-top:2px;word-break:break-all}
                .lp-dest-none{background:rgba(239,68,68,.08);border-color:rgba(239,68,68,.25)}
                .lp-dest-none .lp-dest-label{color:#fca5a5}
                .lp-dest-scroll{background:rgba(34,211,238,.07);border-color:rgba(34,211,238,.22)}
                .lp-dest-external{background:rgba(129,140,248,.07);border-color:rgba(129,140,248,.22)}

                /* More dropdown menu */
                .more-wrap{position:relative;display:inline-block}
                .more-menu{display:none;position:absolute;top:100%;right:0;margin-top:6px;
                    background:#1e293b;border:1px solid rgba(255,255,255,.1);border-radius:10px;
                    box-shadow:0 12px 40px rgba(0,0,0,.4);min-width:220px;z-index:80;
                    padding:6px;overflow:hidden}
                .more-menu.open{display:block}
                .more-item{display:flex;align-items:center;gap:10px;width:100%;padding:9px 12px;
                    background:transparent;border:none;color:#94a3b8;font-size:13px;cursor:pointer;
                    font-family:inherit;border-radius:6px;text-align:left;transition:background .12s;
                    text-decoration:none}
                .more-item:hover{background:rgba(255,255,255,.06);color:#e2e8f0}
                .more-item .mi-icon{font-size:14px;width:20px;text-align:center;flex:none}
                .more-item .mi-size{font-size:11px;color:#475569;margin-left:auto}
                .more-divider{height:1px;background:rgba(255,255,255,.06);margin:6px 8px}
                .more-label{font-size:10px;text-transform:uppercase;letter-spacing:.08em;
                    color:#475569;padding:6px 12px 4px;font-weight:600}
                @keyframes viro-spin{to{transform:rotate(360deg)}}

                /* Text formatting toolbar */
                .text-toolbar{position:absolute;z-index:60;background:#1e293b;
                    border:1px solid rgba(255,255,255,.12);border-radius:10px;
                    box-shadow:0 8px 32px rgba(0,0,0,.4);padding:6px 8px;
                    display:flex;align-items:center;gap:4px;flex-wrap:nowrap}
                .text-toolbar::after{content:"";position:absolute;bottom:-6px;left:50%;
                    transform:translateX(-50%);width:12px;height:6px;
                    background:#1e293b;clip-path:polygon(0 0,100% 0,50% 100%)}
                .tt-sep{width:1px;height:22px;background:rgba(255,255,255,.08);margin:0 2px}
                .tt-btn{background:transparent;border:1px solid transparent;color:#94a3b8;
                    cursor:pointer;padding:4px 6px;border-radius:5px;font-size:13px;
                    font-family:inherit;transition:all .12s;display:flex;align-items:center;
                    justify-content:center;min-width:28px;height:28px}
                .tt-btn:hover{background:rgba(255,255,255,.06);color:#e2e8f0}
                .tt-btn.active{background:rgba(129,140,248,.15);color:#818cf8;border-color:rgba(129,140,248,.3)}
                .tt-select{background:#0f172a;border:1px solid rgba(255,255,255,.1);
                    color:#94a3b8;padding:3px 6px;border-radius:5px;font-size:11px;
                    font-family:inherit;cursor:pointer;height:28px;outline:none}
                .tt-select:focus{border-color:rgba(129,140,248,.4)}
                .tt-color{width:22px;height:22px;border-radius:50%;border:2px solid rgba(255,255,255,.15);
                    cursor:pointer;padding:0;overflow:hidden;position:relative}
                .tt-color input{position:absolute;inset:-4px;width:32px;height:32px;
                    border:none;cursor:pointer;opacity:0}
                .tt-size{width:48px}
            </style>
        </head>
        <body>
            <div class="editor-layout">
                <!-- Top bar -->
                <div class="top-bar">
                    <div style="display:flex;align-items:center;gap:16px">
                        <div class="logo"><svg viewBox="0 0 40 44" fill="none" style="width:20px;height:22px;margin-right:2px"><path d="M6 40L20 6L34 40" stroke="#818cf8" stroke-width="3" stroke-linecap="round" stroke-linejoin="round"/><circle cx="20" cy="5" r="3.5" fill="#22d3ee"/></svg> ViroBuilder</div>
                        <div class="title"><?php echo esc_html( $title ); ?></div>
                    </div>
                    <div class="devices">
                        <button class="dev-btn active" data-device="desktop">Desktop</button>
                        <button class="dev-btn" data-device="tablet">Tablet</button>
                        <button class="dev-btn" data-device="phone">Phone</button>
                    </div>
                    <div class="mode-toggle">
                        <button class="mode-btn active" data-mode="select" title="Click page elements to edit text, images, and links">👆 Select</button>
                        <button class="mode-btn" data-mode="chat" title="Disable visual editing, chat only">💬 Chat</button>
                        <button class="mode-btn" data-mode="preview" title="Clean preview, no editing">👁️ Preview</button>
                    </div>
                    <div class="actions">
                        <div class="more-wrap">
                            <button class="tb-btn tb-btn-ghost" id="btn-more" title="More actions">⋯ More</button>
                            <div class="more-menu" id="more-menu">
                                <a href="<?php echo esc_url( get_permalink( $post_id ) ); ?>" target="_blank" class="more-item">
                                    <span class="mi-icon">↗</span>Open live preview
                                </a>
                                <button class="more-item" id="btn-export">
                                    <span class="mi-icon">⬇</span>Export as HTML
                                </button>
                                <button class="more-item" id="btn-import">
                                    <span class="mi-icon">⬆</span>Import HTML file
                                </button>
                                <input type="file" id="import-file" accept=".html,.htm" style="display:none">
                            </div>
                        </div>
                        <button class="tb-btn tb-btn-ghost" id="btn-undo" disabled title="Undo last change">↶</button>
                        <button class="tb-btn tb-btn-ghost" id="btn-save">Save draft</button>
                        <button class="tb-btn tb-btn-publish" id="btn-publish" data-published="<?php echo $is_published ? '1' : '0'; ?>">
                            <?php echo $is_published ? 'Update' : 'Publish'; ?>
                        </button>
                        <a href="<?php echo esc_url( admin_url( 'edit.php?post_type=page' ) ); ?>" class="tb-btn tb-btn-ghost" title="Exit editor">✕</a>
                    </div>
                </div>

                <!-- Preview -->
                <div class="preview-pane" id="preview-pane">
                    <iframe class="preview-frame" id="preview-frame"></iframe>
                </div>

                <!-- Chat -->
                <div class="chat-pane">
                    <div class="chat-header">
                        <h2><svg viewBox="0 0 40 44" fill="none" style="width:16px;height:18px;vertical-align:-2px;margin-right:4px"><path d="M6 40L20 6L34 40" stroke="#818cf8" stroke-width="3" stroke-linecap="round" stroke-linejoin="round"/><circle cx="20" cy="5" r="3.5" fill="#22d3ee"/></svg>Design Editor</h2>
                        <p>Describe any change — I'll update the page live.</p>
                    </div>
                    <div class="quick-actions" id="quick-actions">
                        <button class="qa-btn" data-prompt="Change the brand color to ">🎨 Colors</button>
                        <button class="qa-btn" data-prompt="Make the headline say '">✏️ Edit copy</button>
                        <button class="qa-btn" data-prompt="Replace the hero image with ">🖼️ Swap photo</button>
                        <button class="qa-btn" data-prompt="Add a testimonials section ">➕ Add section</button>
                        <button class="qa-btn" data-prompt="Remove the ">🗑️ Remove</button>
                        <button class="qa-btn" data-prompt="Move the ">↕️ Reorder</button>
                    </div>
                    <div class="selection-bar" id="selection-bar">
                        <img class="sel-thumb" id="sel-thumb" src="" alt="">
                        <div class="sel-text" id="sel-text"><b>Image selected</b> — chat edits will target this image</div>
                        <button class="sel-clear" id="sel-clear" title="Clear selection">&times;</button>
                    </div>
                    <div class="chat-messages" id="chat-messages">
                        <div class="msg msg-system">Page loaded. Tell me what to change.</div>
                    </div>
                    <div class="chat-input">
                        <div class="input-row">
                            <textarea id="chat-input" rows="1" placeholder="Describe a change…"></textarea>
                            <button class="send-btn" id="send-btn">
                                <svg viewBox="0 0 24 24"><path d="M22 2L11 13"/><path d="M22 2l-7 20-4-9-9-4 20-7z"/></svg>
                            </button>
                        </div>
                    </div>
                </div>
            </div>

            <script>
            (function() {
                // The layout is position:fixed;inset:0 so it fills the visual viewport exactly.
                // On some mobile browsers the visualViewport API gives a more accurate height
                // (accounting for on-screen keyboards / dynamic toolbars) — sync to it when present.
                function syncHeight() {
                    var layout = document.querySelector('.editor-layout');
                    if (!layout) return;
                    var h = (window.visualViewport && window.visualViewport.height) ? window.visualViewport.height : window.innerHeight;
                    layout.style.height = h + 'px';
                }
                syncHeight();
                window.addEventListener('resize', syncHeight);
                if (window.visualViewport) window.visualViewport.addEventListener('resize', syncHeight);

                var AJAX = '<?php echo esc_url( admin_url( 'admin-ajax.php' ) ); ?>';
                var NONCE = '<?php echo esc_js( $nonce ); ?>';
                var POST_ID = <?php echo (int) $post_id; ?>;
                var currentHtml = <?php echo wp_json_encode( $html ); ?>;
                var htmlHistory = [currentHtml];
                
                var sending = false;
                var editMode = 'select'; // 'select' | 'chat' | 'preview'
                var activePopover = null;
                var selectedImageInfo = null; // {section, index, alt, src}

                var iframe = document.getElementById('preview-frame');
                var messagesDiv = document.getElementById('chat-messages');
                var input = document.getElementById('chat-input');
                var sendBtn = document.getElementById('send-btn');
                var undoBtn = document.getElementById('btn-undo');
                var saveBtn = document.getElementById('btn-save');
                var previewPane = document.getElementById('preview-pane');

                // ═══════════════════════════════════════════════
                // CORE: Render, serialize, state
                // ═══════════════════════════════════════════════

                function renderPage(html) {
                    try {
                        var doc = iframe.contentDocument || iframe.contentWindow.document;
                        doc.open(); doc.write(html); doc.close();
                    } catch(e) {
                        var blob = new Blob([html], {type:'text/html'});
                        iframe.src = URL.createObjectURL(blob);
                    }
                    // Re-inject visual editing layer after render
                    setTimeout(function(){ injectEditingLayer(); }, 100);
                }

                function serializeIframe() {
                    try {
                        var doc = iframe.contentDocument;
                        // Remove editing artifacts before serializing
                        doc.querySelectorAll('.viro-edit-highlight,.viro-edit-label').forEach(function(e){e.remove()});
                        doc.querySelectorAll('[contenteditable]').forEach(function(e){e.removeAttribute('contenteditable')});
                        doc.querySelectorAll('.viro-editing').forEach(function(e){e.classList.remove('viro-editing')});
                        // Remove injected style
                        var injectedStyle = doc.getElementById('viro-edit-css');
                        if (injectedStyle) injectedStyle.remove();
                        return '<!DOCTYPE html>\n' + doc.documentElement.outerHTML;
                    } catch(e) { return currentHtml; }
                }

                function pushState(html) {
                    htmlHistory.push(currentHtml);
                    currentHtml = html;
                    undoBtn.disabled = false;
                    debouncedSave();
                }

                var saveTimer = null;
                function debouncedSave() {
                    if (saveTimer) clearTimeout(saveTimer);
                    saveTimer = setTimeout(autoSave, 1500);
                }

                function autoSave() {
                    var fd = new FormData();
                    fd.append('action', 'virobuilder_chat_edit');
                    fd.append('_ajax_nonce', NONCE);
                    fd.append('post_id', POST_ID);
                    fd.append('instruction', '__save__');
                    fd.append('current_html', currentHtml);
                    fetch(AJAX, {method:'POST', body:fd}).catch(function(){});
                }

                renderPage(currentHtml);

                // ═══════════════════════════════════════════════
                // MODE TOGGLE
                // ═══════════════════════════════════════════════

                document.querySelectorAll('.mode-btn').forEach(function(btn) {
                    btn.addEventListener('click', function() {
                        editMode = btn.dataset.mode;
                        document.querySelectorAll('.mode-btn').forEach(function(b){b.classList.remove('active')});
                        btn.classList.add('active');

                        // Toggle chat pane visibility
                        var chatPane = document.querySelector('.chat-pane');
                        if (editMode === 'preview') {
                            chatPane.style.display = 'none';
                            document.querySelector('.editor-layout').style.gridTemplateColumns = '1fr';
                        } else {
                            chatPane.style.display = '';
                            document.querySelector('.editor-layout').style.gridTemplateColumns = '1fr 380px';
                        }

                        // Re-inject or remove editing layer
                        injectEditingLayer();
                    });
                });

                // ═══════════════════════════════════════════════
                // DEVICE SWITCHER
                // ═══════════════════════════════════════════════

                document.querySelectorAll('.dev-btn').forEach(function(btn) {
                    btn.addEventListener('click', function() {
                        document.querySelectorAll('.dev-btn').forEach(function(b){b.classList.remove('active')});
                        btn.classList.add('active');
                        previewPane.className = 'preview-pane' + (btn.dataset.device !== 'desktop' ? ' device-'+btn.dataset.device : '');
                    });
                });

                // ═══════════════════════════════════════════════
                // VISUAL EDITING LAYER (injected into iframe)
                // ═══════════════════════════════════════════════

                function injectEditingLayer() {
                    var doc;
                    try { doc = iframe.contentDocument; } catch(e) { return; }
                    if (!doc || !doc.body) return;

                    // Remove existing
                    var old = doc.getElementById('viro-edit-css');
                    if (old) old.remove();

                    if (editMode !== 'select') return;

                    // Inject CSS for hover highlights
                    var style = doc.createElement('style');
                    style.id = 'viro-edit-css';
                    style.textContent = [
                        /* Text elements */
                        '[data-viro-editable]:hover{outline:2px dashed rgba(59,130,246,.5);outline-offset:4px;cursor:text;position:relative}',
                        '[data-viro-editable].viro-editing{outline:2px solid rgba(59,130,246,.8);outline-offset:4px;background:rgba(59,130,246,.03)}',
                        /* Images */
                        'img:hover{outline:2px dashed rgba(34,197,94,.5);outline-offset:4px;cursor:pointer}',
                        /* Links/buttons */
                        'a.btn:hover,a[href]:not([data-viro-editable]):hover{outline:2px dashed rgba(245,158,11,.5);outline-offset:4px;cursor:pointer}',
                        /* Edit label that appears on hover */
                        '.viro-edit-label{position:absolute;top:-28px;left:0;background:#1e293b;color:#e2e8f0;font-size:10px;font-weight:600;padding:3px 8px;border-radius:4px;z-index:9999;pointer-events:none;font-family:-apple-system,BlinkMacSystemFont,Segoe UI,Roboto,Helvetica,Arial,sans-serif;white-space:nowrap;box-shadow:0 2px 8px rgba(0,0,0,.3)}',
                        '.viro-edit-label.text-label{background:#1e3a5f}',
                        '.viro-edit-label.img-label{background:#14532d}',
                        '.viro-edit-label.link-label{background:#78350f}',
                        /* Suppress nav links hover for editing context */
                        '*{cursor:default}',
                        'a,button,[data-viro-editable],img{cursor:pointer}',
                    ].join('\n');
                    doc.head.appendChild(style);

                    // Attach event listeners
                    doc.removeEventListener('click', handleIframeClick, true);
                    doc.addEventListener('click', handleIframeClick, true);
                    doc.removeEventListener('mouseover', handleIframeHover);
                    doc.addEventListener('mouseover', handleIframeHover);
                    doc.removeEventListener('mouseout', handleIframeOut);
                    doc.addEventListener('mouseout', handleIframeOut);
                }

                var hoverLabel = null;
                var hoverTarget = null; // the element the label currently belongs to

                function resolveHoverEl(target) {
                    var logo = target.closest('[data-viro-logo], a.logo, .logo');
                    if (logo) return { el: logo, kind: 'logo' };
                    var link = target.closest('a[href], a.btn, button:not([type="submit"]), [role="button"]');
                    if (link) return { el: link, kind: 'link' };
                    if (target.tagName === 'IMG') return { el: target, kind: 'img' };
                    var editable = target.closest('[data-viro-editable]');
                    if (editable) return { el: editable, kind: 'text' };
                    return null;
                }

                function handleIframeHover(e) {
                    if (editMode !== 'select') return;
                    var doc = iframe.contentDocument;
                    var resolved = resolveHoverEl(e.target);

                    // Same element as before → do nothing (prevents flicker from DOM churn)
                    if (resolved && resolved.el === hoverTarget) return;

                    // Moved to a different element (or none) → clear the old label first
                    if (hoverLabel) { hoverLabel.remove(); hoverLabel = null; }
                    hoverTarget = resolved ? resolved.el : null;
                    if (!resolved) return;

                    var labelEl = doc.createElement('span');
                    labelEl.className = 'viro-edit-label';
                    if (resolved.kind === 'logo') {
                        labelEl.classList.add('link-label');
                        labelEl.textContent = '✦ Click to change logo';
                        resolved.el.style.position = resolved.el.style.position || 'relative';
                        resolved.el.appendChild(labelEl);
                    } else if (resolved.kind === 'link') {
                        labelEl.classList.add('link-label');
                        labelEl.textContent = '🔗 Click to edit link';
                        resolved.el.style.position = resolved.el.style.position || 'relative';
                        resolved.el.appendChild(labelEl);
                    } else if (resolved.kind === 'img') {
                        var wrapper = resolved.el.parentElement || resolved.el;
                        labelEl.classList.add('img-label');
                        labelEl.textContent = '🖼️ Click to swap photo';
                        wrapper.style.position = wrapper.style.position || 'relative';
                        wrapper.appendChild(labelEl);
                    } else {
                        labelEl.classList.add('text-label');
                        labelEl.textContent = '✏️ Click to edit text';
                        resolved.el.style.position = resolved.el.style.position || 'relative';
                        resolved.el.appendChild(labelEl);
                    }
                    hoverLabel = labelEl;
                }

                function handleIframeOut(e) {
                    // Only clear when actually leaving the labeled element (not when moving
                    // onto a child of it). relatedTarget is where the cursor is going.
                    if (!hoverTarget) return;
                    var to = e.relatedTarget;
                    if (to && hoverTarget.contains && hoverTarget.contains(to)) return;
                    if (hoverLabel) { hoverLabel.remove(); hoverLabel = null; }
                    hoverTarget = null;
                }

                function handleIframeClick(e) {
                    if (editMode !== 'select') return;

                    var target = e.target;
                    // A link or button anywhere on the page (nav OR in-page CTAs).
                    // Checked FIRST: the link popover also edits the button text, so links
                    // marked as text-editable still get the full link editor.
                    var link = target.closest('a[href], a.btn, button:not([type="submit"]), [role="button"]');
                    var logo = target.closest('[data-viro-logo], a.logo, .logo');
                    var img = (!logo) ? (target.tagName === 'IMG' ? target : null) : null;
                    var editable = (!link && !img && !logo) ? target.closest('[data-viro-editable]') : null;

                    if (logo) {
                        e.preventDefault();
                        e.stopPropagation();
                        showLogoPopover(logo);
                    } else if (link) {
                        e.preventDefault();
                        e.stopPropagation();
                        showLinkPopover(link);
                    } else if (img) {
                        e.preventDefault();
                        e.stopPropagation();
                        selectImage(img);
                        showPexelsPopover(img);
                    } else if (editable) {
                        e.preventDefault();
                        e.stopPropagation();
                        startTextEdit(editable);
                    }
                }

                // ═══════════════════════════════════════════════
                // IMAGE SELECTION TRACKING
                // ═══════════════════════════════════════════════

                var selBar = document.getElementById('selection-bar');
                var selThumb = document.getElementById('sel-thumb');
                var selText = document.getElementById('sel-text');
                document.getElementById('sel-clear').addEventListener('click', clearSelection);

                function selectImage(imgEl) {
                    // Find which section this image is in
                    var section = imgEl.closest('[data-viro-section]');
                    var sectionName = section ? section.getAttribute('data-viro-section') : 'unknown';

                    // Find the image index within the page
                    var doc = iframe.contentDocument;
                    var allImages = doc.querySelectorAll('img');
                    var imgIndex = Array.prototype.indexOf.call(allImages, imgEl);

                    // Store selection info
                    selectedImageInfo = {
                        section: sectionName,
                        index: imgIndex,
                        alt: imgEl.getAttribute('alt') || '',
                        src: imgEl.getAttribute('src') || '',
                    };

                    // Highlight the selected image with a persistent outline
                    doc.querySelectorAll('.viro-img-selected').forEach(function(el) {
                        el.classList.remove('viro-img-selected');
                        el.style.outline = '';
                        el.style.outlineOffset = '';
                    });
                    imgEl.classList.add('viro-img-selected');
                    imgEl.style.outline = '3px solid #22d3ee';
                    imgEl.style.outlineOffset = '4px';

                    // Update selection bar
                    selThumb.src = imgEl.src;
                    var label = sectionName.replace(/[-_]/g, ' ');
                    label = label.charAt(0).toUpperCase() + label.slice(1);
                    selText.innerHTML = '<b>' + label + ' image selected</b> — chat edits will target this image';
                    selBar.classList.add('active');
                }

                function clearSelection() {
                    selectedImageInfo = null;
                    selBar.classList.remove('active');
                    try {
                        var doc = iframe.contentDocument;
                        doc.querySelectorAll('.viro-img-selected').forEach(function(el) {
                            el.classList.remove('viro-img-selected');
                            el.style.outline = '';
                            el.style.outlineOffset = '';
                        });
                    } catch(e) {}
                }

                // ═══════════════════════════════════════════════
                // INLINE TEXT EDITING WITH FORMATTING TOOLBAR
                // ═══════════════════════════════════════════════

                var editingElement = null;
                var textToolbar = null;

                function startTextEdit(el) {
                    if (editingElement) finishTextEdit(editingElement, false);
                    closePopovers();

                    editingElement = el;
                    el.setAttribute('contenteditable', 'true');
                    el.classList.add('viro-editing');
                    el.focus();

                    // Select all text
                    var doc = iframe.contentDocument;
                    var range = doc.createRange();
                    range.selectNodeContents(el);
                    var sel = doc.getSelection();
                    sel.removeAllRanges();
                    sel.addRange(range);

                    // Listen for finish
                    el.addEventListener('keydown', onTextKeydown);

                    // Show formatting toolbar
                    showTextToolbar(el);
                }

                function showTextToolbar(el) {
                    removeTextToolbar();

                    var rect = el.getBoundingClientRect();
                    var iframeRect = iframe.getBoundingClientRect();
                    var top = iframeRect.top + rect.top - 48;
                    var left = iframeRect.left + rect.left + (rect.width / 2);

                    // Get current styles
                    var doc = iframe.contentDocument;
                    var computed = doc.defaultView.getComputedStyle(el);
                    var currentColor = el.style.color || computed.color || '#000000';
                    var currentSize = parseInt(el.style.fontSize || computed.fontSize) || 16;
                    var currentFont = el.style.fontFamily || computed.fontFamily || '';
                    var currentWeight = parseInt(el.style.fontWeight || computed.fontWeight) || 400;
                    var currentItalic = (el.style.fontStyle || computed.fontStyle) === 'italic';
                    var currentTag = el.tagName.toLowerCase();

                    // Convert rgb to hex for color input
                    var hexColor = rgbToHex(currentColor);

                    var tb = document.createElement('div');
                    tb.className = 'text-toolbar';
                    tb.style.top = Math.max(4, top) + 'px';
                    tb.style.left = left + 'px';
                    tb.style.transform = 'translateX(-50%)';

                    tb.innerHTML =
                        // Color
                        '<div class="tt-color" style="background:' + hexColor + '" title="Text color">' +
                            '<input type="color" value="' + hexColor + '" data-tt="color">' +
                        '</div>' +
                        '<div class="tt-sep"></div>' +
                        // Font size
                        '<input type="number" class="tt-select tt-size" value="' + currentSize + '" min="10" max="120" step="1" data-tt="size" title="Font size (px)">' +
                        '<div class="tt-sep"></div>' +
                        // Font family
                        '<select class="tt-select" data-tt="font" title="Font family">' +
                            '<option value="">Current font</option>' +
                            '<option value="\'Space Grotesk\',sans-serif">Space Grotesk</option>' +
                            '<option value="\'DM Sans\',sans-serif">DM Sans</option>' +
                            '<option value="\'Inter\',sans-serif">Inter</option>' +
                            '<option value="\'Outfit\',sans-serif">Outfit</option>' +
                            '<option value="\'Fraunces\',serif">Fraunces</option>' +
                            '<option value="\'DM Serif Display\',serif">DM Serif Display</option>' +
                            '<option value="\'Playfair Display\',serif">Playfair Display</option>' +
                            '<option value="\'Sora\',sans-serif">Sora</option>' +
                            '<option value="\'Nunito\',sans-serif">Nunito</option>' +
                            '<option value="Georgia,serif">Georgia</option>' +
                            '<option value="system-ui,sans-serif">System</option>' +
                        '</select>' +
                        '<div class="tt-sep"></div>' +
                        // Bold
                        '<button class="tt-btn' + (currentWeight >= 600 ? ' active' : '') + '" data-tt="bold" title="Bold"><b>B</b></button>' +
                        // Italic
                        '<button class="tt-btn' + (currentItalic ? ' active' : '') + '" data-tt="italic" title="Italic"><i>I</i></button>' +
                        // Underline
                        '<button class="tt-btn" data-tt="underline" title="Underline"><u>U</u></button>' +
                        '<div class="tt-sep"></div>' +
                        // Text type
                        '<select class="tt-select" data-tt="tag" title="Text type">' +
                            '<option value="h1"' + (currentTag === 'h1' ? ' selected' : '') + '>H1</option>' +
                            '<option value="h2"' + (currentTag === 'h2' ? ' selected' : '') + '>H2</option>' +
                            '<option value="h3"' + (currentTag === 'h3' ? ' selected' : '') + '>H3</option>' +
                            '<option value="p"' + (currentTag === 'p' ? ' selected' : '') + '>P</option>' +
                            '<option value="span"' + (currentTag === 'span' ? ' selected' : '') + '>Span</option>' +
                        '</select>' +
                        '<div class="tt-sep"></div>' +
                        // Done
                        '<button class="tt-btn" data-tt="done" title="Done editing" style="color:#10b981">✓</button>';

                    document.body.appendChild(tb);
                    textToolbar = tb;

                    // Keep toolbar on screen
                    var tbRect = tb.getBoundingClientRect();
                    if (tbRect.left < 8) tb.style.left = (tbRect.width / 2 + 8) + 'px';
                    if (tbRect.right > window.innerWidth - 8) tb.style.left = (window.innerWidth - tbRect.width / 2 - 8) + 'px';
                    if (top < 4) { tb.style.top = (iframeRect.top + rect.bottom + 8) + 'px'; }

                    // Event handlers
                    tb.addEventListener('mousedown', function(e) { e.stopPropagation(); });
                    tb.addEventListener('click', function(e) { e.stopPropagation(); });

                    // Color
                    tb.querySelector('[data-tt="color"]').addEventListener('input', function(e) {
                        el.style.color = e.target.value;
                        e.target.parentElement.style.background = e.target.value;
                    });

                    // Size
                    tb.querySelector('[data-tt="size"]').addEventListener('input', function(e) {
                        el.style.fontSize = e.target.value + 'px';
                    });

                    // Font
                    tb.querySelector('[data-tt="font"]').addEventListener('change', function(e) {
                        if (e.target.value) el.style.fontFamily = e.target.value;
                    });

                    // Bold
                    tb.querySelector('[data-tt="bold"]').addEventListener('click', function(e) {
                        var btn = e.currentTarget;
                        var isBold = btn.classList.toggle('active');
                        el.style.fontWeight = isBold ? '700' : '400';
                    });

                    // Italic
                    tb.querySelector('[data-tt="italic"]').addEventListener('click', function(e) {
                        var btn = e.currentTarget;
                        var isItalic = btn.classList.toggle('active');
                        el.style.fontStyle = isItalic ? 'italic' : 'normal';
                    });

                    // Underline
                    tb.querySelector('[data-tt="underline"]').addEventListener('click', function(e) {
                        var btn = e.currentTarget;
                        var isUnderline = btn.classList.toggle('active');
                        el.style.textDecoration = isUnderline ? 'underline' : 'none';
                    });

                    // Tag change (H1/H2/H3/P)
                    tb.querySelector('[data-tt="tag"]').addEventListener('change', function(e) {
                        var newTag = e.target.value;
                        if (newTag === currentTag) return;
                        var doc = iframe.contentDocument;
                        var newEl = doc.createElement(newTag);
                        // Copy attributes
                        Array.from(el.attributes).forEach(function(a) {
                            newEl.setAttribute(a.name, a.value);
                        });
                        // Copy inline styles
                        newEl.style.cssText = el.style.cssText;
                        // Copy content
                        newEl.innerHTML = el.innerHTML;
                        el.parentNode.replaceChild(newEl, el);
                        editingElement = newEl;
                        el = newEl;
                        el.setAttribute('contenteditable', 'true');
                        el.classList.add('viro-editing');
                        el.focus();
                    });

                    // Done
                    tb.querySelector('[data-tt="done"]').addEventListener('click', function() {
                        finishTextEdit(el, true);
                    });
                }

                function removeTextToolbar() {
                    if (textToolbar) { textToolbar.remove(); textToolbar = null; }
                }

                function rgbToHex(color) {
                    if (color.startsWith('#')) return color.length === 4 ?
                        '#' + color[1]+color[1]+color[2]+color[2]+color[3]+color[3] : color;
                    var match = color.match(/rgba?\((\d+),\s*(\d+),\s*(\d+)/);
                    if (!match) return '#000000';
                    return '#' + [match[1],match[2],match[3]].map(function(x) {
                        return parseInt(x).toString(16).padStart(2,'0');
                    }).join('');
                }

                function onTextKeydown(e) {
                    if (e.key === 'Escape') {
                        finishTextEdit(e.target, true);
                    }
                    // Allow Enter for line breaks in paragraphs, but finish for headings
                    if (e.key === 'Enter' && !e.shiftKey) {
                        var tag = e.target.tagName.toLowerCase();
                        if (tag === 'h1' || tag === 'h2' || tag === 'h3') {
                            e.preventDefault();
                            finishTextEdit(e.target, true);
                        }
                    }
                }

                function finishTextEdit(el, save) {
                    el.removeAttribute('contenteditable');
                    el.classList.remove('viro-editing');
                    el.removeEventListener('keydown', onTextKeydown);
                    editingElement = null;
                    removeTextToolbar();

                    if (save !== false) {
                        var newHtml = serializeIframe();
                        if (newHtml !== currentHtml) {
                            pushState(newHtml);
                            addMessage('system', '✓ Text updated');
                            renderPage(currentHtml);
                        }
                    }
                }

                // Close text editor when clicking outside in the iframe
                iframe.addEventListener('load', function() {
                    try {
                        iframe.contentDocument.addEventListener('click', function(e) {
                            if (editingElement && !e.target.closest('[contenteditable]')) {
                                finishTextEdit(editingElement, true);
                            }
                        });
                    } catch(err) {}
                });

                // ═══════════════════════════════════════════════
                // PEXELS IMAGE SWAP POPOVER
                // ═══════════════════════════════════════════════

                function showPexelsPopover(imgEl) {
                    closePopovers();

                    var rect = imgEl.getBoundingClientRect();
                    var iframeRect = iframe.getBoundingClientRect();
                    var top = iframeRect.top + rect.bottom + 8;
                    var left = iframeRect.left + rect.left;
                    // Keep on screen
                    if (left + 360 > window.innerWidth) left = window.innerWidth - 380;
                    if (top + 420 > window.innerHeight) top = iframeRect.top + rect.top - 430;

                    var pop = document.createElement('div');
                    pop.className = 'pexels-popover';
                    pop.style.top = top + 'px';
                    pop.style.left = left + 'px';

                    pop.innerHTML =
                        '<div class="pp-header"><span>Swap Photo</span><button class="pp-close">&times;</button></div>' +
                        '<div class="pp-search"><input type="text" placeholder="Search free photos…"><button>Search</button></div>' +
                        '<div class="pp-grid"></div>' +
                        '<div class="pp-status">Search for a new photo or upload your own</div>' +
                        '<div class="pp-upload"><button>↑ Upload from computer</button></div>';

                    document.body.appendChild(pop);
                    activePopover = pop;

                    var searchInput = pop.querySelector('.pp-search input');
                    var searchBtn = pop.querySelector('.pp-search button');
                    var grid = pop.querySelector('.pp-grid');
                    var status = pop.querySelector('.pp-status');

                    // Pre-fill search from alt text
                    var alt = imgEl.getAttribute('alt') || '';
                    if (alt && alt.length > 5) {
                        searchInput.value = alt.split(' ').slice(0, 4).join(' ');
                    }

                    pop.querySelector('.pp-close').addEventListener('click', closePopovers);

                    async function doSearch() {
                        var q = searchInput.value.trim();
                        if (!q) return;
                        status.textContent = 'Searching…';
                        grid.innerHTML = '';
                        try {
                            var fd = new FormData();
                            fd.append('action', 'virobuilder_pexels_search');
                            fd.append('_ajax_nonce', NONCE);
                            fd.append('query', q);
                            fd.append('orientation', 'landscape');
                            fd.append('count', '12');
                            var res = await fetch(AJAX, {method:'POST', body:fd});
                            var data = await res.json();
                            if (data.success && data.data.photos && data.data.photos.length) {
                                status.textContent = data.data.photos.length + ' photos from Pexels';
                                data.data.photos.forEach(function(photo) {
                                    var img = document.createElement('img');
                                    img.src = photo.thumbnail;
                                    img.alt = photo.alt || q;
                                    img.title = photo.photographer ? 'Photo by ' + photo.photographer : '';
                                    img.addEventListener('click', function() {
                                        swapImage(imgEl, photo.url, photo.alt || q);
                                    });
                                    grid.appendChild(img);
                                });
                            } else {
                                status.textContent = 'No photos found. Try different words.';
                            }
                        } catch(err) { status.textContent = 'Search failed.'; }
                    }

                    searchBtn.addEventListener('click', doSearch);
                    searchInput.addEventListener('keydown', function(e) {
                        if (e.key === 'Enter') doSearch();
                    });
                    searchInput.focus();

                    // Upload button
                    pop.querySelector('.pp-upload button').addEventListener('click', function() {
                        if (!window.wp || !window.wp.media) {
                            alert('WordPress media library not available.');
                            return;
                        }
                        var frame = wp.media({title:'Choose a photo', multiple:false, library:{type:'image'}});
                        frame.on('select', function() {
                            var att = frame.state().get('selection').first().toJSON();
                            var url = (att.sizes && att.sizes.large && att.sizes.large.url) || att.url;
                            swapImage(imgEl, url, att.alt || att.title || '');
                        });
                        frame.open();
                        closePopovers();
                    });
                }

                function swapImage(imgEl, newUrl, newAlt) {
                    closePopovers();
                    try {
                        imgEl.src = newUrl;
                        if (newAlt) imgEl.alt = newAlt;
                        var newHtml = serializeIframe();
                        pushState(newHtml);
                        addMessage('system', '✓ Image swapped');
                        renderPage(currentHtml);
                    } catch(e) {}
                }

                // ═══════════════════════════════════════════════
                // LINK EDIT POPOVER
                // ═══════════════════════════════════════════════

                // Classify a link destination into a human-readable type + label
                function classifyLink(href, doc) {
                    href = (href || '').trim();
                    if (!href || href === '#') {
                        return { type:'none', icon:'⚠️', label:'No destination set', detail:'This link goes nowhere yet.' };
                    }
                    if (href.charAt(0) === '#') {
                        var id = href.slice(1);
                        var exists = id && doc.getElementById(id);
                        return {
                            type:'scroll', icon:'📍',
                            label: exists ? 'Scrolls to a section on this page' : 'Scrolls to section (not found)',
                            detail: exists ? 'Section: #' + id : 'No section with id "' + id + '" exists on this page.',
                            ok: !!exists
                        };
                    }
                    if (/^mailto:/i.test(href)) {
                        return { type:'email', icon:'✉️', label:'Opens an email', detail:href.replace(/^mailto:/i,''), ok:true };
                    }
                    if (/^tel:/i.test(href)) {
                        return { type:'phone', icon:'📞', label:'Starts a phone call', detail:href.replace(/^tel:/i,''), ok:true };
                    }
                    if (/^https?:\/\//i.test(href)) {
                        var host = '';
                        try { host = new URL(href).hostname.replace(/^www\./,''); } catch(e) {}
                        return { type:'external', icon:'🔗', label:'Goes to an external website', detail:host || href, ok:true };
                    }
                    if (href.charAt(0) === '/' || !/^[a-z]+:/i.test(href)) {
                        return { type:'internal', icon:'📄', label:'Goes to another page on your site', detail:href, ok:true };
                    }
                    return { type:'other', icon:'🔗', label:'Custom link', detail:href, ok:true };
                }

                function showLinkPopover(linkEl) {
                    closePopovers();

                    var doc = iframe.contentDocument;
                    var rect = linkEl.getBoundingClientRect();
                    var iframeRect = iframe.getBoundingClientRect();
                    var top = iframeRect.top + rect.bottom + 8;
                    var left = iframeRect.left + rect.left;
                    if (left + 320 > window.innerWidth) left = window.innerWidth - 340;
                    if (top < 4) top = iframeRect.top + rect.bottom + 8;

                    var pop = document.createElement('div');
                    pop.className = 'link-popover';
                    pop.style.top = top + 'px';
                    pop.style.left = left + 'px';

                    var currentText = linkEl.textContent.trim();
                    var currentHref = linkEl.getAttribute('href') || '#';
                    var info = classifyLink(currentHref, doc);

                    // Gather section anchors on the page for the "scroll to" dropdown
                    var sectionOpts = '';
                    var sections = doc.querySelectorAll('[id]');
                    sections.forEach(function(s) {
                        if (s.id && (s.tagName === 'SECTION' || s.tagName === 'DIV' || s.tagName === 'HEADER' || s.tagName === 'FOOTER')) {
                            sectionOpts += '<option value="#' + s.id + '"' + (currentHref === '#'+s.id ? ' selected' : '') + '>#' + s.id + '</option>';
                        }
                    });

                    pop.innerHTML =
                        '<div class="lp-dest lp-dest-' + info.type + '">' +
                            '<span class="lp-dest-icon">' + info.icon + '</span>' +
                            '<div><div class="lp-dest-label">' + info.label + '</div>' +
                            '<div class="lp-dest-detail">' + info.detail.replace(/</g,'&lt;') + '</div></div>' +
                        '</div>' +
                        '<label>Button / link text</label>' +
                        '<input type="text" class="lp-text" value="' + currentText.replace(/"/g,'&quot;') + '">' +
                        '<label>Where it goes</label>' +
                        '<div class="lp-type-row">' +
                            '<select class="lp-type">' +
                                '<option value="external"' + (info.type==='external'||info.type==='other' ? ' selected' : '') + '>External website</option>' +
                                '<option value="scroll"' + (info.type==='scroll' ? ' selected' : '') + '>Scroll to section</option>' +
                                '<option value="internal"' + (info.type==='internal' ? ' selected' : '') + '>Page on this site</option>' +
                                '<option value="email"' + (info.type==='email' ? ' selected' : '') + '>Email address</option>' +
                                '<option value="phone"' + (info.type==='phone' ? ' selected' : '') + '>Phone number</option>' +
                            '</select>' +
                        '</div>' +
                        '<input type="text" class="lp-url lp-url-external" placeholder="https://example.com" value="' + (info.type==='external'||info.type==='internal'||info.type==='other' ? currentHref.replace(/"/g,'&quot;') : '') + '">' +
                        '<select class="lp-url-scroll" style="display:none">' + (sectionOpts || '<option value="">(no sections found)</option>') + '</select>' +
                        '<input type="text" class="lp-url-email" style="display:none" placeholder="you@business.com" value="' + (info.type==='email' ? currentHref.replace(/^mailto:/i,'').replace(/"/g,'&quot;') : '') + '">' +
                        '<input type="text" class="lp-url-phone" style="display:none" placeholder="(555) 123-4567" value="' + (info.type==='phone' ? currentHref.replace(/^tel:/i,'').replace(/"/g,'&quot;') : '') + '">' +
                        '<div class="lp-actions">' +
                            '<button class="lp-cancel">Cancel</button>' +
                            '<button class="lp-apply">Apply</button>' +
                        '</div>';

                    document.body.appendChild(pop);
                    activePopover = pop;

                    var typeSel = pop.querySelector('.lp-type');
                    function syncTypeFields() {
                        var t = typeSel.value;
                        pop.querySelector('.lp-url-external').style.display = (t==='external'||t==='internal') ? 'block' : 'none';
                        pop.querySelector('.lp-url-scroll').style.display = (t==='scroll') ? 'block' : 'none';
                        pop.querySelector('.lp-url-email').style.display = (t==='email') ? 'block' : 'none';
                        pop.querySelector('.lp-url-phone').style.display = (t==='phone') ? 'block' : 'none';
                        var extInput = pop.querySelector('.lp-url-external');
                        extInput.placeholder = (t==='internal') ? '/about  or  /contact' : 'https://example.com';
                    }
                    typeSel.addEventListener('change', syncTypeFields);
                    syncTypeFields();

                    pop.querySelector('.lp-cancel').addEventListener('click', closePopovers);
                    pop.querySelector('.lp-apply').addEventListener('click', function() {
                        var newText = pop.querySelector('.lp-text').value.trim();
                        var t = typeSel.value;
                        var newUrl = '#';
                        if (t==='external' || t==='internal') newUrl = pop.querySelector('.lp-url-external').value.trim() || '#';
                        else if (t==='scroll') newUrl = pop.querySelector('.lp-url-scroll').value || '#';
                        else if (t==='email') { var em = pop.querySelector('.lp-url-email').value.trim(); newUrl = em ? 'mailto:'+em : '#'; }
                        else if (t==='phone') { var ph = pop.querySelector('.lp-url-phone').value.trim(); newUrl = ph ? 'tel:'+ph.replace(/[^0-9+]/g,'') : '#'; }

                        if (newText) {
                            var arrow = linkEl.querySelector('.arrow');
                            linkEl.textContent = newText + ' ';
                            if (arrow) linkEl.appendChild(arrow);
                        }
                        linkEl.setAttribute('href', newUrl);
                        closePopovers();
                        var newHtmlStr = serializeIframe();
                        pushState(newHtmlStr);
                        addMessage('system', '✓ Link updated');
                        renderPage(currentHtml);
                    });

                    pop.querySelector('.lp-text').focus();
                    pop.querySelector('.lp-text').select();
                }

                function showLogoPopover(logoEl) {
                    closePopovers();
                    var doc = iframe.contentDocument;
                    var rect = logoEl.getBoundingClientRect();
                    var iframeRect = iframe.getBoundingClientRect();
                    var top = iframeRect.top + rect.bottom + 8;
                    var left = iframeRect.left + rect.left;
                    if (left + 320 > window.innerWidth) left = window.innerWidth - 340;

                    var hasImg = !!logoEl.querySelector('img');
                    var currentText = logoEl.textContent.trim();

                    var pop = document.createElement('div');
                    pop.className = 'link-popover';
                    pop.style.top = top + 'px';
                    pop.style.left = left + 'px';
                    pop.innerHTML =
                        '<div class="lp-dest lp-dest-scroll">' +
                            '<span class="lp-dest-icon">✦</span>' +
                            '<div><div class="lp-dest-label">Your logo</div>' +
                            '<div class="lp-dest-detail">Upload an image, or use a text wordmark. Applies to header & footer.</div></div>' +
                        '</div>' +
                        '<button class="lp-apply" id="logo-upload" style="width:100%;margin-bottom:10px">⬆ Upload / choose logo image</button>' +
                        '<label>Or use text</label>' +
                        '<input type="text" class="logo-text" value="' + currentText.replace(/"/g,'&quot;') + '" placeholder="Business name">' +
                        '<div class="lp-actions">' +
                            '<button class="lp-cancel">Cancel</button>' +
                            '<button class="lp-apply" id="logo-apply-text">Use text</button>' +
                        '</div>';
                    document.body.appendChild(pop);
                    activePopover = pop;

                    // Apply an image logo to ALL logo elements (header + footer)
                    function applyImage(url) {
                        var logos = doc.querySelectorAll('[data-viro-logo], a.logo, .logo');
                        logos.forEach(function(l) {
                            l.innerHTML = '<img src="' + url + '" alt="Logo" style="height:40px;width:auto;display:block;object-fit:contain">';
                        });
                        closePopovers();
                        var s = serializeIframe(); pushState(s);
                        addMessage('system', '✓ Logo updated (header & footer)');
                        renderPage(currentHtml);
                    }

                    pop.querySelector('#logo-upload').addEventListener('click', function() {
                        if (!window.wp || !window.wp.media) {
                            alert('The media library is unavailable. Try the text option, or reload the editor.');
                            return;
                        }
                        var frame = wp.media({ title: 'Choose your logo', multiple: false, library: { type: 'image' } });
                        frame.on('select', function() {
                            var att = frame.state().get('selection').first().toJSON();
                            var url = att.sizes && att.sizes.medium ? att.sizes.medium.url : att.url;
                            applyImage(url);
                        });
                        frame.open();
                    });

                    pop.querySelector('#logo-apply-text').addEventListener('click', function() {
                        var txt = pop.querySelector('.logo-text').value.trim();
                        if (!txt) { closePopovers(); return; }
                        var logos = doc.querySelectorAll('[data-viro-logo], a.logo, .logo');
                        logos.forEach(function(l) { l.textContent = txt; });
                        closePopovers();
                        var s = serializeIframe(); pushState(s);
                        addMessage('system', '✓ Logo text updated (header & footer)');
                        renderPage(currentHtml);
                    });

                    pop.querySelector('.lp-cancel').addEventListener('click', closePopovers);
                }

                function closePopovers() {
                    if (activePopover) { activePopover.remove(); activePopover = null; }
                }

                // Close popovers on click outside
                document.addEventListener('click', function(e) {
                    if (activePopover && !activePopover.contains(e.target)) closePopovers();
                });

                // ═══════════════════════════════════════════════
                // CHAT: Quick actions, messages, send
                // ═══════════════════════════════════════════════

                document.querySelectorAll('.qa-btn').forEach(function(btn) {
                    btn.addEventListener('click', function() {
                        input.value = btn.dataset.prompt;
                        input.focus();
                        input.setSelectionRange(input.value.length, input.value.length);
                    });
                });

                input.addEventListener('input', function() {
                    this.style.height = 'auto';
                    this.style.height = Math.min(this.scrollHeight, 120) + 'px';
                });

                function addMessage(role, text) {
                    var div = document.createElement('div');
                    div.className = 'msg msg-' + role;
                    if (role === 'ai') {
                        div.innerHTML = '<span class="change-summary">' + text.replace(/</g,'&lt;') + '</span>';
                    } else {
                        div.textContent = text;
                    }
                    messagesDiv.appendChild(div);
                    messagesDiv.scrollTop = messagesDiv.scrollHeight;
                    return div;
                }

                // ── Rich progress indicator ──────────────────
                var progressTimer = null;
                var progressElapsed = null;

                function startProgress(instruction) {
                    // Choose contextual messages based on what the user asked
                    var lower = (instruction || '').toLowerCase();
                    var steps;

                    if (lower.includes('color') || lower.includes('brand') || lower.includes('palette')) {
                        steps = [
                            ['🎨','Analyzing your color choice…'],
                            ['🔧','Updating CSS variables…'],
                            ['✨','Adjusting contrast and accents…'],
                            ['📱','Testing readability on all devices…'],
                            ['🎯','Fine-tuning hover states…'],
                            ['✅','Wrapping up…']
                        ];
                    } else if (lower.includes('image') || lower.includes('photo') || lower.includes('picture')) {
                        steps = [
                            ['🔍','Finding the right photo…'],
                            ['📷','Matching your page style…'],
                            ['✂️','Adjusting the layout…'],
                            ['🖼️','Optimizing the composition…'],
                            ['✅','Almost there…']
                        ];
                    } else if (lower.includes('add') || lower.includes('section') || lower.includes('new')) {
                        steps = [
                            ['📐','Designing the new section…'],
                            ['🎨','Matching your existing design system…'],
                            ['📝','Writing the content…'],
                            ['📱','Adding responsive rules…'],
                            ['✨','Animating the entrance…'],
                            ['✅','Finalizing…']
                        ];
                    } else if (lower.includes('headline') || lower.includes('text') || lower.includes('copy') || lower.includes('say')) {
                        steps = [
                            ['✏️','Crafting the new copy…'],
                            ['📖','Checking tone and flow…'],
                            ['✅','Updating the page…']
                        ];
                    } else {
                        steps = [
                            ['🧠','Understanding your request…'],
                            ['🎨','Applying the design changes…'],
                            ['📐','Adjusting layout and spacing…'],
                            ['📱','Verifying responsive behavior…'],
                            ['✨','Polishing the details…'],
                            ['✅','Wrapping up…']
                        ];
                    }

                    // Create the progress widget
                    var widget = document.createElement('div');
                    widget.id = 'progress-widget';
                    widget.className = 'progress-widget';

                    // Progress bar
                    var barTrack = document.createElement('div');
                    barTrack.className = 'pw-bar-track';
                    var barFill = document.createElement('div');
                    barFill.className = 'pw-bar-fill';
                    barTrack.appendChild(barFill);
                    widget.appendChild(barTrack);

                    // Step text
                    var stepText = document.createElement('div');
                    stepText.className = 'pw-step';
                    stepText.innerHTML = '<span class="pw-icon">' + steps[0][0] + '</span><span class="pw-text">' + steps[0][1] + '</span>';
                    widget.appendChild(stepText);

                    // Timer
                    var timerEl = document.createElement('div');
                    timerEl.className = 'pw-timer';
                    timerEl.textContent = '0s';
                    widget.appendChild(timerEl);

                    messagesDiv.appendChild(widget);
                    messagesDiv.scrollTop = messagesDiv.scrollHeight;

                    // Animate through steps
                    var currentStep = 0;
                    var startTime = Date.now();
                    var stepDuration = Math.max(4000, (120000 / steps.length)); // Spread over ~2 min

                    progressTimer = setInterval(function() {
                        // Update elapsed time
                        var elapsed = Math.floor((Date.now() - startTime) / 1000);
                        timerEl.textContent = elapsed + 's';

                        // Update progress bar (fill over ~2 minutes)
                        var pct = Math.min(95, (elapsed / 120) * 100);
                        barFill.style.width = pct + '%';

                        // Advance step
                        var expectedStep = Math.min(steps.length - 1, Math.floor(elapsed / (stepDuration / 1000)));
                        if (expectedStep > currentStep) {
                            currentStep = expectedStep;
                            stepText.style.opacity = '0';
                            stepText.style.transform = 'translateY(6px)';
                            setTimeout(function() {
                                stepText.innerHTML = '<span class="pw-icon">' + steps[currentStep][0] + '</span><span class="pw-text">' + steps[currentStep][1] + '</span>';
                                stepText.style.opacity = '1';
                                stepText.style.transform = 'translateY(0)';
                            }, 200);
                        }

                        messagesDiv.scrollTop = messagesDiv.scrollHeight;
                    }, 1000);
                }

                function stopProgress() {
                    if (progressTimer) { clearInterval(progressTimer); progressTimer = null; }
                    var w = document.getElementById('progress-widget');
                    if (w) {
                        // Fill bar to 100% briefly then remove
                        var fill = w.querySelector('.pw-bar-fill');
                        if (fill) fill.style.width = '100%';
                        setTimeout(function() { w.remove(); }, 400);
                    }
                }

                function ordinalSuffix(n) {
                    var s = ['th','st','nd','rd'];
                    var v = n % 100;
                    return (s[(v-20)%10]||s[v]||s[0]);
                }

                // Detect simple visual edits and nudge toward instant click-editing.
                var clickHintShown = {}; // track which hint types we've shown this session
                var pendingHintInstruction = null;

                function maybeShowClickHint(instruction) {
                    var lower = instruction.toLowerCase();
                    var type = null;
                    if (/\b(colou?r|background|bg)\b/.test(lower) && !/\b(section|layout|scheme|palette|whole|entire|all)\b/.test(lower)) {
                        type = 'color';
                    } else if (/\b(font|typeface|bigger|smaller|font size|bold|italic|underline)\b/.test(lower) && !/\b(everything|all|whole|entire)\b/.test(lower)) {
                        type = 'font';
                    } else if (/\b(photo|image|picture)\b/.test(lower) && /\b(swap|change|replace|different|new)\b/.test(lower)) {
                        type = 'image';
                    }
                    if (!type || clickHintShown[type]) return false;

                    clickHintShown[type] = true;
                    pendingHintInstruction = instruction;

                    var tips = {
                        color: 'Tip: you can change colors instantly — just <b>click the element</b> in the preview and pick a color. No waiting.',
                        font:  'Tip: click any text in the preview to change its <b>font, size, or style</b> instantly — no waiting.',
                        image: 'Tip: click any image in the preview to <b>swap it from Pexels</b> instantly — no waiting.'
                    };
                    addHintMessage(tips[type]);
                    return true;
                }

                function addHintMessage(html) {
                    var wrap = document.createElement('div');
                    wrap.className = 'chat-msg chat-msg-hint';
                    wrap.innerHTML = '<div class="hint-body">💡 ' + html +
                        '</div><div class="hint-actions">' +
                        '<button class="hint-send">Edit with AI anyway</button></div>';
                    messagesDiv.appendChild(wrap);
                    messagesDiv.scrollTop = messagesDiv.scrollHeight;
                    wrap.querySelector('.hint-send').addEventListener('click', function() {
                        wrap.querySelector('.hint-actions').innerHTML = '';
                        var instr = pendingHintInstruction;
                        pendingHintInstruction = null;
                        // Bypass the hint on this explicit re-send
                        sending = false;
                        forceSendEdit(instr);
                    });
                }

                // Send bypassing the hint (used by "Edit with AI anyway")
                async function forceSendEdit(instruction) {
                    if (sending || !instruction.trim()) return;
                    sending = true; sendBtn.disabled = true;
                    addMessage('user', instruction);
                    startProgress(instruction);
                    try {
                        var fd = new FormData();
                        fd.append('action', 'virobuilder_chat_edit');
                        fd.append('_ajax_nonce', NONCE);
                        fd.append('post_id', POST_ID);
                        fd.append('instruction', instruction);
                        fd.append('current_html', currentHtml);
                        var res = await fetch(AJAX, {method:'POST', body:fd});
                        var data = await res.json();
                        stopProgress();
                        if (data.success && data.data && data.data.html) {
                            pushState(data.data.html);
                            currentHtml = data.data.html;
                            renderPage(currentHtml);
                            addMessage('assistant', data.data.summary || '✓ Done');
                        } else {
                            addMessage('assistant', (data.data && data.data.message) ? data.data.message : 'That edit didn\'t work — try rephrasing.');
                        }
                    } catch(e) {
                        stopProgress();
                        addMessage('assistant', 'Something went wrong. Please try again.');
                    }
                    sending = false; sendBtn.disabled = false;
                }

                async function sendEdit(instruction) {
                    if (sending || !instruction.trim()) return;

                    // Nudge: if this looks like a simple color/text/font edit and nothing is
                    // selected, suggest the instant click-to-edit path (no AI call, no wait).
                    // Shown once per session; the user can still send the chat edit.
                    if (!selectedImageInfo && maybeShowClickHint(instruction)) {
                        return; // wait for the user to either click the element or re-send
                    }

                    sending = true; sendBtn.disabled = true;

                    // If an image is selected and the instruction seems image-related,
                    // prepend specific context so the AI targets the right image
                    var actualInstruction = instruction;
                    if (selectedImageInfo) {
                        var lower = instruction.toLowerCase();
                        var imageRelated = lower.includes('image') || lower.includes('photo') ||
                            lower.includes('picture') || lower.includes('swap') ||
                            lower.includes('replace') || lower.includes('change') ||
                            lower.includes('selected') || lower.includes('this');

                        if (imageRelated) {
                            actualInstruction = 'TARGET: The image in the "' + selectedImageInfo.section +
                                '" section (the ' + (selectedImageInfo.index + 1) +
                                ordinalSuffix(selectedImageInfo.index + 1) + ' <img> tag on the page' +
                                (selectedImageInfo.alt ? ', alt="' + selectedImageInfo.alt + '"' : '') +
                                '). INSTRUCTION: ' + instruction;
                        }
                        // Clear selection after use
                        clearSelection();
                    }

                    addMessage('user', instruction);
                    input.value = ''; input.style.height = 'auto';
                    startProgress(instruction);

                    try {
                        var fd = new FormData();
                        fd.append('action', 'virobuilder_chat_edit');
                        fd.append('_ajax_nonce', NONCE);
                        fd.append('post_id', POST_ID);
                        fd.append('instruction', actualInstruction);
                        fd.append('current_html', currentHtml);

                        var res = await fetch(AJAX, {method:'POST', body:fd});
                        var data = await res.json();
                        stopProgress();

                        if (data.success && data.data && data.data.html) {
                            pushState(data.data.html);
                            currentHtml = data.data.html; // pushState already set this but let's be explicit
                            renderPage(currentHtml);
                            addMessage('ai', data.data.summary || '✓ Done');
                            if (data.data.cost) {
                            }
                        } else {
                            addMessage('ai', '⚠ ' + ((data.data && data.data.message) || 'Edit failed.'));
                        }
                    } catch(err) {
                        stopProgress();
                        addMessage('ai', '⚠ Network error: ' + err.message);
                    }
                    sending = false; sendBtn.disabled = false; input.focus();
                }

                sendBtn.addEventListener('click', function() { sendEdit(input.value); });
                input.addEventListener('keydown', function(e) {
                    if (e.key === 'Enter' && !e.shiftKey) { e.preventDefault(); sendEdit(input.value); }
                });

                // ═══════════════════════════════════════════════
                // UNDO / SAVE
                // ═══════════════════════════════════════════════

                undoBtn.addEventListener('click', function() {
                    if (htmlHistory.length <= 1) return;
                    currentHtml = htmlHistory.pop();
                    renderPage(currentHtml);
                    addMessage('system', '↩ Reverted');
                    if (htmlHistory.length <= 1) undoBtn.disabled = true;
                    autoSave();
                });

                saveBtn.addEventListener('click', async function() {
                    saveBtn.textContent = 'Saving…'; saveBtn.disabled = true;
                    try {
                        var fd = new FormData();
                        fd.append('action', 'virobuilder_chat_edit');
                        fd.append('_ajax_nonce', NONCE);
                        fd.append('post_id', POST_ID);
                        fd.append('instruction', '__save__');
                        fd.append('current_html', currentHtml);
                        var res = await fetch(AJAX, {method:'POST', body:fd});
                        var data = await res.json();
                        if (data.success) {
                            saveBtn.textContent = '✓ Saved';
                            addMessage('system', '💾 Page saved');
                        } else {
                            saveBtn.textContent = 'Save failed';
                        }
                    } catch(e) { saveBtn.textContent = 'Error'; }
                    setTimeout(function(){ saveBtn.textContent = 'Save draft'; saveBtn.disabled = false; }, 1500);
                });

                // ═══════════════════════════════════════════════
                // PUBLISH
                // ═══════════════════════════════════════════════
                var publishBtn = document.getElementById('btn-publish');
                var VIEW_URL = <?php echo wp_json_encode( $view_url ); ?>;
                publishBtn.addEventListener('click', async function() {
                    var wasPublished = publishBtn.dataset.published === '1';
                    publishBtn.textContent = wasPublished ? 'Updating…' : 'Publishing…';
                    publishBtn.disabled = true;
                    try {
                        var fd = new FormData();
                        fd.append('action', 'virobuilder_chat_publish');
                        fd.append('_ajax_nonce', NONCE);
                        fd.append('post_id', POST_ID);
                        fd.append('current_html', currentHtml);
                        var res = await fetch(AJAX, {method:'POST', body:fd});
                        var data = await res.json();
                        if (data.success) {
                            publishBtn.dataset.published = '1';
                            publishBtn.textContent = wasPublished ? '✓ Updated' : '✓ Published';
                            if (data.data && data.data.view_url) VIEW_URL = data.data.view_url;
                            addPublishMessage(VIEW_URL, wasPublished);
                        } else {
                            publishBtn.textContent = 'Failed';
                        }
                    } catch(e) { publishBtn.textContent = 'Error'; }
                    setTimeout(function(){
                        publishBtn.textContent = (publishBtn.dataset.published === '1') ? 'Update' : 'Publish';
                        publishBtn.disabled = false;
                    }, 2000);
                });

                function addPublishMessage(url, wasUpdate) {
                    var wrap = document.createElement('div');
                    wrap.className = 'chat-msg chat-msg-hint';
                    wrap.innerHTML = '<div class="hint-body">🎉 Your page is ' + (wasUpdate ? 'updated and ' : '') + '<b>live</b>!</div>' +
                        '<div class="hint-actions"><a class="hint-send" href="' + url + '" target="_blank" style="text-decoration:none;display:inline-block">View live page ↗</a></div>';
                    messagesDiv.appendChild(wrap);
                    messagesDiv.scrollTop = messagesDiv.scrollHeight;
                }

                // ═══════════════════════════════════════════════
                // EXPORT / IMPORT
                // ═══════════════════════════════════════════════

                document.getElementById('btn-export').addEventListener('click', function() {
                    var blob = new Blob([currentHtml], {type:'text/html;charset=utf-8'});
                    var url = URL.createObjectURL(blob);
                    var a = document.createElement('a');
                    a.href = url;
                    a.download = '<?php echo esc_js( sanitize_file_name( $title ) ); ?>.html';
                    document.body.appendChild(a);
                    a.click();
                    document.body.removeChild(a);
                    URL.revokeObjectURL(url);
                    addMessage('system', '📦 Page exported as HTML');
                });

                var importInput = document.getElementById('import-file');
                document.getElementById('btn-import').addEventListener('click', function() {
                    importInput.click();
                });
                importInput.addEventListener('change', function(e) {
                    var file = e.target.files[0];
                    if (!file) return;
                    if (!file.name.match(/\.html?$/i)) {
                        alert('Please select an HTML file.');
                        return;
                    }
                    var reader = new FileReader();
                    reader.onload = function(ev) {
                        var html = ev.target.result;
                        if (html.indexOf('<html') === -1 && html.indexOf('<!DOCTYPE') === -1) {
                            alert('This file does not appear to be a complete HTML page.');
                            return;
                        }
                        if (confirm('Import this page? Your current page will be replaced. You can undo this.')) {
                            pushState(html);
                            currentHtml = html;
                            renderPage(currentHtml);
                            addMessage('system', '📥 Page imported from ' + file.name);
                        }
                    };
                    reader.readAsText(file);
                    importInput.value = ''; // Reset so same file can be re-imported
                });

                // ═══════════════════════════════════════════════
                // MORE MENU
                // ═══════════════════════════════════════════════

                var moreMenu = document.getElementById('more-menu');

                document.getElementById('btn-more').addEventListener('click', function(e) {
                    e.stopPropagation();
                    moreMenu.classList.toggle('open');
                });

                // Close menu on outside click
                document.addEventListener('click', function(e) {
                    if (!e.target.closest('.more-wrap')) moreMenu.classList.remove('open');
                });

            })();
            </script>
            <?php wp_print_media_templates(); ?>
            <?php wp_print_footer_scripts(); ?>
        </body>
        </html>
        <?php
        exit; // Full page, no WP admin chrome
    }

    /**
     * AJAX: Publish (or update) the page — saves content and sets status to publish.
     */
    public function ajax_chat_publish(): void {
        check_ajax_referer( 'virobuilder_nonce' );

        $post_id = absint( $_POST['post_id'] ?? 0 );
        if ( ! $post_id || ! current_user_can( 'publish_posts' ) || ! current_user_can( 'edit_post', $post_id ) ) {
            wp_send_json_error( [ 'message' => 'Permission denied.' ], 403 );
        }

        // phpcs:ignore WordPress.Security.ValidatedSanitizedInput.InputNotSanitized -- full HTML document; nonce + edit_post capability verified above
        $current_html = wp_unslash( $_POST['current_html'] ?? '' );

        wp_update_post( [
            'ID'           => $post_id,
            'post_content' => $current_html,
            'post_status'  => 'publish',
        ] );
        update_post_meta( $post_id, '_virobuilder_designer_page', '1' );

        wp_send_json_success( [
            'published' => true,
            'view_url'  => get_permalink( $post_id ),
        ] );
    }

    /**
     * AJAX: Process a chat edit instruction.
     */
    public function ajax_chat_edit(): void {
        check_ajax_referer( 'virobuilder_nonce' );

        if ( ! current_user_can( 'edit_posts' ) ) {
            wp_send_json_error( [ 'message' => 'Permission denied' ], 403 );
        }

        $post_id     = absint( $_POST['post_id'] ?? 0 );
        $instruction = sanitize_textarea_field( wp_unslash( $_POST['instruction'] ?? '' ) );
        // phpcs:ignore WordPress.Security.ValidatedSanitizedInput.InputNotSanitized -- full HTML document; nonce + edit_post capability verified above
        $current_html = wp_unslash( $_POST['current_html'] ?? '' );

        if ( ! $post_id || ! current_user_can( 'edit_post', $post_id ) ) {
            wp_send_json_error( [ 'message' => 'Invalid post.' ], 400 );
        }

        // Special: save command (no AI call needed)
        if ( $instruction === '__save__' ) {
            wp_update_post( [
                'ID'           => $post_id,
                'post_content' => $current_html,
            ] );
            update_post_meta( $post_id, '_virobuilder_designer_page', '1' );
            wp_send_json_success( [ 'saved' => true ] );
            return;
        }

        if ( empty( $instruction ) ) {
            wp_send_json_error( [ 'message' => 'No instruction provided.' ], 400 );
        }

        // Get API key
        $api_key = get_option( 'virobuilder_ai_api_key', '' );
        if ( empty( $api_key ) ) {
            wp_send_json_error( [ 'message' => 'No API key configured.' ], 400 );
        }

        // Get chat history for context
        $history = get_post_meta( $post_id, '_virobuilder_chat_history', true );
        if ( ! is_array( $history ) ) $history = [];

        // Build messages
        $system  = virobuilder_editor_system_prompt();
        $messages = virobuilder_editor_build_messages( $current_html, $instruction, $history );

        // Call Claude
        $response = wp_remote_post( 'https://api.anthropic.com/v1/messages', [
            'timeout' => 300,
            'headers' => [
                'Content-Type'      => 'application/json',
                'x-api-key'         => $api_key,
                'anthropic-version' => '2023-06-01',
            ],
            'body' => wp_json_encode( [
                'model'      => self::AI_MODEL,
                'max_tokens' => 16000,
                'system'     => $system,
                'messages'   => $messages,
            ] ),
        ] );

        if ( is_wp_error( $response ) ) {
            wp_send_json_error( [ 'message' => 'AI request failed: ' . $response->get_error_message() ], 500 );
        }

        $code = wp_remote_retrieve_response_code( $response );
        $body = wp_remote_retrieve_body( $response );

        if ( $code !== 200 ) {
            $err = json_decode( $body, true );
            wp_send_json_error( [ 'message' => $err['error']['message'] ?? "HTTP $code" ], 500 );
        }

        $data = json_decode( $body, true );
        $new_html = '';
        foreach ( ( $data['content'] ?? [] ) as $block ) {
            if ( ( $block['type'] ?? '' ) === 'text' ) {
                $new_html .= $block['text'];
            }
        }

        // Strip code fences
        $new_html = preg_replace( '/^```html?\s*/i', '', $new_html );
        $new_html = preg_replace( '/\s*```\s*$/', '', $new_html );
        $new_html = trim( $new_html );

        // Extract just the HTML document — strip any AI preamble/explanation
        // before <!DOCTYPE or <html, and any trailing text after </html>
        $doctype_pos = stripos( $new_html, '<!DOCTYPE' );
        $html_pos = stripos( $new_html, '<html' );
        $start = false;
        if ( $doctype_pos !== false ) {
            $start = $doctype_pos;
        } elseif ( $html_pos !== false ) {
            $start = $html_pos;
        }
        if ( $start !== false && $start > 0 ) {
            $new_html = substr( $new_html, $start );
        }
        // Trim anything after the closing </html>
        $end_pos = stripos( $new_html, '</html>' );
        if ( $end_pos !== false ) {
            $new_html = substr( $new_html, 0, $end_pos + 7 );
        }
        $new_html = trim( $new_html );

        // Validate it's still HTML
        if ( stripos( $new_html, '<html' ) === false && stripos( $new_html, '<!DOCTYPE' ) === false ) {
            wp_send_json_error( [
                'message' => 'The AI could not complete that edit. Try rephrasing — for example, instead of "change the structure," try "move the about section above the services" or "add a testimonials section after the hero."',
            ], 500 );
        }

        // Resolve any new image placeholders
        if ( function_exists( 'virobuilder_ai_get_image_provider' ) && preg_match( '/\{\{[A-Z_0-9]+\}\}/', $new_html ) ) {
            $new_html = $this->resolve_image_placeholders( $new_html );
        }

        // Save chat history
        $history[] = [ 'role' => 'user', 'content' => $instruction ];
        $history[] = [ 'role' => 'assistant', 'content' => '(page updated)' ];
        // Keep last 20 exchanges max
        if ( count( $history ) > 40 ) {
            $history = array_slice( $history, -40 );
        }
        update_post_meta( $post_id, '_virobuilder_chat_history', $history );

        // Auto-save the HTML
        wp_update_post( [
            'ID'           => $post_id,
            'post_content' => $new_html,
        ] );
        update_post_meta( $post_id, '_virobuilder_designer_page', '1' );

        // Cost estimate
        $usage = $data['usage'] ?? [];
        $in = $usage['input_tokens'] ?? 0;
        $out = $usage['output_tokens'] ?? 0;
        $cost = ( $in * 0.003 / 1000 ) + ( $out * 0.015 / 1000 );

        wp_send_json_success( [
            'html'    => $new_html,
            'summary' => $this->generate_change_summary( $instruction ),
            'cost'    => number_format( $cost, 4 ),
            'usage'   => $usage,
        ] );
    }

    /**
     * Generate a human-readable summary of what changed.
     */
    private function generate_change_summary( string $instruction ): string {
        $lower = strtolower( $instruction );

        if ( strpos( $lower, 'color' ) !== false ) return '✓ Colors updated';
        if ( strpos( $lower, 'headline' ) !== false || strpos( $lower, 'heading' ) !== false ) return '✓ Headline updated';
        if ( strpos( $lower, 'image' ) !== false || strpos( $lower, 'photo' ) !== false ) return '✓ Image updated';
        if ( strpos( $lower, 'add' ) !== false ) return '✓ Section added';
        if ( strpos( $lower, 'remove' ) !== false || strpos( $lower, 'delete' ) !== false ) return '✓ Section removed';
        if ( strpos( $lower, 'move' ) !== false || strpos( $lower, 'reorder' ) !== false ) return '✓ Sections reordered';
        if ( strpos( $lower, 'font' ) !== false ) return '✓ Typography updated';

        return '✓ Page updated';
    }

    /**
     * Resolve {{IMAGE_SLOT}} placeholders via Pexels.
     */
    private function resolve_image_placeholders( string $html ): string {
        $pexels_key = get_option( 'virobuilder_pexels_api_key', '' );
        if ( empty( $pexels_key ) ) return $html;

        $provider = virobuilder_ai_get_image_provider();

        if ( preg_match_all( '/\{\{([A-Z_0-9]+)\}\}/', $html, $matches ) ) {
            foreach ( $matches[1] as $slot ) {
                // Check for data-viro-image-query on nearby img tags
                $query = '';
                if ( preg_match( '/data-viro-image-query="([^"]+)"/', $html, $qm ) ) {
                    $query = $qm[1];
                }
                if ( empty( $query ) ) {
                    // Derive query from slot name
                    $query = strtolower( str_replace( '_', ' ', $slot ) );
                }

                $results = $provider->search( $query, 5, 'landscape' );
                if ( ! empty( $results[0]['url'] ) ) {
                    $html = str_replace( '{{' . $slot . '}}', esc_url( $results[0]['url'] ), $html );
                }
            }
        }

        return $html;
    }

    /**
     * AJAX: Get chat history for a post.
     */
    public function ajax_get_history(): void {
        check_ajax_referer( 'virobuilder_nonce' );
        $post_id = absint( $_POST['post_id'] ?? 0 );
        if ( ! $post_id || ! current_user_can( 'edit_post', $post_id ) ) {
            wp_send_json_error( [ 'message' => 'Invalid post.' ], 400 );
        }
        $history = get_post_meta( $post_id, '_virobuilder_chat_history', true );
        wp_send_json_success( [ 'history' => is_array( $history ) ? $history : [] ] );
    }

    /**
     * AJAX: Re-resolve image placeholders in current HTML.
     */
    public function ajax_resolve_images(): void {
        check_ajax_referer( 'virobuilder_nonce' );

        if ( ! current_user_can( 'edit_posts' ) ) {
            wp_send_json_error( [ 'message' => 'Permission denied' ], 403 );
        }

        // phpcs:ignore WordPress.Security.ValidatedSanitizedInput.InputNotSanitized -- full HTML document; nonce + capability verified in this handler
        $html = wp_unslash( $_POST['html'] ?? '' );
        $resolved = $this->resolve_image_placeholders( $html );
        wp_send_json_success( [ 'html' => $resolved ] );
    }
}
