<?php
/**
 * AI Quick-Build style presets.
 *
 * A "style preset" is a post-assembly transformation applied to a generated page.
 * After copy + images are filled into section templates, the chosen preset retints
 * the page: it sets a section-by-section background rhythm, applies a color palette
 * derived from the user's brand color, swaps typography, and styles components
 * (cards, buttons, eyebrows). This is what turns a flat, all-white page into a
 * visually confident, on-trend design.
 *
 * Each industry exposes 2-3 presets that match current UX/UI norms for that field.
 * The user picks one in the AI Quick-Build flow before generating.
 *
 * Preset shape:
 *   id, label, blurb           - identity shown in the picker
 *   swatch                     - { bg, accent, text } colors for the picker chip
 *   font_heading, font_body    - Google font family stacks
 *   heading_weight, heading_ls - typographic feel
 *   radius                     - component corner radius (px, as string)
 *   card                       - 'flat' | 'soft' | 'bordered'
 *   rhythm                     - ordered list of section treatments, cycled across
 *                                the page: 'light' | 'tinted' | 'dark' | 'brand'
 *   tints                      - derived neutral + brand tints (computed at runtime)
 *
 * @package ViroBuilder
 */

defined( 'ABSPATH' ) || exit;

/**
 * Return the style presets available for a given industry key.
 * Falls back to the SaaS presets for any industry not yet specialised.
 */
function virobuilder_ai_get_styles_for_industry( string $industry ): array {
    $map = virobuilder_ai_all_styles();
    return $map[ $industry ] ?? $map['saas'];
}

/**
 * Look up a single style preset by industry + style id.
 */
function virobuilder_ai_get_style( string $industry, string $style_id ): ?array {
    foreach ( virobuilder_ai_get_styles_for_industry( $industry ) as $style ) {
        if ( $style['id'] === $style_id ) {
            return $style;
        }
    }
    // Fall back to the first style for the industry.
    $styles = virobuilder_ai_get_styles_for_industry( $industry );
    return $styles[0] ?? null;
}

/**
 * The full registry. Phase 1 ships SaaS with three genuine presets;
 * other industries inherit the SaaS set until they are specialised.
 */
function virobuilder_ai_all_styles(): array {
    static $all = null;
    if ( $all !== null ) return $all;

    $saas = [
        // 1. Bold, dark, high-contrast — Linear / Vercel territory.
        [
            'id'             => 'nimbus',
            'label'          => 'Nimbus',
            'blurb'          => 'Bold & dark. High-contrast hero, gradient accents, tight modern type. Reads premium and technical.',
            'swatch'         => [ 'bg' => '#0b1020', 'accent' => '#6366f1', 'text' => '#ffffff' ],
            'font_heading'   => "'Space Grotesk', 'Plus Jakarta Sans', sans-serif",
            'font_body'      => "'Inter', sans-serif",
            'heading_weight' => '700',
            'heading_ls'     => '-1.5',
            'radius'         => '14',
            'card'           => 'soft',
            // hero dark, then alternating light/tinted, a dark band before CTA, brand CTA.
            'rhythm'         => [ 'dark', 'light', 'tinted', 'light', 'dark', 'light', 'brand' ],
        ],
        // 2. Clean, light, airy — Stripe territory.
        [
            'id'             => 'clarity',
            'label'          => 'Clarity',
            'blurb'          => 'Clean & airy. Generous white space, soft shadows, brand used as a precise accent. Trustworthy and calm.',
            'swatch'         => [ 'bg' => '#ffffff', 'accent' => '#635bff', 'text' => '#0a2540' ],
            'font_heading'   => "'Plus Jakarta Sans', sans-serif",
            'font_body'      => "'Inter', sans-serif",
            'heading_weight' => '800',
            'heading_ls'     => '-1',
            'radius'         => '12',
            'card'           => 'soft',
            'rhythm'         => [ 'light', 'tinted', 'light', 'tinted', 'light', 'light', 'brand' ],
        ],
        // 3. Vibrant, rounded, friendly — Attio / Loops territory.
        [
            'id'             => 'pulse',
            'label'          => 'Pulse',
            'blurb'          => 'Vibrant & friendly. Rounded shapes, bright brand color blocks, approachable. Great for modern, playful products.',
            'swatch'         => [ 'bg' => '#fef6f0', 'accent' => '#ff6b4a', 'text' => '#1a1a2e' ],
            'font_heading'   => "'Plus Jakarta Sans', sans-serif",
            'font_body'      => "'DM Sans', sans-serif",
            'heading_weight' => '800',
            'heading_ls'     => '-0.5',
            'radius'         => '22',
            'card'           => 'bordered',
            'rhythm'         => [ 'tinted', 'light', 'brand', 'light', 'tinted', 'light', 'brand' ],
        ],
    ];

    $all = [
        'saas' => $saas,
        // Other industries inherit SaaS presets for now (Phase 2 specialises each).
    ];

    return $all;
}

/* ───────────────────────────── Color helpers ───────────────────────────── */

/**
 * Parse a #rrggbb hex string into [r,g,b]. Returns null on bad input.
 */
function virobuilder_ai_hex_to_rgb( string $hex ): ?array {
    $hex = ltrim( trim( $hex ), '#' );
    if ( strlen( $hex ) === 3 ) {
        $hex = $hex[0] . $hex[0] . $hex[1] . $hex[1] . $hex[2] . $hex[2];
    }
    if ( strlen( $hex ) !== 6 || ! ctype_xdigit( $hex ) ) {
        return null;
    }
    return [
        hexdec( substr( $hex, 0, 2 ) ),
        hexdec( substr( $hex, 2, 2 ) ),
        hexdec( substr( $hex, 4, 2 ) ),
    ];
}

function virobuilder_ai_rgb_to_hex( array $rgb ): string {
    return sprintf( '#%02x%02x%02x',
        max( 0, min( 255, (int) round( $rgb[0] ) ) ),
        max( 0, min( 255, (int) round( $rgb[1] ) ) ),
        max( 0, min( 255, (int) round( $rgb[2] ) ) )
    );
}

/**
 * Mix a color toward white by $amount (0..1). amount=0 returns the color,
 * amount=1 returns white. Used to make soft tinted section backgrounds.
 */
function virobuilder_ai_tint( string $hex, float $amount ): string {
    $rgb = virobuilder_ai_hex_to_rgb( $hex );
    if ( ! $rgb ) return '#f4f6fb';
    $mixed = [
        $rgb[0] + ( 255 - $rgb[0] ) * $amount,
        $rgb[1] + ( 255 - $rgb[1] ) * $amount,
        $rgb[2] + ( 255 - $rgb[2] ) * $amount,
    ];
    return virobuilder_ai_rgb_to_hex( $mixed );
}

/**
 * Mix a color toward black by $amount (0..1). Used for hover/darker brand.
 */
function virobuilder_ai_shade( string $hex, float $amount ): string {
    $rgb = virobuilder_ai_hex_to_rgb( $hex );
    if ( ! $rgb ) return '#0c2a4e';
    $mixed = [
        $rgb[0] * ( 1 - $amount ),
        $rgb[1] * ( 1 - $amount ),
        $rgb[2] * ( 1 - $amount ),
    ];
    return virobuilder_ai_rgb_to_hex( $mixed );
}

/**
 * Relative luminance (0..1) for choosing readable text on a background.
 */
function virobuilder_ai_luminance( string $hex ): float {
    $rgb = virobuilder_ai_hex_to_rgb( $hex );
    if ( ! $rgb ) return 1.0;
    $srgb = array_map( function( $c ) {
        $c = $c / 255;
        return $c <= 0.03928 ? $c / 12.92 : pow( ( $c + 0.055 ) / 1.055, 2.4 );
    }, $rgb );
    return 0.2126 * $srgb[0] + 0.7152 * $srgb[1] + 0.0722 * $srgb[2];
}

/**
 * Pick black or white text for best contrast on the given background.
 */
function virobuilder_ai_readable_text( string $bg_hex, string $dark = '#0f172a', string $light = '#ffffff' ): string {
    return virobuilder_ai_luminance( $bg_hex ) > 0.45 ? $dark : $light;
}

/**
 * Build the concrete palette for a preset given the user's brand color.
 * Returns a flat map of tokens the style applier writes into elements.
 */
function virobuilder_ai_build_palette( array $style, string $brand ): array {
    $brand = $brand ?: '#6366f1';

    // Dark section background: derive from brand for brand-flavored darks in Nimbus,
    // but keep it genuinely dark for contrast.
    $dark_bg = virobuilder_ai_shade( $brand, 0.78 );
    if ( virobuilder_ai_luminance( $dark_bg ) > 0.18 ) {
        $dark_bg = '#0b1020';
    }

    return [
        'brand'        => $brand,
        'brand_dark'   => virobuilder_ai_shade( $brand, 0.18 ),
        'brand_soft'   => virobuilder_ai_tint( $brand, 0.88 ), // very light brand wash
        'tinted_bg'    => virobuilder_ai_tint( $brand, 0.93 ),
        'dark_bg'      => $dark_bg,
        'light_bg'     => '#ffffff',
        'text_dark'    => '#0f172a',
        'text_muted'   => '#5b6473',
        'text_on_dark' => '#e7ebf3',
        'muted_on_dark'=> '#9aa6bd',
        'border'       => '#e6e9f0',
    ];
}
