<?php
/**
 * AI Quick-Build recipes.
 *
 * Each recipe defines an industry's landing page composition:
 *   - sections:    ordered list of section template IDs to compose
 *   - copy_keys:   per-section, the copy fields the AI must generate
 *   - substitutions: maps "widget_type:index:setting_key" => copy_key
 *   - image_targets: maps "widget_type:index:url_key" => image pool name
 *   - image_pools: per-industry, named arrays of Unsplash photo IDs
 *
 * @package ViroBuilder
 */

defined( 'ABSPATH' ) || exit;

function virobuilder_ai_get_industries(): array {
    static $industries = null;
    if ( $industries !== null ) return $industries;

    $industries = [
        'saas' => [
            'label' => 'SaaS / Software Product',
            'description' => 'Software product or platform with a free trial',
            'icon' => 'zap',
            'sections' => virobuilder_ai_recipe_saas(),
            'image_pools' => virobuilder_ai_image_pools_saas(),
        ],
        'agency' => [
            'label' => 'Marketing / Design Agency',
            'description' => 'Services agency selling design, marketing, or development',
            'icon' => 'briefcase',
            'sections' => virobuilder_ai_recipe_agency(),
            'image_pools' => virobuilder_ai_image_pools_agency(),
        ],
        'restaurant' => [
            'label' => 'Restaurant / Hospitality',
            'description' => 'Restaurant, café, bar, or hospitality business',
            'icon' => 'heart',
            'sections' => virobuilder_ai_recipe_restaurant(),
            'image_pools' => virobuilder_ai_image_pools_restaurant(),
        ],
        'health' => [
            'label' => 'Health / Wellness Clinic',
            'description' => 'Medical clinic, dental practice, therapy, wellness',
            'icon' => 'shield',
            'sections' => virobuilder_ai_recipe_health(),
            'image_pools' => virobuilder_ai_image_pools_health(),
        ],
        'realestate' => [
            'label' => 'Real Estate',
            'description' => 'Real estate broker, agency, or property listings',
            'icon' => 'home',
            'sections' => virobuilder_ai_recipe_realestate(),
            'image_pools' => virobuilder_ai_image_pools_realestate(),
        ],
        'law' => [
            'label' => 'Law Firm / Professional Services',
            'description' => 'Law firm, accounting, consulting, professional services',
            'icon' => 'briefcase',
            'sections' => virobuilder_ai_recipe_law(),
            'image_pools' => virobuilder_ai_image_pools_law(),
        ],
        'ecommerce' => [
            'label' => 'E-commerce / Product Sales',
            'description' => 'Physical product, DTC brand, e-commerce store',
            'icon' => 'shopping-bag',
            'sections' => virobuilder_ai_recipe_ecommerce(),
            'image_pools' => virobuilder_ai_image_pools_ecommerce(),
        ],
        'fitness' => [
            'label' => 'Fitness / Gym / Studio',
            'description' => 'Gym, yoga studio, personal trainer, fitness coach',
            'icon' => 'activity',
            'sections' => virobuilder_ai_recipe_fitness(),
            'image_pools' => virobuilder_ai_image_pools_fitness(),
        ],
    ];

    return $industries;
}

function virobuilder_ai_get_recipe( string $industry_id ): ?array {
    $all = virobuilder_ai_get_industries();
    return $all[ $industry_id ] ?? null;
}

// ════════════════════════════════════════════════════════════════
// IMAGE POOLS
// ════════════════════════════════════════════════════════════════
function virobuilder_ai_image_pools_saas(): array {
    return [
        'hero' => [ 'photo-1551288049-bebda4e38f71', 'photo-1460925895917-afdab827c52f', 'photo-1551434678-e076c223a692' ],
        'feature' => [ 'photo-1581291518857-4e27b48ff24e', 'photo-1517048676732-d65bc937f952', 'photo-1559136555-9303baea8ebd' ],
    ];
}
function virobuilder_ai_image_pools_agency(): array {
    return [
        'hero' => [ 'photo-1542744173-8e7e53415bb0', 'photo-1497366216548-37526070297c', 'photo-1556761175-b413da4baf72' ],
        'feature' => [ 'photo-1559028012-481c04fa702d', 'photo-1545239351-cefa43af60f3', 'photo-1581291518857-4e27b48ff24e' ],
    ];
}
function virobuilder_ai_image_pools_restaurant(): array {
    return [
        'hero' => [ 'photo-1517248135467-4c7edcad34c4', 'photo-1414235077428-338989a2e8c0', 'photo-1559339352-11d035aa65de' ],
        'feature' => [ 'photo-1546069901-ba9599a7e63c', 'photo-1565299624946-b28f40a0ae38', 'photo-1551782450-a2132b4ba21d' ],
    ];
}
function virobuilder_ai_image_pools_health(): array {
    return [
        'hero' => [ 'photo-1576091160399-112ba8d25d1d', 'photo-1631815589968-fdb09a223b1e', 'photo-1505751172876-fa1923c5c528' ],
        'feature' => [ 'photo-1571019613454-1cb2f99b2d8b', 'photo-1591343395082-e120087004b4', 'photo-1559757148-5c350d0d3c56' ],
    ];
}
function virobuilder_ai_image_pools_realestate(): array {
    return [
        'hero' => [ 'photo-1564013799919-ab600027ffc6', 'photo-1600585154340-be6161a56a0c', 'photo-1512917774080-9991f1c4c750' ],
        'feature' => [ 'photo-1600596542815-ffad4c1539a9', 'photo-1600573472550-8090b5e0745e', 'photo-1600607687939-ce8a6c25118c' ],
    ];
}
function virobuilder_ai_image_pools_law(): array {
    return [
        'hero' => [ 'photo-1450101499163-c8848c66ca85', 'photo-1589216532372-1c2a367900d9', 'photo-1521587760476-6c12a4b040da' ],
        'feature' => [ 'photo-1521791136064-7986c2920216', 'photo-1556761175-b413da4baf72', 'photo-1573497019940-1c28c88b4f3e' ],
    ];
}
function virobuilder_ai_image_pools_ecommerce(): array {
    return [
        'hero' => [ 'photo-1607082348824-0a96f2a4b9da', 'photo-1556905055-8f358a7a47b2', 'photo-1611042553365-9b101441c135' ],
        'feature' => [ 'photo-1523275335684-37898b6baf30', 'photo-1542291026-7eec264c27ff', 'photo-1572635196237-14b3f281503f' ],
    ];
}
function virobuilder_ai_image_pools_fitness(): array {
    return [
        'hero' => [ 'photo-1534438327276-14e5300c3a48', 'photo-1571902943202-507ec2618e8f', 'photo-1517836357463-d25dfeac3438' ],
        'feature' => [ 'photo-1599058917212-d750089bc07e', 'photo-1574680096145-d05b474e2155', 'photo-1571019613454-1cb2f99b2d8b' ],
    ];
}

// ════════════════════════════════════════════════════════════════
// SHARED SECTIONS
// ════════════════════════════════════════════════════════════════
function virobuilder_ai_section_faq( array $copy_keys = [] ): array {
    return [
        'section_id' => 'faq-modern',
        'copy_keys' => array_merge( [
            'headline' => 'Common questions',
            'subhead'  => "Can't find what you're looking for?",
            'q1' => 'A common question your audience asks',
            'a1' => 'Honest, specific answer (2-3 sentences)',
            'q2' => 'A common question your audience asks',
            'a2' => 'Honest, specific answer (2-3 sentences)',
            'q3' => 'A common question your audience asks',
            'a3' => 'Honest, specific answer (2-3 sentences)',
            'q4' => 'A common question your audience asks',
            'a4' => 'Honest, specific answer (2-3 sentences)',
            'q5' => 'A common question your audience asks',
            'a5' => 'Honest, specific answer (2-3 sentences)',
        ], $copy_keys ),
        'substitutions' => [
            'heading:0:title'        => 'headline',
            'text-editor:0:content'  => 'subhead',
            'faq:0:q1' => 'q1', 'faq:0:a1' => 'a1',
            'faq:0:q2' => 'q2', 'faq:0:a2' => 'a2',
            'faq:0:q3' => 'q3', 'faq:0:a3' => 'a3',
            'faq:0:q4' => 'q4', 'faq:0:a4' => 'a4',
            'faq:0:q5' => 'q5', 'faq:0:a5' => 'a5',
        ],
    ];
}

function virobuilder_ai_section_cta( string $cta_text = 'Get started →' ): array {
    return [
        'section_id' => 'cta-modern-gradient',
        'copy_keys' => [
            'eyebrow'  => 'READY?',
            'headline' => 'Final CTA headline (4-6 words)',
            'subhead'  => 'Specific reason to act now (1 sentence)',
            'cta_text' => $cta_text,
        ],
        'substitutions' => [
            'eyebrow:0:text'         => 'eyebrow',
            'heading:0:title'        => 'headline',
            'text-editor:0:content'  => 'subhead',
            'button:0:text'          => 'cta_text',
        ],
    ];
}

function virobuilder_ai_section_testimonials( string $eyebrow = 'CUSTOMER STORIES' ): array {
    return [
        'section_id' => 'testimonials-modern-3',
        'copy_keys' => [
            'eyebrow'   => $eyebrow,
            'headline'  => 'What people say about {name}',
            'quote1'    => 'Realistic-sounding customer quote about {name} - 2 sentences max',
            'name1'     => 'Plausible customer name',
            'title1'    => 'Their role · their company or context',
            'quote2'    => 'Different customer quote about {name} - 2 sentences max',
            'name2'     => 'Plausible customer name (different person)',
            'title2'    => 'Their role · their company or context',
            'quote3'    => 'Different customer quote about {name} - 2 sentences max',
            'name3'     => 'Plausible customer name (different person)',
            'title3'    => 'Their role · their company or context',
        ],
        'substitutions' => [
            'eyebrow:0:text'           => 'eyebrow',
            'heading:0:title'          => 'headline',
            'testimonial:0:content'    => 'quote1',
            'testimonial:0:name'       => 'name1',
            'testimonial:0:title'      => 'title1',
            'testimonial:1:content'    => 'quote2',
            'testimonial:1:name'       => 'name2',
            'testimonial:1:title'      => 'title2',
            'testimonial:2:content'    => 'quote3',
            'testimonial:2:name'       => 'name3',
            'testimonial:2:title'      => 'title3',
        ],
    ];
}

// ════════════════════════════════════════════════════════════════
// SaaS
// ════════════════════════════════════════════════════════════════
function virobuilder_ai_recipe_saas(): array {
    return [
        [
            'section_id' => 'hero-modern-saas',
            'copy_keys' => [
                'eyebrow'    => 'INTRODUCING {name}',
                'headline'   => 'Specific value prop for {name} - max 8 words',
                'subhead'    => 'What {name} does for {audience} - 1-2 sentences',
                'cta_text'   => 'Action verb + outcome',
                'cta_micro'  => 'NO CREDIT CARD · 14-DAY FREE TRIAL',
            ],
            'substitutions' => [
                'eyebrow:0:text'         => 'eyebrow',
                'heading:0:title'        => 'headline',
                'text-editor:0:content'  => 'subhead',
                'button:0:text'          => 'cta_text',
                'eyebrow:1:text'         => 'cta_micro',
            ],
            'brand_color_targets' => [ 'button:0:bg_color', 'button:0:hover_bg_color' ],
        ],
        [
            'section_id' => 'problem-agitation-3',
            'copy_keys' => [
                'eyebrow'    => 'THE PROBLEM',
                'headline'   => 'Why the old way of {offering} is broken',
                'pain1_title'=> 'Pain point #1 short headline (3-5 words)',
                'pain1_body' => 'Specific pain {audience} feels - 2 sentences max',
                'pain2_title'=> 'Pain point #2 short headline (3-5 words)',
                'pain2_body' => 'Specific pain {audience} feels - 2 sentences max',
                'pain3_title'=> 'Pain point #3 short headline (3-5 words)',
                'pain3_body' => 'Specific pain {audience} feels - 2 sentences max',
            ],
            'substitutions' => [
                'eyebrow:0:text'         => 'eyebrow',
                'heading:0:title'        => 'headline',
                'icon-box:0:title'       => 'pain1_title',
                'icon-box:0:description' => 'pain1_body',
                'icon-box:1:title'       => 'pain2_title',
                'icon-box:1:description' => 'pain2_body',
                'icon-box:2:title'       => 'pain3_title',
                'icon-box:2:description' => 'pain3_body',
            ],
        ],
        [
            'section_id' => 'features-modern-grid',
            'copy_keys' => [
                'eyebrow'        => 'FEATURES',
                'headline'       => 'What {name} actually does',
                'subhead'        => 'Concrete capabilities, no fluff',
                'feat1_title'    => 'Feature 1 name (2-3 words)',
                'feat1_desc'     => 'What it does and why it matters - 1-2 sentences',
                'feat2_title'    => 'Feature 2 name (2-3 words)',
                'feat2_desc'     => 'What it does and why it matters - 1-2 sentences',
                'feat3_title'    => 'Feature 3 name (2-3 words)',
                'feat3_desc'     => 'What it does and why it matters - 1-2 sentences',
            ],
            'substitutions' => [
                'eyebrow:0:text'         => 'eyebrow',
                'heading:0:title'        => 'headline',
                'text-editor:0:content'  => 'subhead',
                'icon-box:0:title'       => 'feat1_title',
                'icon-box:0:description' => 'feat1_desc',
                'icon-box:1:title'       => 'feat2_title',
                'icon-box:1:description' => 'feat2_desc',
                'icon-box:2:title'       => 'feat3_title',
                'icon-box:2:description' => 'feat3_desc',
            ],
        ],
        virobuilder_ai_section_testimonials( 'CUSTOMER STORIES' ),
        [
            'section_id' => 'pricing-modern-3-tier',
            'copy_keys' => [
                'eyebrow'        => 'PRICING',
                'headline'       => 'Simple pricing for {name}',
                'subhead'        => 'No long contracts. Cancel anytime.',
                'tier1_name'     => 'Cheapest tier name (1 word)',
                'tier1_subtitle' => 'Who it is for',
                'tier1_price'    => 'Price as number only (e.g. 9 or 0)',
                'tier1_features' => 'Features as newline-separated list (4-5 items)',
                'tier1_button'   => 'CTA for this tier',
                'tier2_name'     => 'Middle (featured) tier name',
                'tier2_subtitle' => 'Who it is for',
                'tier2_price'    => 'Price as number only',
                'tier2_features' => 'Features list, newline-separated, 6-8 items',
                'tier2_button'   => 'CTA for this tier',
                'tier3_name'     => 'Top tier name',
                'tier3_subtitle' => 'Who it is for',
                'tier3_price'    => 'Price as number only',
                'tier3_features' => 'Features list, newline-separated, 6-8 items',
                'tier3_button'   => 'CTA for this tier',
            ],
            'substitutions' => [
                'eyebrow:0:text'              => 'eyebrow',
                'heading:0:title'             => 'headline',
                'text-editor:0:content'       => 'subhead',
                'pricing-table:0:plan_name'   => 'tier1_name',
                'pricing-table:0:subtitle'    => 'tier1_subtitle',
                'pricing-table:0:price'       => 'tier1_price',
                'pricing-table:0:features'    => 'tier1_features',
                'pricing-table:0:button_text' => 'tier1_button',
                'pricing-table:1:plan_name'   => 'tier2_name',
                'pricing-table:1:subtitle'    => 'tier2_subtitle',
                'pricing-table:1:price'       => 'tier2_price',
                'pricing-table:1:features'    => 'tier2_features',
                'pricing-table:1:button_text' => 'tier2_button',
                'pricing-table:2:plan_name'   => 'tier3_name',
                'pricing-table:2:subtitle'    => 'tier3_subtitle',
                'pricing-table:2:price'       => 'tier3_price',
                'pricing-table:2:features'    => 'tier3_features',
                'pricing-table:2:button_text' => 'tier3_button',
            ],
        ],
        virobuilder_ai_section_faq(),
        virobuilder_ai_section_cta( 'Start free trial →' ),
    ];
}

// ════════════════════════════════════════════════════════════════
// Agency
// ════════════════════════════════════════════════════════════════
function virobuilder_ai_recipe_agency(): array {
    return [
        [
            'section_id' => 'hero-asymmetric-split',
            'copy_keys' => [
                'eyebrow'    => 'INDEPENDENT STUDIO',
                'headline'   => 'Headline pitching {name} services - max 8 words',
                'subhead'    => 'What {name} does for {audience} - 1-2 sentences',
                'cta_text'   => 'Start a project →',
            ],
            'substitutions' => [
                'eyebrow:0:text'         => 'eyebrow',
                'heading:0:title'        => 'headline',
                'text-editor:0:content'  => 'subhead',
                'button:0:text'          => 'cta_text',
            ],
            'brand_color_targets' => [ 'button:0:bg_color', 'button:0:hover_bg_color' ],
            'image_targets' => [ 'image:0:image_url' => 'hero' ],
        ],
        [
            'section_id' => 'services-grid-6',
            'copy_keys' => [
                'eyebrow'   => 'WHAT WE DO',
                'headline'  => 'Services {name} offers',
                'serv1_title' => 'Service 1 name (2-3 words)',
                'serv1_desc'  => 'What it includes - 1-2 sentences',
                'serv2_title' => 'Service 2 name (2-3 words)',
                'serv2_desc'  => 'What it includes - 1-2 sentences',
                'serv3_title' => 'Service 3 name (2-3 words)',
                'serv3_desc'  => 'What it includes - 1-2 sentences',
                'serv4_title' => 'Service 4 name (2-3 words)',
                'serv4_desc'  => 'What it includes - 1-2 sentences',
                'serv5_title' => 'Service 5 name (2-3 words)',
                'serv5_desc'  => 'What it includes - 1-2 sentences',
                'serv6_title' => 'Service 6 name (2-3 words)',
                'serv6_desc'  => 'What it includes - 1-2 sentences',
            ],
            'substitutions' => [
                'eyebrow:0:text'         => 'eyebrow',
                'heading:0:title'        => 'headline',
                'icon-box:0:title'       => 'serv1_title',
                'icon-box:0:description' => 'serv1_desc',
                'icon-box:1:title'       => 'serv2_title',
                'icon-box:1:description' => 'serv2_desc',
                'icon-box:2:title'       => 'serv3_title',
                'icon-box:2:description' => 'serv3_desc',
                'icon-box:3:title'       => 'serv4_title',
                'icon-box:3:description' => 'serv4_desc',
                'icon-box:4:title'       => 'serv5_title',
                'icon-box:4:description' => 'serv5_desc',
                'icon-box:5:title'       => 'serv6_title',
                'icon-box:5:description' => 'serv6_desc',
            ],
        ],
        virobuilder_ai_section_testimonials( 'CLIENT STORIES' ),
        virobuilder_ai_section_faq(),
        virobuilder_ai_section_cta( 'Start a project →' ),
    ];
}

// ════════════════════════════════════════════════════════════════
// Restaurant
// ════════════════════════════════════════════════════════════════
function virobuilder_ai_recipe_restaurant(): array {
    return [
        [
            'section_id' => 'hero-asymmetric-split',
            'copy_keys' => [
                'eyebrow'    => 'CUISINE TYPE · NEIGHBORHOOD',
                'headline'   => "{name}'s tagline - max 8 words evocative",
                'subhead'    => 'What makes {name} different - 1-2 sentences',
                'cta_text'   => 'Reserve a table →',
            ],
            'substitutions' => [
                'eyebrow:0:text'         => 'eyebrow',
                'heading:0:title'        => 'headline',
                'text-editor:0:content'  => 'subhead',
                'button:0:text'          => 'cta_text',
            ],
            'brand_color_targets' => [ 'button:0:bg_color', 'button:0:hover_bg_color' ],
            'image_targets' => [ 'image:0:image_url' => 'hero' ],
        ],
        [
            'section_id' => 'features-modern-grid',
            'copy_keys' => [
                'eyebrow'        => 'WHAT TO EXPECT',
                'headline'       => 'A few things to know about {name}',
                'subhead'        => 'Subhead about the dining experience',
                'feat1_title'    => 'Aspect 1 (e.g. "Seasonal menu")',
                'feat1_desc'     => 'Description - 1-2 sentences',
                'feat2_title'    => 'Aspect 2 (e.g. "Local sourcing")',
                'feat2_desc'     => 'Description - 1-2 sentences',
                'feat3_title'    => 'Aspect 3 (e.g. "Intimate space")',
                'feat3_desc'     => 'Description - 1-2 sentences',
            ],
            'substitutions' => [
                'eyebrow:0:text'         => 'eyebrow',
                'heading:0:title'        => 'headline',
                'text-editor:0:content'  => 'subhead',
                'icon-box:0:title'       => 'feat1_title',
                'icon-box:0:description' => 'feat1_desc',
                'icon-box:1:title'       => 'feat2_title',
                'icon-box:1:description' => 'feat2_desc',
                'icon-box:2:title'       => 'feat3_title',
                'icon-box:2:description' => 'feat3_desc',
            ],
        ],
        virobuilder_ai_section_testimonials( 'GUESTS SAY' ),
        virobuilder_ai_section_faq( [
            'q1' => 'A common reservation/dining question',
            'q2' => 'A common menu or dietary question',
            'q3' => 'A common timing or hours question',
            'q4' => 'A common parking or location question',
            'q5' => 'A common private events question',
        ] ),
        virobuilder_ai_section_cta( 'Reserve a table →' ),
    ];
}

// ════════════════════════════════════════════════════════════════
// Health / Wellness
// ════════════════════════════════════════════════════════════════
function virobuilder_ai_recipe_health(): array {
    return [
        [
            'section_id' => 'hero-asymmetric-split',
            'copy_keys' => [
                'eyebrow'    => 'EVIDENCE-BASED · MODERN APPROACH',
                'headline'   => 'Healthcare headline for {name} - reassuring, calm',
                'subhead'    => 'What {name} offers patients - 1-2 sentences',
                'cta_text'   => 'Book an appointment →',
            ],
            'substitutions' => [
                'eyebrow:0:text'         => 'eyebrow',
                'heading:0:title'        => 'headline',
                'text-editor:0:content'  => 'subhead',
                'button:0:text'          => 'cta_text',
            ],
            'brand_color_targets' => [ 'button:0:bg_color', 'button:0:hover_bg_color' ],
            'image_targets' => [ 'image:0:image_url' => 'hero' ],
        ],
        [
            'section_id' => 'services-grid-6',
            'copy_keys' => [
                'eyebrow'   => 'OUR SERVICES',
                'headline'  => "How {name} helps {audience}",
                'serv1_title' => 'Service 1 name',
                'serv1_desc'  => 'What it includes - 1-2 sentences',
                'serv2_title' => 'Service 2 name',
                'serv2_desc'  => 'What it includes - 1-2 sentences',
                'serv3_title' => 'Service 3 name',
                'serv3_desc'  => 'What it includes - 1-2 sentences',
                'serv4_title' => 'Service 4 name',
                'serv4_desc'  => 'What it includes - 1-2 sentences',
                'serv5_title' => 'Service 5 name',
                'serv5_desc'  => 'What it includes - 1-2 sentences',
                'serv6_title' => 'Service 6 name',
                'serv6_desc'  => 'What it includes - 1-2 sentences',
            ],
            'substitutions' => [
                'eyebrow:0:text'         => 'eyebrow',
                'heading:0:title'        => 'headline',
                'icon-box:0:title'       => 'serv1_title',
                'icon-box:0:description' => 'serv1_desc',
                'icon-box:1:title'       => 'serv2_title',
                'icon-box:1:description' => 'serv2_desc',
                'icon-box:2:title'       => 'serv3_title',
                'icon-box:2:description' => 'serv3_desc',
                'icon-box:3:title'       => 'serv4_title',
                'icon-box:3:description' => 'serv4_desc',
                'icon-box:4:title'       => 'serv5_title',
                'icon-box:4:description' => 'serv5_desc',
                'icon-box:5:title'       => 'serv6_title',
                'icon-box:5:description' => 'serv6_desc',
            ],
        ],
        virobuilder_ai_section_testimonials( 'PATIENT STORIES' ),
        virobuilder_ai_section_faq( [
            'q1' => 'A common question about insurance/coverage',
            'q2' => 'A common question about first-visit expectations',
            'q3' => 'A common question about appointment scheduling',
            'q4' => 'A common question about emergencies/urgent care',
            'q5' => 'A common question about specific procedures',
        ] ),
        virobuilder_ai_section_cta( 'Book an appointment →' ),
    ];
}

// ════════════════════════════════════════════════════════════════
// Real Estate
// ════════════════════════════════════════════════════════════════
function virobuilder_ai_recipe_realestate(): array {
    return [
        [
            'section_id' => 'hero-asymmetric-split',
            'copy_keys' => [
                'eyebrow'    => "{name}'S MARKET · YEAR ESTABLISHED",
                'headline'   => 'Real estate headline for {name} - confident',
                'subhead'    => 'What {name} does for buyers/sellers - 1-2 sentences',
                'cta_text'   => 'Browse listings →',
            ],
            'substitutions' => [
                'eyebrow:0:text'         => 'eyebrow',
                'heading:0:title'        => 'headline',
                'text-editor:0:content'  => 'subhead',
                'button:0:text'          => 'cta_text',
            ],
            'brand_color_targets' => [ 'button:0:bg_color', 'button:0:hover_bg_color' ],
            'image_targets' => [ 'image:0:image_url' => 'hero' ],
        ],
        [
            'section_id' => 'services-grid-6',
            'copy_keys' => [
                'eyebrow'   => 'WHAT WE DO',
                'headline'  => "How {name} helps you buy or sell",
                'serv1_title' => 'Service 1 (e.g. "Buyer representation")',
                'serv1_desc'  => 'What it includes - 1-2 sentences',
                'serv2_title' => 'Service 2',
                'serv2_desc'  => 'What it includes - 1-2 sentences',
                'serv3_title' => 'Service 3',
                'serv3_desc'  => 'What it includes - 1-2 sentences',
                'serv4_title' => 'Service 4',
                'serv4_desc'  => 'What it includes - 1-2 sentences',
                'serv5_title' => 'Service 5',
                'serv5_desc'  => 'What it includes - 1-2 sentences',
                'serv6_title' => 'Service 6',
                'serv6_desc'  => 'What it includes - 1-2 sentences',
            ],
            'substitutions' => [
                'eyebrow:0:text'         => 'eyebrow',
                'heading:0:title'        => 'headline',
                'icon-box:0:title'       => 'serv1_title',
                'icon-box:0:description' => 'serv1_desc',
                'icon-box:1:title'       => 'serv2_title',
                'icon-box:1:description' => 'serv2_desc',
                'icon-box:2:title'       => 'serv3_title',
                'icon-box:2:description' => 'serv3_desc',
                'icon-box:3:title'       => 'serv4_title',
                'icon-box:3:description' => 'serv4_desc',
                'icon-box:4:title'       => 'serv5_title',
                'icon-box:4:description' => 'serv5_desc',
                'icon-box:5:title'       => 'serv6_title',
                'icon-box:5:description' => 'serv6_desc',
            ],
        ],
        virobuilder_ai_section_testimonials( 'CLIENT STORIES' ),
        virobuilder_ai_section_faq( [
            'q1' => 'A common question about commission structure',
            'q2' => 'A common question about local market conditions',
            'q3' => 'A common question about the buying or selling process',
            'q4' => 'A common question about timeline expectations',
            'q5' => 'A common question about working with this agency',
        ] ),
        virobuilder_ai_section_cta( 'Get in touch →' ),
    ];
}

// ════════════════════════════════════════════════════════════════
// Law Firm
// ════════════════════════════════════════════════════════════════
function virobuilder_ai_recipe_law(): array {
    return [
        [
            'section_id' => 'hero-asymmetric-split',
            'copy_keys' => [
                'eyebrow'    => 'PRACTICE AREAS · YEAR ESTABLISHED',
                'headline'   => 'Law firm headline for {name} - serious, trustworthy',
                'subhead'    => 'What {name} represents and who - 1-2 sentences',
                'cta_text'   => 'Schedule consultation →',
            ],
            'substitutions' => [
                'eyebrow:0:text'         => 'eyebrow',
                'heading:0:title'        => 'headline',
                'text-editor:0:content'  => 'subhead',
                'button:0:text'          => 'cta_text',
            ],
            'brand_color_targets' => [ 'button:0:bg_color', 'button:0:hover_bg_color' ],
            'image_targets' => [ 'image:0:image_url' => 'hero' ],
        ],
        [
            'section_id' => 'services-grid-6',
            'copy_keys' => [
                'eyebrow'   => 'PRACTICE AREAS',
                'headline'  => "What {name} specializes in",
                'serv1_title' => 'Practice area 1 (e.g. "Corporate Law")',
                'serv1_desc'  => 'What it covers - 1-2 sentences',
                'serv2_title' => 'Practice area 2',
                'serv2_desc'  => 'What it covers - 1-2 sentences',
                'serv3_title' => 'Practice area 3',
                'serv3_desc'  => 'What it covers - 1-2 sentences',
                'serv4_title' => 'Practice area 4',
                'serv4_desc'  => 'What it covers - 1-2 sentences',
                'serv5_title' => 'Practice area 5',
                'serv5_desc'  => 'What it covers - 1-2 sentences',
                'serv6_title' => 'Practice area 6',
                'serv6_desc'  => 'What it covers - 1-2 sentences',
            ],
            'substitutions' => [
                'eyebrow:0:text'         => 'eyebrow',
                'heading:0:title'        => 'headline',
                'icon-box:0:title'       => 'serv1_title',
                'icon-box:0:description' => 'serv1_desc',
                'icon-box:1:title'       => 'serv2_title',
                'icon-box:1:description' => 'serv2_desc',
                'icon-box:2:title'       => 'serv3_title',
                'icon-box:2:description' => 'serv3_desc',
                'icon-box:3:title'       => 'serv4_title',
                'icon-box:3:description' => 'serv4_desc',
                'icon-box:4:title'       => 'serv5_title',
                'icon-box:4:description' => 'serv5_desc',
                'icon-box:5:title'       => 'serv6_title',
                'icon-box:5:description' => 'serv6_desc',
            ],
        ],
        virobuilder_ai_section_testimonials( 'CLIENT REPRESENTATION' ),
        virobuilder_ai_section_faq( [
            'q1' => 'A common question about consultation fees',
            'q2' => 'A common question about case timeline',
            'q3' => 'A common question about confidentiality',
            'q4' => 'A common question about the legal process',
            'q5' => 'A common question about jurisdiction or scope',
        ] ),
        virobuilder_ai_section_cta( 'Schedule consultation →' ),
    ];
}

// ════════════════════════════════════════════════════════════════
// E-commerce
// ════════════════════════════════════════════════════════════════
function virobuilder_ai_recipe_ecommerce(): array {
    return [
        [
            'section_id' => 'hero-asymmetric-split',
            'copy_keys' => [
                'eyebrow'    => 'NEW · BESTSELLER · LIMITED EDITION',
                'headline'   => 'Product headline for {name} - aspirational',
                'subhead'    => "Why {audience} loves {name} - 1-2 sentences",
                'cta_text'   => 'Shop now →',
            ],
            'substitutions' => [
                'eyebrow:0:text'         => 'eyebrow',
                'heading:0:title'        => 'headline',
                'text-editor:0:content'  => 'subhead',
                'button:0:text'          => 'cta_text',
            ],
            'brand_color_targets' => [ 'button:0:bg_color', 'button:0:hover_bg_color' ],
            'image_targets' => [ 'image:0:image_url' => 'hero' ],
        ],
        [
            'section_id' => 'features-modern-grid',
            'copy_keys' => [
                'eyebrow'        => 'WHY IT WORKS',
                'headline'       => "What makes {name} different",
                'subhead'        => 'Concrete product benefits',
                'feat1_title'    => 'Benefit 1 (2-3 words)',
                'feat1_desc'     => 'Specific outcome - 1-2 sentences',
                'feat2_title'    => 'Benefit 2 (2-3 words)',
                'feat2_desc'     => 'Specific outcome - 1-2 sentences',
                'feat3_title'    => 'Benefit 3 (2-3 words)',
                'feat3_desc'     => 'Specific outcome - 1-2 sentences',
            ],
            'substitutions' => [
                'eyebrow:0:text'         => 'eyebrow',
                'heading:0:title'        => 'headline',
                'text-editor:0:content'  => 'subhead',
                'icon-box:0:title'       => 'feat1_title',
                'icon-box:0:description' => 'feat1_desc',
                'icon-box:1:title'       => 'feat2_title',
                'icon-box:1:description' => 'feat2_desc',
                'icon-box:2:title'       => 'feat3_title',
                'icon-box:2:description' => 'feat3_desc',
            ],
        ],
        virobuilder_ai_section_testimonials( 'CUSTOMER REVIEWS' ),
        virobuilder_ai_section_faq( [
            'q1' => 'A common shipping question',
            'q2' => 'A common returns/refunds question',
            'q3' => 'A common product care/usage question',
            'q4' => 'A common sizing/fit question (if applicable)',
            'q5' => 'A common quality/materials question',
        ] ),
        virobuilder_ai_section_cta( 'Shop now →' ),
    ];
}

// ════════════════════════════════════════════════════════════════
// Fitness
// ════════════════════════════════════════════════════════════════
function virobuilder_ai_recipe_fitness(): array {
    return [
        [
            'section_id' => 'hero-asymmetric-split',
            'copy_keys' => [
                'eyebrow'    => 'TRAINING STYLE · NEIGHBORHOOD',
                'headline'   => "{name}'s tagline - energetic, motivating, max 8 words",
                'subhead'    => "Who {name} is for and what they'll achieve - 1-2 sentences",
                'cta_text'   => 'Start your free week →',
            ],
            'substitutions' => [
                'eyebrow:0:text'         => 'eyebrow',
                'heading:0:title'        => 'headline',
                'text-editor:0:content'  => 'subhead',
                'button:0:text'          => 'cta_text',
            ],
            'brand_color_targets' => [ 'button:0:bg_color', 'button:0:hover_bg_color' ],
            'image_targets' => [ 'image:0:image_url' => 'hero' ],
        ],
        [
            'section_id' => 'services-grid-6',
            'copy_keys' => [
                'eyebrow'   => 'PROGRAMS',
                'headline'  => "What's available at {name}",
                'serv1_title' => 'Program 1 (e.g. "Strength training")',
                'serv1_desc'  => 'What it covers - 1-2 sentences',
                'serv2_title' => 'Program 2',
                'serv2_desc'  => 'What it covers - 1-2 sentences',
                'serv3_title' => 'Program 3',
                'serv3_desc'  => 'What it covers - 1-2 sentences',
                'serv4_title' => 'Program 4',
                'serv4_desc'  => 'What it covers - 1-2 sentences',
                'serv5_title' => 'Program 5',
                'serv5_desc'  => 'What it covers - 1-2 sentences',
                'serv6_title' => 'Program 6',
                'serv6_desc'  => 'What it covers - 1-2 sentences',
            ],
            'substitutions' => [
                'eyebrow:0:text'         => 'eyebrow',
                'heading:0:title'        => 'headline',
                'icon-box:0:title'       => 'serv1_title',
                'icon-box:0:description' => 'serv1_desc',
                'icon-box:1:title'       => 'serv2_title',
                'icon-box:1:description' => 'serv2_desc',
                'icon-box:2:title'       => 'serv3_title',
                'icon-box:2:description' => 'serv3_desc',
                'icon-box:3:title'       => 'serv4_title',
                'icon-box:3:description' => 'serv4_desc',
                'icon-box:4:title'       => 'serv5_title',
                'icon-box:4:description' => 'serv5_desc',
                'icon-box:5:title'       => 'serv6_title',
                'icon-box:5:description' => 'serv6_desc',
            ],
        ],
        virobuilder_ai_section_testimonials( 'MEMBER STORIES' ),
        virobuilder_ai_section_faq( [
            'q1' => 'A common question about trial week / first visit',
            'q2' => 'A common question about cancellation policy',
            'q3' => 'A common question about classes / programs',
            'q4' => 'A common question about beginner-friendliness',
            'q5' => 'A common question about facilities or equipment',
        ] ),
        virobuilder_ai_section_cta( 'Start your free week →' ),
    ];
}
