<?php
/**
 * ViroBuilder AI Chat Editor — Edit Prompt System.
 *
 * When the user gives an instruction like "make the headline shorter" or
 * "change the brand color to blue," this prompt tells Claude how to modify
 * the existing page HTML while preserving the design system integrity.
 *
 * @package ViroBuilder
 */

defined( 'ABSPATH' ) || exit;
/**
 * System prompt for page editing via chat.
 */
function virobuilder_editor_system_prompt(): string {
    return file_get_contents( __DIR__ . '/../../prompts/editor-system.txt' );
}

/**
 * Build the messages array for an edit request.
 *
 * @param string $current_html  The current page HTML.
 * @param string $instruction   The user's edit instruction.
 * @param array  $history       Previous chat messages [{role, content}, ...].
 * @return array  Messages array for the API call.
 */
function virobuilder_editor_build_messages(
    string $current_html,
    string $instruction,
    array $history = []
): array {
    $messages = [];

    // Include recent history (last 6 exchanges max to stay within context)
    $recent = array_slice( $history, -12 );
    foreach ( $recent as $msg ) {
        $messages[] = [
            'role'    => $msg['role'],
            'content' => $msg['content'],
        ];
    }

    // Current edit request
    $messages[] = [
        'role'    => 'user',
        'content' => "Here is the current page HTML:\n\n" . $current_html .
                     "\n\n---\n\nMake this change: " . $instruction,
    ];

    return $messages;
}
