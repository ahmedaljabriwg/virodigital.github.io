<?php
/**
 * Layout archetypes for the AI designer.
 *
 * The old prompt described ONE rigid page skeleton, so every generation looked
 * identical regardless of industry. Instead we define a set of distinct page
 * architectures and inject exactly ONE into the prompt per generation — chosen
 * by industry fit plus randomness — so a portfolio, a clinic, and a bookstore
 * each get a genuinely different base structure.
 *
 * @package ViroBuilder
 */

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

if ( ! function_exists( 'virobuilder_layout_archetypes' ) ) {
    /**
     * The archetype library. Each entry defines a complete page architecture:
     * section order, hero style, the treatment of each major section, and one
     * signature moment that makes it distinct. These are intentionally concrete
     * about STRUCTURE but defer all color/type/copy to the shared design system.
     *
     * @return array<string,array{name:string,fits:array<string>,spec:string}>
     */
    function virobuilder_layout_archetypes(): array {
        return [

            // 1. Editorial / magazine — big type, asymmetric, for creative & brand-led sites
            'editorial' => [
                'name' => 'Editorial',
                'fits' => [ 'photography', 'agency', 'beauty', 'restaurant', 'nonprofit', 'realestate', 'fitness', 'ecommerce', 'other' ],
                'spec_file' => 'editorial',
            ],

            // 2. Bold SaaS / product — punchy, conversion-focused, for software & tech
            'product' => [
                'name' => 'Product',
                'fits' => [ 'saas', 'consulting', 'education', 'agency', 'fitness', 'construction', 'dental', 'ecommerce', 'other' ],
                'spec_file' => 'product',
            ],

            // 3. Warm local business — trust-first, for clinics, trades, services
            'local' => [
                'name' => 'Local Business',
                'fits' => [ 'dental', 'law', 'construction', 'fitness', 'beauty', 'consulting', 'realestate', 'restaurant', 'other' ],
                'spec_file' => 'local',
            ],

            // 4. Portfolio / showcase — visual-first, for creatives & studios
            'portfolio' => [
                'name' => 'Portfolio',
                'fits' => [ 'photography', 'agency', 'beauty', 'realestate', 'other' ],
                'spec_file' => 'portfolio',
            ],

            // 5. Storefront / catalog — for shops, bookstores, products
            'storefront' => [
                'name' => 'Storefront',
                'fits' => [ 'ecommerce', 'restaurant', 'beauty', 'realestate', 'other' ],
                'spec_file' => 'storefront',
            ],

            // 6. Classic professional — formal, structured, for law/finance/consulting
            'professional' => [
                'name' => 'Professional',
                'fits' => [ 'law', 'consulting', 'education', 'nonprofit', 'dental', 'construction', 'realestate', 'other' ],
                'spec_file' => 'professional',
            ],

            // 7. Event / launch — single-focus, urgency, for launches, campaigns
            'event' => [
                'name' => 'Event / Launch',
                'fits' => [ 'nonprofit', 'education', 'saas', 'restaurant', 'fitness', 'other' ],
                'spec_file' => 'event',
            ],

            // 8. Minimal one-pager — calm, lots of space, for simple/abstract businesses
            'minimal' => [
                'name' => 'Minimal',
                'fits' => [ 'saas', 'consulting', 'photography', 'agency', 'education', 'law', 'dental', 'nonprofit', 'ecommerce', 'other' ],
                'spec_file' => 'minimal',
            ],
        ];
    }
}

if ( ! function_exists( 'virobuilder_pick_archetype' ) ) {
    /**
     * Pick ONE archetype for this generation, biased toward the industry fit but
     * with randomness so repeat generations for the same industry still differ.
     *
     * @param array $brief The generation brief (expects 'industry').
     * @return array{key:string,name:string,spec:string}
     */
    function virobuilder_pick_archetype( array $brief ): array {
        $archetypes = virobuilder_layout_archetypes();
        $industry   = strtolower( (string) ( $brief['industry'] ?? 'other' ) );

        // Allow an explicit override (e.g. for testing or a future "regenerate with different layout").
        if ( ! empty( $brief['layout_archetype'] ) && isset( $archetypes[ $brief['layout_archetype'] ] ) ) {
            $k = $brief['layout_archetype'];
            return [ 'key' => $k, 'name' => $archetypes[ $k ]['name'], 'spec' => virobuilder_load_archetype_spec( $archetypes[ $k ]['spec_file'] ) ];
        }

        // Build the candidate pool: archetypes that fit this industry.
        $pool = [];
        foreach ( $archetypes as $key => $a ) {
            if ( in_array( $industry, $a['fits'], true ) ) {
                $pool[] = $key;
            }
        }

        // If the industry matched nothing specific, any archetype is fair game.
        if ( empty( $pool ) ) {
            $pool = array_keys( $archetypes );
        }

        // Random choice from the fitting pool.
        $key = $pool[ array_rand( $pool ) ];

        return [
            'key'  => $key,
            'name' => $archetypes[ $key ]['name'],
            'spec' => virobuilder_load_archetype_spec( $archetypes[ $key ]['spec_file'] ),
        ];
    }
}

if ( ! function_exists( 'virobuilder_load_archetype_spec' ) ) {
    /**
     * Load an archetype spec from its text file.
     */
    function virobuilder_load_archetype_spec( string $key ): string {
        $file = __DIR__ . '/../../prompts/archetypes/' . sanitize_file_name( $key ) . '.txt';
        if ( is_readable( $file ) ) {
            return (string) file_get_contents( $file );
        }
        return '';
    }
}
