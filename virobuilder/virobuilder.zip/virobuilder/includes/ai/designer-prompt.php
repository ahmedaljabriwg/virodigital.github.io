<?php
/**
 * ViroBuilder AI Page Designer — Prompt Engineering System.
 *
 * The system prompt encodes a complete design system at the quality level of
 * a $10K agency build. Every visual detail, responsive behavior, animation,
 * and micro-interaction is specified explicitly so the AI has no room to
 * produce generic output.
 *
 * @package ViroBuilder
 */

defined( 'ABSPATH' ) || exit;
/**
 * Build the system prompt for the AI page designer.
 */
function virobuilder_designer_system_prompt( array $brief ): string {
    $brand = $brief['brand_color'] ?? '#1f4a3f';

    // Pick ONE page architecture for this generation so every page differs.
    if ( ! function_exists( 'virobuilder_pick_archetype' ) ) {
        require_once __DIR__ . '/layout-archetypes.php';
    }
    $archetype      = virobuilder_pick_archetype( $brief );
    $archetype_name = $archetype['name'];
    $archetype_spec = $archetype['spec'];

    $tpl = file_get_contents( __DIR__ . '/../../prompts/designer-system.txt' );
    return strtr( $tpl, [
        '{{BRAND}}'          => $brand,
        '{{ARCHETYPE_NAME}}' => $archetype_name,
        '{{ARCHETYPE_SPEC}}' => $archetype_spec,
    ] );
}

/**
 * Build the user message (business brief) for the AI.
 */
function virobuilder_designer_user_prompt( array $brief ): string {
    $name     = $brief['business_name'] ?? 'My Business';
    $industry = $brief['industry'] ?? 'professional services';
    $offering = $brief['offering'] ?? '';
    $audience = $brief['audience'] ?? '';
    $tone     = $brief['tone'] ?? 'professional and approachable';
    $location = $brief['location'] ?? '';
    $phone    = $brief['phone'] ?? '';
    $color    = $brief['brand_color'] ?? '#1f4a3f';

    $tpl = file_get_contents( __DIR__ . '/../../prompts/designer-user.txt' );
    return strtr( $tpl, [
        '{{NAME}}'     => $name,
        '{{INDUSTRY}}' => $industry,
        '{{OFFERING}}' => $offering,
        '{{AUDIENCE}}' => $audience,
        '{{TONE}}'     => $tone,
        '{{LOCATION}}' => $location,
        '{{PHONE}}'    => $phone,
        '{{COLOR}}'    => $color,
    ] );
}
