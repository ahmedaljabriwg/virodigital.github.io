<?php
/**
 * ViroBuilder AI Designer — Full-page HTML generation.
 *
 * This is the new generation pipeline that produces designer-grade HTML pages
 * (like a $10K agency site) rather than widget-tree assembly. The AI designs
 * the complete page as one coherent document with a proper CSS design system.
 *
 * Generation flow:
 *   1. Build system + user prompts from business brief
 *   2. Call Claude API (BYOK or Pro proxy key)
 *   3. Receive complete HTML document
 *   4. Inject real Pexels photos into {{IMAGE_SLOT}} placeholders
 *   5. Register section boundaries for editor integration
 *   6. Store as post content (raw HTML) + section metadata
 *
 * @package ViroBuilder
 */

defined( 'ABSPATH' ) || exit;

require_once __DIR__ . '/designer-prompt.php';

class ViroBuilder_AI_Designer {

    const AI_MODEL = 'claude-sonnet-4-6';

    private array $brief;

    public function __construct( array $brief ) {
        $this->brief = $brief;
    }

    /**
     * Generate a complete designed page.
     *
     * @return array {
     *   html:           string   Complete HTML document
     *   sections:       array    Section metadata for editor
     *   usage:          array    Token usage stats
     *   cost_estimate:  string   Approximate cost in USD
     * }
     * @throws Exception on API or validation errors.
     */
    public function generate(): array {
        $api_key = $this->resolve_api_key();

        $system_prompt = virobuilder_designer_system_prompt( $this->brief );
        $user_prompt   = virobuilder_designer_user_prompt( $this->brief );

        // Call Claude API
        $response = wp_remote_post( 'https://api.anthropic.com/v1/messages', [
            'timeout' => 300, // Full page generation can take 60-180s on slower connections
            'headers' => [
                'Content-Type'      => 'application/json',
                'x-api-key'         => $api_key,
                'anthropic-version' => '2023-06-01',
            ],
            'body' => wp_json_encode( [
                'model'      => self::AI_MODEL,
                'max_tokens' => 16000,
                'system'     => $system_prompt,
                'messages'   => [
                    [
                        'role'    => 'user',
                        'content' => $user_prompt,
                    ],
                ],
            ] ),
        ] );

        if ( is_wp_error( $response ) ) {
            throw new Exception( esc_html( 'AI request failed: ' . $response->get_error_message() ) );
        }

        $code = wp_remote_retrieve_response_code( $response );
        $body = wp_remote_retrieve_body( $response );

        if ( $code !== 200 ) {
            $error_body = json_decode( $body, true );
            $error_msg  = $error_body['error']['message'] ?? 'HTTP ' . $code;
            throw new Exception( esc_html( 'Anthropic API error: ' . $error_msg ) );
        }

        $data = json_decode( $body, true );

        // Extract HTML from response content blocks
        $html = '';
        foreach ( ( $data['content'] ?? [] ) as $block ) {
            if ( ( $block['type'] ?? '' ) === 'text' ) {
                $html .= $block['text'];
            }
        }

        if ( empty( $html ) ) {
            throw new Exception( esc_html( 'AI returned empty response.' ) );
        }

        // Strip markdown code fences if present
        $html = preg_replace( '/^```html?\s*/i', '', $html );
        $html = preg_replace( '/\s*```\s*$/', '', $html );

        // Validate it's actual HTML
        if ( stripos( $html, '<!DOCTYPE' ) === false && stripos( $html, '<html' ) === false ) {
            throw new Exception( esc_html( 'AI did not return valid HTML. Response starts with: ' . substr( $html, 0, 100 ) ) );
        }

        // Quality validation — check for critical design system elements
        $quality_issues = $this->validate_quality( $html );
        if ( ! empty( $quality_issues ) ) {
            // Log issues but don't block — the page may still be usable
            if ( defined( 'WP_DEBUG' ) && WP_DEBUG ) {
                // phpcs:ignore WordPress.PHP.DevelopmentFunctions.error_log_error_log -- debug-only diagnostic
                error_log( 'ViroBuilder Designer quality issues: ' . implode( ', ', $quality_issues ) );
            }
        }

        // Inject real Pexels images
        $html = $this->inject_images( $html );

        // Ensure SEO meta tags and JSON-LD are present
        $html = $this->ensure_seo( $html );

        // Extract section metadata for editor
        $sections = $this->extract_sections( $html );

        // Calculate cost estimate
        $usage          = $data['usage'] ?? [];
        $input_tokens   = $usage['input_tokens'] ?? 0;
        $output_tokens  = $usage['output_tokens'] ?? 0;
        $cost           = ( $input_tokens * 0.003 / 1000 ) + ( $output_tokens * 0.015 / 1000 );
        $cost_str       = '$' . number_format( $cost, 4 );

        return [
            'html'          => $html,
            'sections'      => $sections,
            'usage'         => $usage,
            'cost_estimate' => $cost_str,
        ];
    }

    /**
     * Resolve which API key to use: Pro proxy or user's own BYOK key.
     *
     * Priority:
     *   1. ViroBuilder Pro license key → proxy through virodigital.net (future)
     *   2. User's own Anthropic API key (BYOK)
     *   3. Error
     */
    private function resolve_api_key(): string {
        // Check for Pro license first (future — proxy endpoint at virodigital.net)
        $pro_key = get_option( 'virobuilder_pro_license_key', '' );
        if ( ! empty( $pro_key ) ) {
            // TODO: When Pro launches, validate the license against virodigital.net
            // and return a proxied API key. For now, fall through to BYOK.
            // $proxy_key = $this->validate_pro_license( $pro_key );
            // if ( $proxy_key ) return $proxy_key;
        }

        // BYOK: user's own Anthropic API key
        $api_key = get_option( 'virobuilder_ai_api_key', '' );
        if ( ! empty( $api_key ) ) {
            return $api_key;
        }

        throw new Exception(
            'No API key configured. Add your Anthropic API key in ViroBuilder → AI Settings, '
            . 'or upgrade to ViroBuilder Pro for hassle-free generation.'
        );
    }

    /**
     * Replace {{IMAGE_SLOT}} placeholders with real Pexels photos.
     */
    private function inject_images( string $html ): string {
        if ( ! function_exists( 'virobuilder_ai_get_image_provider' ) ) {
            return $html;
        }

        $pexels_key = get_option( 'virobuilder_pexels_api_key', '' );
        if ( empty( $pexels_key ) ) {
            // No Pexels key: replace slots with a pleasant placeholder
            $placeholder = 'data:image/svg+xml,' . rawurlencode(
                '<svg xmlns="http://www.w3.org/2000/svg" width="1200" height="800" viewBox="0 0 1200 800">'
                . '<rect fill="#e8e4dc" width="1200" height="800"/>'
                . '<text x="600" y="400" text-anchor="middle" fill="#a09888" font-family="system-ui" font-size="24">Add your photo</text>'
                . '</svg>'
            );
            return preg_replace( '/\{\{\s*[A-Z_0-9]+\s*\}\}/', $placeholder, $html );
        }

        $provider = virobuilder_ai_get_image_provider();
        $industry = $this->brief['industry'] ?? 'professional services';
        $used_ids = [];

        // Map slot names to search queries
        $slot_queries = $this->get_image_slot_queries( $industry );

        // Find all {{SLOT}} markers in the HTML (unique slot names)
        if ( preg_match_all( '/\{\{\s*([A-Z_0-9]+)\s*\}\}/', $html, $matches ) ) {
            $slots = array_unique( $matches[1] );
            foreach ( $slots as $slot_name ) {
                $query = $slot_queries[ $slot_name ] ?? $slot_queries['_default'] ?? $industry . ' professional';

                $results = $provider->search( $query, 8, 'landscape' );

                $chosen = null;
                foreach ( $results as $img ) {
                    $id = $img['pexels_id'] ?? 0;
                    if ( $id && in_array( $id, $used_ids, true ) ) {
                        continue;
                    }
                    $chosen = $img;
                    if ( $id ) $used_ids[] = $id;
                    break;
                }

                if ( $chosen ) {
                    $replacement = esc_url( $chosen['url'] );
                } else {
                    // Fallback: leave a branded placeholder
                    $replacement = 'data:image/svg+xml,' . rawurlencode(
                        '<svg xmlns="http://www.w3.org/2000/svg" width="1200" height="800" viewBox="0 0 1200 800">'
                        . '<rect fill="#e8e4dc" width="1200" height="800"/>'
                        . '<text x="600" y="400" text-anchor="middle" fill="#a09888" font-family="system-ui" font-size="20">'
                        . htmlspecialchars( $slot_name ) . '</text></svg>'
                    );
                }

                // Replace ALL occurrences of this slot with the same image (whitespace-tolerant)
                $html = preg_replace(
                    '/\{\{\s*' . preg_quote( $slot_name, '/' ) . '\s*\}\}/',
                    str_replace( '$', '\$', $replacement ),
                    $html
                );
            }
        }

        return $html;
    }

    /**
     * Map image slot names to Pexels search queries based on industry.
     */
    private function get_image_slot_queries( string $industry ): array {
        $base = [
            'HERO_IMAGE'  => '',
            'ABOUT_IMAGE' => '',
            'GALLERY_1'   => '',
            'GALLERY_2'   => '',
            'GALLERY_3'   => '',
            '_default'    => 'modern professional business',
        ];

        $industry_queries = [
            'dental clinic' => [
                'HERO_IMAGE'  => 'modern dental clinic interior bright',
                'ABOUT_IMAGE' => 'dentist consulting patient friendly',
                'GALLERY_1'   => 'dental office reception modern',
                'GALLERY_2'   => 'dental team professional',
                'GALLERY_3'   => 'dental treatment room clean',
                '_default'    => 'modern dental care',
            ],
            'health' => [
                'HERO_IMAGE'  => 'modern medical clinic interior',
                'ABOUT_IMAGE' => 'doctor patient consultation',
                '_default'    => 'modern healthcare facility',
            ],
            'saas' => [
                'HERO_IMAGE'  => 'team working laptops modern office',
                'ABOUT_IMAGE' => 'startup founder office portrait',
                '_default'    => 'modern office technology',
            ],
            'agency' => [
                'HERO_IMAGE'  => 'creative team brainstorming modern office',
                'ABOUT_IMAGE' => 'design studio workspace',
                '_default'    => 'creative design workspace',
            ],
            'restaurant' => [
                'HERO_IMAGE'  => 'restaurant interior warm lighting',
                'ABOUT_IMAGE' => 'chef preparing food kitchen',
                'GALLERY_1'   => 'gourmet dish plating',
                'GALLERY_2'   => 'restaurant bar interior',
                'GALLERY_3'   => 'outdoor dining patio',
                '_default'    => 'restaurant dining',
            ],
            'realestate' => [
                'HERO_IMAGE'  => 'luxury modern house exterior',
                'ABOUT_IMAGE' => 'real estate agent showing property',
                'GALLERY_1'   => 'modern living room interior',
                'GALLERY_2'   => 'kitchen design modern',
                'GALLERY_3'   => 'house exterior garden',
                '_default'    => 'modern home interior design',
            ],
            'law' => [
                'HERO_IMAGE'  => 'law firm modern office interior',
                'ABOUT_IMAGE' => 'lawyer client meeting consultation',
                '_default'    => 'professional business office',
            ],
            'ecommerce' => [
                'HERO_IMAGE'  => 'product photography lifestyle minimal',
                'ABOUT_IMAGE' => 'small business owner workshop',
                'GALLERY_1'   => 'product packaging modern',
                'GALLERY_2'   => 'online shopping lifestyle',
                'GALLERY_3'   => 'warehouse fulfillment',
                '_default'    => 'product lifestyle photography',
            ],
            'fitness' => [
                'HERO_IMAGE'  => 'modern gym interior equipment',
                'ABOUT_IMAGE' => 'personal trainer coaching client',
                '_default'    => 'fitness gym training',
            ],
        ];

        // Try exact match, then partial match on first word
        if ( isset( $industry_queries[ $industry ] ) ) {
            return array_merge( $base, $industry_queries[ $industry ] );
        }

        // Partial match
        $first_word = strtolower( explode( ' ', $industry )[0] );
        foreach ( $industry_queries as $key => $queries ) {
            if ( strpos( $key, $first_word ) !== false ) {
                return array_merge( $base, $queries );
            }
        }

        return $base;
    }

    /**
     * Extract section boundaries from data-viro-section attributes.
     * These power the editor's section reordering, visibility toggles, etc.
     */
    private function extract_sections( string $html ): array {
        $sections = [];
        if ( preg_match_all( '/data-viro-section="([^"]+)"/', $html, $matches ) ) {
            foreach ( $matches[1] as $i => $name ) {
                $sections[] = [
                    'id'    => $name,
                    'order' => $i,
                    'label' => ucfirst( str_replace( [ '-', '_' ], ' ', $name ) ),
                ];
            }
        }
        return $sections;
    }

    /**
     * Validate the generated HTML meets our quality bar.
     *
     * Returns an array of issue strings (empty = all good).
     * Does NOT block generation — just logs warnings.
     */
    private function validate_quality( string $html ): array {
        $issues = [];

        // Design system tokens
        if ( stripos( $html, ':root' ) === false ) {
            $issues[] = 'Missing :root CSS custom properties';
        }
        if ( stripos( $html, '--font-display' ) === false ) {
            $issues[] = 'Missing --font-display variable';
        }
        if ( stripos( $html, 'clamp(' ) === false ) {
            $issues[] = 'Missing fluid typography (clamp)';
        }

        // Responsive
        if ( stripos( $html, '@media' ) === false ) {
            $issues[] = 'Missing responsive @media breakpoints';
        }
        if ( preg_match_all( '/@media\s*\(/', $html ) < 2 ) {
            $issues[] = 'Fewer than 2 responsive breakpoints (expected 3)';
        }

        // Structure
        if ( stripos( $html, 'data-viro-section' ) === false ) {
            $issues[] = 'Missing data-viro-section markers';
        }
        if ( stripos( $html, 'data-viro-editable' ) === false ) {
            $issues[] = 'Missing data-viro-editable markers';
        }

        // Visual quality
        if ( stripos( $html, 'backdrop-filter' ) === false ) {
            $issues[] = 'Missing frosted-glass nav (backdrop-filter)';
        }
        if ( stripos( $html, 'IntersectionObserver' ) === false ) {
            $issues[] = 'Missing scroll animations';
        }
        if ( stripos( $html, 'translateY(' ) === false ) {
            $issues[] = 'Missing hover elevation effects';
        }
        if ( stripos( $html, '::before' ) === false && stripos( $html, '::after' ) === false ) {
            $issues[] = 'Missing decorative pseudo-elements';
        }
        if ( stripos( $html, 'prefers-reduced-motion' ) === false ) {
            $issues[] = 'Missing prefers-reduced-motion respect';
        }

        // Accessibility
        if ( preg_match_all( '/alt="[^"]+"/i', $html ) < 1 ) {
            $issues[] = 'Images missing alt text';
        }

        // SEO
        if ( stripos( $html, 'meta name="description"' ) === false ) {
            $issues[] = 'Missing meta description';
        }
        if ( stripos( $html, 'og:title' ) === false ) {
            $issues[] = 'Missing Open Graph tags';
        }
        if ( stripos( $html, 'twitter:card' ) === false ) {
            $issues[] = 'Missing Twitter Card tags';
        }
        if ( stripos( $html, 'application/ld+json' ) === false ) {
            $issues[] = 'Missing JSON-LD structured data';
        }
        $h1_count = preg_match_all( '/<h1[\s>]/i', $html );
        if ( $h1_count === 0 ) {
            $issues[] = 'Missing h1 tag';
        } elseif ( $h1_count > 1 ) {
            $issues[] = 'Multiple h1 tags (should be exactly one)';
        }

        return $issues;
    }

    /**
     * Ensure SEO meta tags and JSON-LD are present.
     *
     * If the AI included them (it should), this is a no-op.
     * If any are missing, inject them from the business brief.
     */
    private function ensure_seo( string $html ): string {
        $name     = esc_attr( $this->brief['business_name'] ?? 'Business' );
        $industry = esc_attr( $this->brief['industry'] ?? '' );
        $offering = esc_attr( $this->brief['offering'] ?? '' );
        $location = esc_attr( $this->brief['location'] ?? '' );
        $phone    = esc_attr( $this->brief['phone'] ?? '' );

        // Build a meta description from the brief
        $desc_parts = array_filter( [ $name, $offering ] );
        if ( $location ) $desc_parts[] = 'in ' . $location;
        $meta_desc = mb_substr( implode( ' — ', $desc_parts ), 0, 155 );

        $injections = '';

        // Meta description
        if ( stripos( $html, 'meta name="description"' ) === false ) {
            $injections .= '<meta name="description" content="' . $meta_desc . '">' . "\n";
        }

        // Robots
        if ( stripos( $html, 'meta name="robots"' ) === false ) {
            $injections .= '<meta name="robots" content="index, follow">' . "\n";
        }

        // Open Graph
        if ( stripos( $html, 'og:title' ) === false ) {
            $injections .= '<meta property="og:type" content="website">' . "\n";
            $injections .= '<meta property="og:title" content="' . $name . '">' . "\n";
            $injections .= '<meta property="og:description" content="' . $meta_desc . '">' . "\n";
            $injections .= '<meta property="og:image" content="{{HERO_IMAGE}}">' . "\n";
            $injections .= '<meta property="og:site_name" content="' . $name . '">' . "\n";
        }

        // Twitter Card
        if ( stripos( $html, 'twitter:card' ) === false ) {
            $injections .= '<meta name="twitter:card" content="summary_large_image">' . "\n";
            $injections .= '<meta name="twitter:title" content="' . $name . '">' . "\n";
            $injections .= '<meta name="twitter:description" content="' . $meta_desc . '">' . "\n";
            $injections .= '<meta name="twitter:image" content="{{HERO_IMAGE}}">' . "\n";
        }

        // Inject before </head>
        if ( ! empty( $injections ) ) {
            $html = str_replace( '</head>', $injections . '</head>', $html );
        }

        // JSON-LD structured data
        if ( stripos( $html, 'application/ld+json' ) === false ) {
            $schema_type = $this->get_schema_type( $this->brief['industry'] ?? '' );

            $schema = [
                '@context'    => 'https://schema.org',
                '@type'       => $schema_type,
                'name'        => $this->brief['business_name'] ?? '',
                'description' => $this->brief['offering'] ?? '',
                'url'         => '#',
            ];

            if ( ! empty( $phone ) ) {
                $schema['telephone'] = $this->brief['phone'];
            }

            if ( ! empty( $location ) ) {
                // Try to parse "City, State" or "Neighborhood, City, State"
                $loc_parts = array_map( 'trim', explode( ',', $this->brief['location'] ) );
                $schema['address'] = [
                    '@type' => 'PostalAddress',
                ];
                if ( count( $loc_parts ) >= 2 ) {
                    $schema['address']['addressLocality'] = $loc_parts[ count( $loc_parts ) - 2 ];
                    $schema['address']['addressRegion']   = end( $loc_parts );
                } else {
                    $schema['address']['addressLocality'] = $loc_parts[0];
                }
            }

            $schema['image'] = '{{HERO_IMAGE}}';

            $json_ld = '<script type="application/ld+json">' . "\n"
                     . wp_json_encode( $schema, JSON_PRETTY_PRINT | JSON_UNESCAPED_SLASHES )
                     . "\n</script>\n";

            $html = str_replace( '</head>', $json_ld . '</head>', $html );
        }

        return $html;
    }

    /**
     * Map industry to Schema.org type.
     */
    private function get_schema_type( string $industry ): string {
        $lower = strtolower( $industry );
        $map = [
            'dental'      => 'Dentist',
            'dentist'     => 'Dentist',
            'medical'     => 'MedicalBusiness',
            'health'      => 'MedicalBusiness',
            'clinic'      => 'MedicalBusiness',
            'restaurant'  => 'Restaurant',
            'food'        => 'Restaurant',
            'cafe'        => 'Restaurant',
            'law'         => 'LegalService',
            'legal'       => 'LegalService',
            'attorney'    => 'LegalService',
            'realestate'  => 'RealEstateAgent',
            'real estate' => 'RealEstateAgent',
            'property'    => 'RealEstateAgent',
            'saas'        => 'SoftwareApplication',
            'software'    => 'SoftwareApplication',
            'tech'        => 'Organization',
            'agency'      => 'ProfessionalService',
            'design'      => 'ProfessionalService',
            'marketing'   => 'ProfessionalService',
            'consulting'  => 'ProfessionalService',
            'fitness'     => 'HealthClub',
            'gym'         => 'HealthClub',
            'ecommerce'   => 'Store',
            'shop'        => 'Store',
            'retail'      => 'Store',
        ];

        foreach ( $map as $keyword => $type ) {
            if ( strpos( $lower, $keyword ) !== false ) {
                return $type;
            }
        }

        return 'LocalBusiness';
    }
}
