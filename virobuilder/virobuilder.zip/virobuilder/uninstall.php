<?php
/**
 * ViroBuilder uninstall routine.
 *
 * Runs only when the user deletes the plugin from the WordPress admin
 * (not on deactivation). Respects the user's choice to keep or delete data.
 *
 * @package ViroBuilder
 */

if ( ! defined( 'WP_UNINSTALL_PLUGIN' ) ) {
    exit;
}

global $wpdb;

// Check if the user chose to keep data
$virobuilder_preserve = get_option( 'virobuilder_keep_data_on_uninstall', '0' );

// Always remove transient flags and lightweight UI state
delete_option( 'virobuilder_activation_redirect' );
delete_transient( 'virobuilder_activation_redirect' );

if ( $virobuilder_preserve === '1' ) {
    // User chose to keep data — only remove the plugin itself
    return;
}

// ── Remove ALL plugin options ──
$virobuilder_options = [
    'virobuilder_version',
    'virobuilder_db_version',
    'virobuilder_forms_db_version',
    'virobuilder_ai_api_key',
    'virobuilder_pexels_api_key',
    'virobuilder_pro_license_key',
    'virobuilder_ai_mode',
    'virobuilder_ai_brand_color',
    'virobuilder_ai_default_industry',
    'virobuilder_keep_data_on_uninstall',
    'virobuilder_preserve_data_on_uninstall', // legacy
];
foreach ( $virobuilder_options as $virobuilder_option ) {
    delete_option( $virobuilder_option );
}

// ── Remove Pexels transient caches ──
// phpcs:ignore WordPress.DB.PreparedSQL.NotPrepared, WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching -- one-time uninstall cleanup of plugin transients
$wpdb->query(
    "DELETE FROM {$wpdb->options} WHERE option_name LIKE '_transient_viro_pxl_%' OR option_name LIKE '_transient_timeout_viro_pxl_%'"
);

// ── Remove per-user meta ──
delete_metadata( 'user', 0, 'virobuilder_welcome_dismissed', '', true );

// ── Remove designer page meta from all posts ──
// phpcs:ignore WordPress.DB.PreparedSQL.NotPrepared, WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching -- one-time uninstall cleanup of plugin meta
$wpdb->query(
    "DELETE FROM {$wpdb->postmeta} WHERE meta_key IN (
        '_virobuilder_designer_page',
        '_virobuilder_sections',
        '_virobuilder_brief',
        '_virobuilder_chat_history',
        '_virobuilder_data'
    )"
);

// ── Drop the submissions table ──
$virobuilder_table = $wpdb->prefix . 'virobuilder_submissions';
// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching, WordPress.DB.DirectDatabaseQuery.SchemaChange -- one-time uninstall: drop plugin table (name prepared with %i)
$wpdb->query( $wpdb->prepare( "DROP TABLE IF EXISTS %i", $virobuilder_table ) );

// ── Clear any scheduled events ──
wp_clear_scheduled_hook( 'virobuilder_cron' );
